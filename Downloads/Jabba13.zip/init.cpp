#include "piecedefs.h"
#include "defs.h"
#include "init.h"
#include "material.h"
#include "log.h"
#include "bits.h"
#include "attack.h"
#include "searcher.h"
#include "hashtab.h"
#include "eval.h"
#include "testers.h"
#include "book.h"
#include "utils.h"
#include "magic.h"
#include "evalparam.h"

sMainOpt mainopt;

void init_mainopt()
{
	mainopt.logon = true;
	mainopt.bookon = true;
	mainopt.bookfile = "final.bin";
	mainopt.inifilename = "jabba.ini";
	mainopt.tablesize = 16;
}


void setininame(string name)
{
    mainopt.inifilename = name;
    cout<<"\n reading supplied ini filename : "<<name;
    if(islog()) logger.file<<"new ini file <"<<name<<">";
}



void processini(vector<string> options)
{
    uint linenum;
    string temp;
	uint temp2 = 0;
    int pos;
    for(linenum=0; linenum < options.size(); ++linenum)
    {
        if(findsubstrend("#", options[linenum], pos))  { continue; }
		else if(findsubstrend("tablehash ", options[linenum], pos))
		{
			temp2  = strtoint(options[linenum],pos);
			if(temp2 > 1024) temp2 = 1024;
			if(temp2 < 16) temp2 = 16;
			mainopt.tablesize = temp2;
			continue;
		}
		else if(findsubstrend("log ", options[linenum], pos))
        {
            options[linenum].erase(0,pos);
            if(options[linenum]=="on")
            {
				mainopt.logon = true;
            }
			else
            {
				mainopt.logon = false;
            }
            continue;
        }
		else if(findsubstrend("book ", options[linenum], pos))
        {
            options[linenum].erase(0,pos);
            if(options[linenum]=="on")
            {
                mainopt.bookon = true;
            }
			else if(options[linenum]=="off")
            {
                mainopt.bookon = false;
            }
            continue;
        }
		else if(findsubstrend("bookname ", options[linenum], pos))
        {
            options[linenum].erase(0,pos);
			mainopt.bookfile = options[linenum];
            continue;
        }
	}
    return;
}



void showinivals()
{
#ifdef DEBUG
   cout<<"ini values from ";
    cout<<" ini file : <"<<mainopt.inifilename<<">"<<endl;
	cout<<"\ntablehash   "<<mainopt.tablesize<<" MB" ;
	cout<<"\nbookfile   "<<mainopt.bookfile<<" MB" ;
	cout<<"\nuse book "<<mainopt.bookon;
	cout<<"\nuse log "<<mainopt.logon;
    cout<<endl;
#endif
    if(islog())
    {
    logger.file<<"ini values from ";
    logger.file<<" ini file : <"<<mainopt.inifilename<<">"<<endl;
	logger.file<<"\ntablehash   "<<mainopt.tablesize<<" MB" ;
	logger.file<<"\nbookfile   "<<mainopt.bookfile<<" MB" ;
	logger.file<<"\nuse book "<<mainopt.bookon;
	logger.file<<"\nuse log "<<mainopt.logon;
    logger.file<<endl;
    logger.file.flush();
    }
}

void readini()
{
    string line;
    vector<string> inilines;
    inilines.clear();
    ifstream file (mainopt.inifilename.c_str());

    if(!file)
    {
        return;
    }

#ifdef DEBUG
    cout<<"\n reading ini file "<<mainopt.inifilename<<endl;
#endif


    if (file.is_open())
    {
      while (! file.eof() )
      {
       getline (file,line);
       inilines.push_back(line);
      }
      if(inilines.size())
      {
      processini(inilines);
       showinivals();
      }
    }

    file.close();

    return;
}



void init_all()
{
    init_magic();
    logstart();
    init_bitboards();
    init_attack_tables();
    search_init_opt();
    tester_init();
	init_mainopt();
	eval_init();
	readini();
	loginit();//defualt on
	showinivals();
	if(mainopt.bookon)
	bookread.read_into_store();
	makenewtable(mainopt.tablesize); //default 32MB hash
}



