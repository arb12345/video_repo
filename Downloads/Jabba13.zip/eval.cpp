#include <iostream>
#include <string>
#include <math.h>
#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "log.h"
#include "board.h"
#include "evalparam.h"
#include "fen.h"

//7k/5K2/6P1/8/8/4n3/8/8 w - -
//#define SPEAK
//-mirror -i mirror.epd

sEval scorer[1];
int safety_table[15];

void eval_init()
{
    init_distance();
    eval_init_opt();
    init_eval_param();
    init_psqt();

    //must come after the above
    safety_table_init();
}

void safety_table_init()
{
  uint i;
  for(i = 0; i < 16; ++i)
  {
   if(i==1)safety_table[i] = tropNBRQ;
   else if(i==2)safety_table[i] = tropBRQ;
   else if(i==3)safety_table[i] = tropNRQ;
   else if(i==4)safety_table[i] = tropRQ;
   else if(i==5)safety_table[i] = tropNBQ;
   else if(i==6)safety_table[i] = tropBQ;
   else if(i==7)safety_table[i] = tropNQ;
   else if(i==8)safety_table[i] = tropQ;
   else if(i==9)safety_table[i] = tropNBR;
   else if(i==10)safety_table[i] = tropBR;
   else if(i==11)safety_table[i] = tropNR;
   else if(i==12)safety_table[i] = tropR;
   else if(i==13)safety_table[i] = tropNB;
   else if(i==14)safety_table[i] = tropB;
   else if(i==15)safety_table[i] = tropN;
  }

}


void init_distance()
{
     memset(scorer->distance, 0, sizeof(scorer->distance));
     int ri, rj, fi, fj;
     for (uint i = 0; i < BRDSQ; ++i)//first loop, square 1
     {
         ri = RANK(i);
         fi = FILE(i);
         for (uint j = 0; j < BRDSQ; ++j)//second loop, sqaure 2
         {
          rj = RANK(j);
          fj = FILE(j);

          scorer->distance[i][j] = (abs(ri-rj) > abs(fi-fj))? abs(ri-rj) : abs(fi-fj);
         }
     }
}

void eval_init_opt()
{
   scorer->opt->psqt = true;
   scorer->opt->pawns = true;
   scorer->opt->bishops = true;
   scorer->opt->rooks = true;
   scorer->opt->queens = true;
   scorer->opt->knights = true;
   scorer->opt->blocked = true;
   scorer->opt->development = true;
   scorer->opt->balance = true;
   scorer->counter = 0;
}


void reset_all_arrays()
{
    uint i;
	i=cW;
	scorer->pawnfiles[i]=0;
	scorer->pawns[i][OPE]=scorer->mob[i][OPE]=scorer->dev[i][OPE]=0;
	scorer->blo[i][OPE]=scorer->pos[i][OPE]=scorer->bal[i][OPE]=scorer->psq[i][OPE]=0;
	scorer->pawns[i][END]=scorer->mob[i][END]=scorer->dev[i][END]=0;
	scorer->blo[i][END]=scorer->pos[i][END]=scorer->bal[i][END]=scorer->psq[i][END]=0;
    scorer->passer[i][OPE]=0;
	scorer->passer[i][END]=0;
    scorer->mat[i][OPE]=0;
	scorer->mat[i][END]=0;
	scorer->safe[i]=0;


	i=cB;
    scorer->pawnfiles[i]=0;
	scorer->pawns[i][OPE]=scorer->mob[i][OPE]=scorer->dev[i][OPE]=0;
	scorer->blo[i][OPE]=scorer->pos[i][OPE]=scorer->bal[i][OPE]=scorer->psq[i][OPE]=0;
	scorer->pawns[i][END]=scorer->mob[i][END]=scorer->dev[i][END]=0;
	scorer->blo[i][END]=scorer->pos[i][END]=scorer->bal[i][END]=scorer->psq[i][END]=0;
    scorer->passer[i][OPE]=0;
	scorer->passer[i][END]=0;
    scorer->mat[i][OPE]=0;
	scorer->mat[i][END]=0;
	scorer->safe[i]=0;

    scorer->drawflag = false;

    scorer->wp = PCENUM(pwP); 
	scorer->wq = PCENUM(pwQ); scorer->mat[cW][OPE] += Qmato; scorer->mat[cW][END] += Qmate;
    scorer->wr = PCENUM(pwR);
    scorer->wb = PCENUM(pwB);
    scorer->wn = PCENUM(pwN);
    scorer->bp = PCENUM(pbP);
    scorer->bq = PCENUM(pbQ); scorer->mat[cB][OPE] += Qmato; scorer->mat[cB][END] += Qmate;
    scorer->br = PCENUM(pbR);
    scorer->bb = PCENUM(pbB);
    scorer->bn = PCENUM(pbN);

    scorer->useWsafety = true;
    scorer->useBsafety = true;
    /*
    if(scorer->bq!=0 && (BIG(cB) > 2)) scorer->useWsafety = true; else scorer->useWsafety = false;
    if(scorer->wq!=0 && (BIG(cW) > 2)) scorer->useBsafety = true; else scorer->useBsafety = false;
    */

    scorer->wkcircle = king_circle[SQTO64(KINGSQ(cW))];
    scorer->bkcircle = king_circle[SQTO64(KINGSQ(cB))];

    scorer->wkatt=scorer->wkdef=scorer->bkatt=scorer->bkdef=0;

}

int lazyeval()
{
    int material = TOTMAT;
	int phase = TotalPhase;
	int s;

   phase -= scorer->wp * PawnPhase;
   phase -= scorer->wn * KnightPhase;
   phase -= scorer->wb * BishopPhase;
   phase -= scorer->wr * RookPhase;
   phase -= scorer->wq * QueenPhase;
   phase -= scorer->bp * PawnPhase;
   phase -= scorer->bn * KnightPhase;
   phase -= scorer->bb * BishopPhase;
   phase -= scorer->br * RookPhase;
   phase -= scorer->bq * QueenPhase;

   int send =  scorer->psq[cW][END] -  scorer->psq[cB][END] + material;
   int sbeg = scorer->psq[cW][OPE] -  scorer->psq[cB][OPE] + material;

   if (phase < 0) phase = 0;
   phase = (phase * 256 + (TotalPhase / 2)) / TotalPhase;
   s = ((sbeg * (256 - phase)) + (send * phase)) / 256;

   if(SIDENOW==cW) s += 10;
   else s -= 10;

	return (SIDENOW==cW) ? s : -s;
}


void score_development()
{
    int soon = 0;
    if(BRDPCE(C1) == pwB) { scorer->dev[cW][OPE] -= minordev; soon++; }
    if(BRDPCE(F1) == pwB) { scorer->dev[cW][OPE] -= minordev; soon++; }
    if(BRDPCE(G1) == pwN) { scorer->dev[cW][OPE] -= minordev; soon++; }
    if(BRDPCE(B1) == pwN) { scorer->dev[cW][OPE] -= minordev; soon++; }

    //now penalty for queen moving too soon
    if(BRDPCE(D1) != pwQ)  { scorer->dev[cW][OPE] -= majorsoon*soon;}

    soon=0;
    if(BRDPCE(C8) == pbB) { scorer->dev[cB][OPE] -= minordev; soon++; }
    if(BRDPCE(F8) == pbB) { scorer->dev[cB][OPE] -= minordev; soon++; }
    if(BRDPCE(G8) == pbN) { scorer->dev[cB][OPE] -= minordev; soon++; }
    if(BRDPCE(B8) == pbN) { scorer->dev[cB][OPE] -= minordev; soon++; }

    //now penalty for queen moving too soon
    if(BRDPCE(D8) != pbQ)  { scorer->dev[cB][OPE]-= majorsoon*soon; }
}

void score_blocked()
{
	//trapped Bishop
	if(BRDPCE(A7)==pwB && BRDPCE(B6)==pbP) { scorer->blo[cW][OPE] -= trB; }
	if(BRDPCE(H7)==pwB && BRDPCE(G6)==pbP) { scorer->blo[cW][OPE] -= trB; }
	if(BRDPCE(A6)==pwB && BRDPCE(B5)==pbP) { scorer->blo[cW][OPE] -= trB; }
	if(BRDPCE(H6)==pwB && BRDPCE(G5)==pbP) { scorer->blo[cW][OPE] -= trB; }
	if(BRDPCE(A2)==pbB && BRDPCE(B3)==pwP) { scorer->blo[cB][OPE] -= trB; }
	if(BRDPCE(H2)==pbB && BRDPCE(G3)==pwP) { scorer->blo[cB][OPE] -= trB; }
	if(BRDPCE(A3)==pbB && BRDPCE(B4)==pwP) { scorer->blo[cB][OPE] -= trB; }
	if(BRDPCE(H3)==pbB && BRDPCE(G4)==pwP) { scorer->blo[cB][OPE] -= trB; }

	if((BRDPCE(C1) == pwK || BRDPCE(B1) == pwK) && (BRDPCE(A1) == pwR || BRDPCE(B1) == pwR)) { scorer->blo[cW][OPE] -= trR; }
    if((BRDPCE(F1) == pwK || BRDPCE(G1) == pwK) && (BRDPCE(H1) == pwR || BRDPCE(G1) == pwR)) { scorer->blo[cW][OPE] -= trR; }
    if((BRDPCE(C8) == pbK || BRDPCE(B8) == pbK) && (BRDPCE(A8) == pbR || BRDPCE(B8) == pbR)) { scorer->blo[cB][OPE] -= trR; }
    if((BRDPCE(F8) == pbK || BRDPCE(G8) == pbK) && (BRDPCE(H8) == pbR || BRDPCE(G8) == pbR)) { scorer->blo[cB][OPE] -= trR; }

	//minors blocking centre pawns...
	if(BRDPCE(D2)==pwP && (BRDPCE(D3)==pwB || BRDPCE(D3)==pwN)) { scorer->blo[cW][OPE] -= trP; }
	if(BRDPCE(E2)==pwP && (BRDPCE(E3)==pwB || BRDPCE(E3)==pwN)) { scorer->blo[cW][OPE] -= trP; }
	if(BRDPCE(D7)==pbP && (BRDPCE(D6)==pbB || BRDPCE(D6)==pbN)) { scorer->blo[cB][OPE] -= trP; }
	if(BRDPCE(E7)==pbP && (BRDPCE(E6)==pbB || BRDPCE(E6)==pbN)) { scorer->blo[cB][OPE] -= trP; }
}


void score_psq()
{
    scorer->psq[cW][OPE] = PSQOPE(cW);
    scorer->psq[cW][END] = PSQEND(cW);
    scorer->psq[cB][OPE] = PSQOPE(cB);
    scorer->psq[cB][END] = PSQEND(cB);
}

int eval()
{
    reset_all_arrays();


#ifdef SPEAK
printboard();
#endif

        balance();
        if(scorer->drawflag)
        {
            //brd.printboard();
			//system("PAUSE");
			return 0;
        }
    //the ordering here is important - the king attacks are filled before calling score_kings()
    score_psq();
    score_pawn();
    score_rooks();
    score_bishops();
    score_knights();
    score_queens();
    score_kings();
    score_blocked();
    score_development();

    int material = TOTMAT;

   // cout<<"\n after loop scorer->psq[cW][OPE] "<<scorer->psq[cW][OPE];

    int send = scorer->pawns[cW][END] -  scorer->pawns[cB][END]+
			   scorer->mob[cW][END]   -  scorer->mob[cB][END]+
			   scorer->dev[cW][END]   -  scorer->dev[cB][END]+
			   scorer->blo[cW][END]   -  scorer->blo[cB][END]+
			   scorer->pos[cW][END]   -  scorer->pos[cB][END]+
			   scorer->psq[cW][END]   -  scorer->psq[cB][END]+
               scorer->bal[cW][END]   -  scorer->bal[cB][END]+
			   scorer->passer[cW][END]   -  scorer->passer[cB][END]+
			   scorer->mat[cW][END]   -  scorer->mat[cB][END]+
			   material;
    int sbeg = scorer->pawns[cW][OPE] -  scorer->pawns[cB][OPE]+
			   scorer->mob[cW][OPE]   -  scorer->mob[cB][OPE]+
			   scorer->dev[cW][OPE]   -  scorer->dev[cB][OPE]+
			   scorer->blo[cW][OPE]   -  scorer->blo[cB][OPE]+
			   scorer->pos[cW][OPE]   -  scorer->pos[cB][OPE]+
			   scorer->psq[cW][OPE]   -  scorer->psq[cB][OPE]+
			   scorer->bal[cW][END]   -  scorer->bal[cB][END]+
			   scorer->passer[cW][OPE]   -  scorer->passer[cB][OPE]+
			   scorer->safe[cW]       -  scorer->safe[cB]+
			   scorer->mat[cW]       -  scorer->mat[cB]+
			   material;


   int phase = TotalPhase;

   phase -= scorer->wp * PawnPhase;
   phase -= scorer->wn * KnightPhase;
   phase -= scorer->wb * BishopPhase;
   phase -= scorer->wr * RookPhase;
   phase -= scorer->wq * QueenPhase;
   phase -= scorer->bp * PawnPhase;
   phase -= scorer->bn * KnightPhase;
   phase -= scorer->bb * BishopPhase;
   phase -= scorer->br * RookPhase;
   phase -= scorer->bq * QueenPhase;

   if (phase < 0) phase = 0;
   phase = (phase * 256 + (TotalPhase / 2)) / TotalPhase;
   int s = ((sbeg * (256 - phase)) + (send * phase)) / 256;

   if(SIDENOW==cW) s += 10;
   else s -= 10;

//#define SPEAK

#ifdef SPEAK
printboard();

	cout<<"\n phase = "<<phase;
	cout<<"\n sbeg = "<<sbeg;
	cout<<" send = "<<send;
	cout<<" score = "<<s;
	cout<<"\n scorer->psq[cW][OPE] = "<<scorer->psq[cW][OPE]<<" scorer->psq[cB][OPE] = "<<scorer->psq[cB][OPE];
	cout<<"\n scorer->psq[cW][END] = "<<scorer->psq[cW][END]<<" scorer->psq[cB][END] = "<<scorer->psq[cB][END];

	cout<<"\n scorer->pawns[cW][OPE] = "<<scorer->pawns[cW][OPE]<<" scorer->pawns[cB][OPE] = "<<scorer->pawns[cB][OPE];
	cout<<"\n scorer->pawns[cW][END] = "<<scorer->pawns[cW][END]<<" scorer->pawns[cB][END] = "<<scorer->pawns[cB][END];

	cout<<"\n scorer->passercW][OPE] = "<<scorer->passer[cW][OPE]<<" scorer->passer[cB][OPE] = "<<scorer->passer[cB][OPE];
	cout<<"\n scorer->passer[cW][END] = "<<scorer->passer[cW][END]<<" scorer->passer[cB][END] = "<<scorer->passer[cB][END];

	cout<<"\n scorer->mob[cW][OPE] = "<<scorer->mob[cW][OPE]<<" scorer->mob[cB][OPE] = "<<scorer->mob[cB][OPE];
	cout<<"\n scorer->mob[cW][END] = "<<scorer->mob[cW][END]<<" scorer->mob[cB][END] = "<<scorer->mob[cB][END];

	cout<<"\n scorer->dev[cW][OPE] = "<<scorer->dev[cW][OPE]<<" scorer->dev[cB][OPE] = "<<scorer->dev[cB][OPE];
	cout<<"\n scorer->dev[cW][END] = "<<scorer->dev[cW][END]<<" scorer->dev[cB][END] = "<<scorer->dev[cB][END];

	cout<<"\n scorer->blo[cW][OPE] = "<<scorer->blo[cW][OPE]<<" scorer->blo[cB][OPE] = "<<scorer->blo[cB][OPE];
	cout<<"\n scorer->blo[cW][END] = "<<scorer->blo[cW][END]<<" scorer->blo[cB][END] = "<<scorer->blo[cB][END];

	cout<<"\n scorer->pos[cW][OPE] = "<<scorer->pos[cW][OPE]<<" scorer->pos[cB][OPE] = "<<scorer->pos[cB][OPE];
	cout<<"\n scorer->pos[cW][END] = "<<scorer->pos[cW][END]<<" scorer->pos[cB][END] = "<<scorer->pos[cB][END];

	cout<<"\n scorer->bal[cW][OPE] = "<<scorer->bal[cW][OPE]<<" scorer->bal[cB][OPE] = "<<scorer->bal[cB][OPE];
	cout<<"\n scorer->bal[cW][END] = "<<scorer->bal[cW][END]<<" scorer->bal[cB][END] = "<<scorer->bal[cB][END];

	cout<<"\n scorer->safe[cW] = "<<scorer->safe[cW]<<" scorer->safe[cB] = "<<scorer->safe[cB];

	cout<<"\n material "<<material;
	cout<<"\n \n FINAL SCORE:: ";
#endif

	return (SIDENOW==cW) ? s : -s;
}

void logeval()
{
    if(!islog()) return;

    int material = TOTMAT;

    int phase = TotalPhase;

   phase -= scorer->wp * PawnPhase;
   phase -= scorer->wn * KnightPhase;
   phase -= scorer->wb * BishopPhase;
   phase -= scorer->wr * RookPhase;
   phase -= scorer->wq * QueenPhase;
   phase -= scorer->bp * PawnPhase;
   phase -= scorer->bn * KnightPhase;
   phase -= scorer->bb * BishopPhase;
   phase -= scorer->br * RookPhase;
   phase -= scorer->bq * QueenPhase;

   if (phase < 0) phase = 0;
   phase = (phase * 256 + (TotalPhase / 2)) / TotalPhase;


   int s = eval();

    logger.file<<"static eval ("<<s<<")";
    logger.file<<"positional score ("<<s-(TOTMAT)<<")\n";

    if(scorer->drawflag) {logger.file<<"material drawflag set, returned score 0\n"; return;}
    logger.file<<" phase = "<<phase;
	logger.file<<"\n scorer->psq[cW][OPE] = "<<scorer->psq[cW][OPE]<<" scorer->psq[cB][OPE] = "<<scorer->psq[cB][OPE];
	logger.file<<"\n scorer->psq[cW][END] = "<<scorer->psq[cW][END]<<" scorer->psq[cB][END] = "<<scorer->psq[cB][END];

	logger.file<<"\n scorer->pawns[cW][OPE] = "<<scorer->pawns[cW][OPE]<<" scorer->pawns[cB][OPE] = "<<scorer->pawns[cB][OPE];
	logger.file<<"\n scorer->pawns[cW][END] = "<<scorer->pawns[cW][END]<<" scorer->pawns[cB][END] = "<<scorer->pawns[cB][END];

	logger.file<<"\n scorer->passer[cW][OPE] = "<<scorer->passer[cW][OPE]<<" scorer->passer[cB][OPE] = "<<scorer->passer[cB][OPE];
	logger.file<<"\n scorer->passer[cW][END] = "<<scorer->passer[cW][END]<<" scorer->passer[cB][END] = "<<scorer->passer[cB][END];

	logger.file<<"\n scorer->mob[cW][OPE] = "<<scorer->mob[cW][OPE]<<" scorer->mob[cB][OPE] = "<<scorer->mob[cB][OPE];
	logger.file<<"\n scorer->mob[cW][END] = "<<scorer->mob[cW][END]<<" scorer->mob[cB][END] = "<<scorer->mob[cB][END];

	logger.file<<"\n scorer->dev[cW][OPE] = "<<scorer->dev[cW][OPE]<<" scorer->dev[cB][OPE] = "<<scorer->dev[cB][OPE];
	logger.file<<"\n scorer->dev[cW][END] = "<<scorer->dev[cW][END]<<" scorer->dev[cB][END] = "<<scorer->dev[cB][END];

	logger.file<<"\n scorer->blo[cW][OPE] = "<<scorer->blo[cW][OPE]<<" scorer->blo[cB][OPE] = "<<scorer->blo[cB][OPE];
	logger.file<<"\n scorer->blo[cW][END] = "<<scorer->blo[cW][END]<<" scorer->blo[cB][END] = "<<scorer->blo[cB][END];

	logger.file<<"\n scorer->pos[cW][OPE] = "<<scorer->pos[cW][OPE]<<" scorer->pos[cB][OPE] = "<<scorer->pos[cB][OPE];
	logger.file<<"\n scorer->pos[cW][END] = "<<scorer->pos[cW][END]<<" scorer->pos[cB][END] = "<<scorer->pos[cB][END];

	logger.file<<"\n scorer->bal[cW][OPE] = "<<scorer->bal[cW][OPE]<<" scorer->bal[cB][OPE] = "<<scorer->bal[cB][OPE];
	logger.file<<"\n scorer->bal[cW][END] = "<<scorer->bal[cW][END]<<" scorer->bal[cB][END] = "<<scorer->bal[cB][END];

	logger.file<<"\n scorer->safe[cW] = "<<scorer->safe[cW]<<" scorer->safe[cB] = "<<scorer->safe[cB];

	logger.file<<"\n material "<<material;
	logger.file<<" (white = "<<MATERIAL(cW)<<") (black = "<<MATERIAL(cB)<<")\n";


	logger.file.flush();
}


