#include <iostream>
#include <cstdio>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <sys/timeb.h>


#include "utils.h"
#include "defs.h"


using namespace std;

void stringsplitter(const string &input, char delim, vector<string> &split)
{
    string temp;
    uint index;

    for(index = 0; index < input.length(); ++index)
    {
        if(input[index] != delim)
        {
            temp += input[index];
        }
        else
        {
         split.push_back(temp);
         temp.clear();
        }
    }
    split.push_back(temp);
}


//convert a string int to an int
int strtoint(string str, int pos)
{
   int valme;
   str.erase(0, pos);
   istringstream iss(str);
   iss >> valme;

   return valme;
}


//convert a string uint to a uint
uint strtouint(string str, int pos)
{
   uint valme;
   str.erase(0, pos);
   istringstream iss(str);
   iss >> valme;

   return valme;
}


//convert a string int to an int
double strtodbl(string str, int pos)
{
   double valme;
   str.erase(0, pos);
   istringstream iss(str);
   iss >> valme;

   return valme;
}

//look for word "word" in "input" - return true if found, pass postion by reference
bool findsubstr(string word, string input, int &pos)
{
	pos = input.find(word);
	if(pos!=-1) return true;

	return false;
}


/*
return the position at the end of a string we find
e.g pawn = 67, if we llok for "pawn = ", pos will be set to the position of the last character
*/
bool findsubstrend(string word, string input, int &pos)
{
    pos = input.find(word);
	if(pos!=-1)
	{
	    pos += word.length();
	    return true;
	}
	return false;
}

double percent(int tester, int all)
{
    double t = double(tester);
    double a = double(all);

    if(t==0 || all==0) return 0;
    else return (t/a)*100;
}

//replacing the past use of the clock() function, due to portability
#include <sys/timeb.h>
uint myclock()
{
	timeb readtime;
	ftime(&readtime);
	return (readtime.time * 1000) + readtime.millitm;
}


