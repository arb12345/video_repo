#include <iostream>
#include <ctime>

#include "clock.h"
#include "piecedefs.h"
#include "defs.h"
#include "log.h"
#include "searcher.h"


using namespace std;

sClock timer[1];

const uint maxtime = 0xffffff;

void resettimeparam(const uint col)
{
      timer->movetime[col] = 0;
      timer->sessiontime[col] = 0;
	  timer->inc[col] = 0;
      timer->movestogo[col] = 0;
	  timer->depth = maxply;
	  timer->timepermove = 0;
	  timer->starttime = 0;
	  timer->stoptime = 0;
	  timer->alloctime = 0;

      timer->modetimepermove = false;
      timer->modemovestogo = false;
      timer->movespersession = 0;
      timer->depthlimit = false;
}


void allocatemovetime(const uint col, const uint status)
{
   // cout<<"\nallocate time mode = "<<status<<endl;
    if (status & smPONDER || status & smINFINITE )
    {
        timer->alloctime = maxtime;
        timer->depth = maxply;
        if(islog() && !tree->param->tuning)
        logger.file << "allocating ininfinte time control\n";
        return;
    }
    else if(timer->depthlimit==true)
    {
        timer->alloctime = maxtime;
        if(islog() && !tree->param->tuning)
        logger.file << "allocating maxtime due to depth limited game\n";
        return;
    }
    else if (timer->timepermove!=0)
    {
        timer->alloctime = timer->timepermove - 50;
        if(islog() && !tree->param->tuning)
        logger.file << "allocating time per move control\n";
        return;
    }
    else
    {
       if (GETMTG(col)!=0)//given moves to next time control
       {
          timer->alloctime =  ( (timer->movetime[col] + (timer->inc[col]*timer->movestogo[col]) )/timer->movestogo[col]+1)-50;
          if(islog())
          logger.file << "allocating moves to go time control\n";
          return;
       }
       else
       {
         timer->alloctime = timer->movetime[col]/30;
         if(islog())
         {
             logger.file << "allocating general time left control\n";
             logger.file << " using "<<timer->movetime[col]<<" as time ";
         }
         return;
       }
    }
    if(islog())  logger.file << "time allocation error";
}

void startsearchtimer(const uint side, const uint mode, const bool ponderhit)
{
   allocatemovetime(side,mode);
   if(islog() && !tree->param->tuning)logger.file << "allocated "<<timer->alloctime<<"ms for the move\n";

   if(mode==smPONDERHIT) adjustforphit();

   timer->starttime = myclock();
   timer->stoptime = timer->starttime+timer->alloctime;

   ASS(timer->stoptime  > timer->starttime);

   if(timer->depth>maxply) timer->depth=maxply;

   if(islog() && !tree->param->tuning) logger.file << "starting timer starttime "<<
   timer->starttime<<" movetime "<<
   timer->alloctime<<" stoptime "<<
   timer->stoptime<<" depth "<<
   timer->depth;
}

void adjustforphit()
{
    ASS(timer->alloctime>0);
    ASS(timer->pondertime>0);

    if(islog())
    logger.file<<"adjusting time for phit ";

	cout<<"adjusting time for phit ";

    uint timetoadd = timer->alloctime*125/100;
	uint timermin = ((timetoadd/16) < 50) ? 50 : timetoadd/16;

    if(islog()){logger.file<<" alloctime = "<<timer->alloctime;
    logger.file<<" 25% more "<<timetoadd-timer->alloctime<<endl;
    logger.file<<"had been pondering for "<<timer->pondertime;}

	cout<<" alloctime = "<<timer->alloctime;
   cout<<" 25% more "<<timetoadd-timer->alloctime<<endl;
    cout<<"had been pondering for "<<timer->pondertime;

    if(timetoadd > timer->pondertime) timer->alloctime = timermin;
	else timer->alloctime = timetoadd-timer->pondertime;

    if(islog())logger.file<<" new alloctime "<<timetoadd<<endl;

    cout<<" new alloctime "<<timetoadd<<endl;
}
