#ifndef TESTERS_H
#define TESTERS_H

#include <fstream>
#include <string.h>

#include "defs.h"
#include "searcher.h"

using namespace std;

struct cTester {
    ofstream ofile;
    ifstream ifile;
    string outputfilename;
    string inputfilename;
    uint timeperposition;
    int depthset;
};

extern cTester tester;

extern void tester_init();
extern void evalmirror();
extern void benchmark();
extern void epdtest();
extern void features();


#endif

