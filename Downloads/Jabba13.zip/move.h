#ifndef MOVE_H
#define MOVE_H

#include "defs.h"
#include "board.h"
#include "material.h"
#include "movelist.h"
#include "history.h"


using namespace std;


extern string printmove(uint move);
extern void printmovelong(uint move);
extern string movetosan(uint move);
extern uint santomove(const string sanmove);
extern bool cancutmove(uint move);
extern int materialgainmove(uint move);

inline bool moveiscastle(uint &side, uint &move)
{
    uint from = FROM(move);
    uint to = TO(move);
    uint piece = BRDPCE(from);

    ASS(onbrd(from));
    ASS(onbrd(to));
    ASS(piecegood(piece));
    ASS(side==cW||side==cB);

    if(side==cW && piece==pwK && from ==E1)
    {
        if(to==G1 || to==C1) return true;
    }
    else if(side==cB && piece==pbK && from ==E8)
     {
        if(to==G8 || to==C8) return true;
    }

    return false;
}

inline bool moveiscapture(uint move)
{
    if(CAP(move)!=0) return true;
    if(FLAG(move)==FlagEP) return true;

    return false;
}



#endif
