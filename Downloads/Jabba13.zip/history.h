#ifndef HISTORY_H
#define HISTORY_H

#include "defs.h"

//longest ever recorded game is 269 moves - 1024 half moves should then be safe!!


struct sRecord {

       uint move;
       uint captured;
       uint castle;
       uint enpas;
       uint fifty;
       u64  key;
       u64  pawnkey;
};

struct sHistory {

        sRecord hisarray[maxgamelength];
        uint gamemoves;
};


extern sHistory his[1];

extern void clearhistory();
extern void printallhistory();
extern void logallhistory();
extern void printonehistory(const uint index);
extern uint lastmovemade();


#define GAMEMOVES  (his->gamemoves)
#define INCRGAMEMOVES (his->gamemoves++)
#define DECRGAMEMOVES (his->gamemoves--)
#define HISMOVE(i) (his->hisarray[(i)].move)
#define HISKEY(i) (his->hisarray[(i)].key)
#define HISPKEY(i) (his->hisarray[(i)].pawnkey)
#define HISCASTLE(i) (his->hisarray[(i)].castle)
#define HISENPAS(i) (his->hisarray[(i)].enpas)
#define HISFIFTY(i) (his->hisarray[(i)].fifty)
#define HISCAPTURE(i) (his->hisarray[(i)].captured)

inline bool findrepetition(const u64 &findme)
{
uint index;
     for(index = 0; index < GAMEMOVES; ++index)
     {
        if(  HISKEY(index) == findme) return true;
     }
     return false;
}

inline uint countrepetition(const u64 &findme)
{
     uint index,rep=0;
     for(index = 0; index < GAMEMOVES; ++index)
     {
        if(  HISKEY(index) == findme) rep++;;
     }
     return rep;
}




#endif
