#include <iostream>
#include <string>
#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "evalparam.h"

using namespace std;

//#define SPEAK

void score_pawn()
{
	uint sq64=0,sq128=0,rank=0;
	bool back = false;
	bool iso = false;
	bool passed = false;
	bool doubled = false;
	bool open = false;
	bool can = false;
    uint bkingfile,wkingfile;
    uint wks,bks;
    uint wpf,bpf;
    bool qsvsks = false; //wk on qs vs bk on ks
    bool ksvsqs = false; //wk on ks vs bk on qs
	u64 occ,allocc;

	uint revsq64,revsq;


	uint distp=0;
	uint distk=0;
	uint side = SIDENOW;

    allocc = P_BB(cW)|P_BB(cB);
    occ = P_BB(cW);

    wks = KINGSQ(cW);
    bks = KINGSQ(cB);

    wkingfile = files[wks];
    bkingfile = files[bks];

    if(wkingfile < FILED && bkingfile > FILEE) qsvsks = true;
    if(wkingfile > FILEE && bkingfile < FILED) ksvsqs = true;

    /* cout<<"\n in eval, wocc \n";
    printbitboard(occ);*/

	while(occ)
	{
		sq64 = POP(occ);
		sq128 = SQFROM64(sq64);
		ASS(sq64>=0&&sq64<64);
		ASS(onbrd(sq128));

		wpf = files[sq128];

		/** Special Test Code make pawn END value back up to PAWNBASE**/
		//scorer->pawns[cW][END] += 20;

		/*cout<<"\n W on "<<printsquare(sq128);
		cout<<" sq64 "<<sq64;*/

		back = false;
		iso = false;
		passed = false;
		doubled = false;
		open = false;
		can = false;

		if(isfilesouth[sq64] & P_BB(cW)) doubled = true;

		if(!(isfilenorth[sq64] & allocc))
		{
			open=true;
		}

		if(!(isisolated[sq64] & P_BB(cW)))
		{
			iso=true;
		}
		else if(!(whitebackward[sq64] & P_BB(cW)))
		{
			back=true;
		}

		if(!(whitepassed[sq64] & P_BB(cB)))
		{
		    passed = true;
		}
		else if(open)
		{
			can = whitecandidate(P_BB(cW),P_BB(cB),sq128,sq64);
		}

#ifdef SPEAK
		string ws = printsquare(sq128);
		cout<<"\n wP "<<ws;
		if(open) cout<<" open ";
		if(doubled) cout<<" doubled ";
		if(iso) cout<<" iso ";
		if(passed) cout<<" passed ";
		if(can)cout<<" can ";
#endif

	    rank = ranks[sq128];
	    ASS(rank>=RANK1&&rank<=RANK8);
		if(doubled)
		{
            if(open)
            {
             scorer->pawns[cW][OPE] -= PDouOpeWk;
			 scorer->pawns[cW][END] -= PDouEndWk;
            }
            else
            {
             scorer->pawns[cW][OPE] -= PDouOpe;
			 scorer->pawns[cW][END] -= PDouEnd;
            }
#ifdef SPEAK
		cout<<"\n wP doubled";
#endif
		}

		if(iso)
		{
			if(open)
			{
			 scorer->pawns[cW][OPE] -= PIsoOpeWk;
			 scorer->pawns[cW][END] -= PIsoEndWk;
			}
			else
			{
			 scorer->pawns[cW][OPE] -= PIsoOpe;
			 scorer->pawns[cW][END] -= PIsoEnd;
			}
#ifdef SPEAK
		cout<<"\n wP pisolated";
#endif
		}
		else if(back)
		{
			scorer->pawns[cW][OPE] -= PBacOpe;
			scorer->pawns[cW][END] -= PBacEnd;
		}

		if(passed)
		{
			scorer->passer[cW][OPE] += PPasOpe*rank;
			scorer->passer[cW][END] += PPasEnd*rank;
			if(P_BB(cW) & whitepawnconnect[sq64])
			{
				scorer->passer[cW][OPE] += PPasConOpe*rank;
     			scorer->passer[cW][END] += PPasConEnd*rank;
			}

			if(BIG(cB) == 0)
			{
			    uint promote = promsq[cW][wpf];
			    distp = scorer->distance[sq128][promote];
			    distk = scorer->distance[bks][promote];
			    if(side==cB) distk--;

			    if(distp<distk) scorer->passer[cW][END] += vQ-vP;
			}

			//rook support in endgame
			if(scorer->wr != 0 && RANK(sq128) > RANK3)
			{
				u64 rookbb = R_BB(cW);
				uint rooksq;
				while(rookbb)
				{
					rooksq = POP64(rookbb);
					if(FILE(rooksq)==wpf && RANK(rooksq)<RANK(sq128))
					{
						scorer->passer[cW][END] += PPasRookEnd*rank;
					}
				}
			}

		}
		else if(can)
		{
            scorer->passer[cW][OPE] += PCanOpe*rank;
     		scorer->passer[cW][END] += PCanEnd*rank;
		}

	}

    occ = P_BB(cB);

  /*  cout<<"\n in eval, bocc \n";
    printbitboard(occ);*/

	while(occ)
	{
		sq64 = POP(occ);
		sq128 = SQFROM64(sq64);
		revsq = SQREV(sq128);
        revsq64 = SQTO64(revsq);
		ASS(sq64>=0&&sq64<64);
		ASS(onbrd(sq128));

		bpf = files[sq128];

		/** Special Test Code make pawn END value back up to PAWNBASE**/
		//scorer->pawns[cB][END] += 20;


		/*cout<<"\n Bp on "<<printsquare(sq128);
		cout<<" revsq "<<revsq64;
		cout<<" revsq64 "<<revsq64;*/

		iso = false;
		passed = false;
		doubled = false;
		open = false;
		can = false;
		back=false;

		if(isfilenorth[sq64] & P_BB(cB)) doubled = true;

		if(!(isfilesouth[sq64] & allocc))
		{
			open=true;
		}

		if(!(isisolated[sq64] & P_BB(cB)))
		{
			iso=true;
		}
		else if(!(blackbackward[sq64] & P_BB(cB)))
		{
			back=true;
		}

		if(!(blackpassed[sq64] & P_BB(cW)))
		{
		    passed = true;
		}
		else if(open)
		{
			can = blackcandidate(P_BB(cW),P_BB(cB),sq128,sq64);
		}

#ifdef SPEAK
		string bs = printsquare(sq128);
		cout<<"\n bP "<<bs;
		if(open) cout<<" open ";
		if(doubled) cout<<" doubled ";
		if(iso) cout<<" iso ";
		if(passed) cout<<" passed ";
		if(can)cout<<" can ";
#endif
		rank = ranks[sq128];
		if(doubled)
		{
			if(open)
			{
			 scorer->pawns[cB][OPE] -= PDouOpeWk;
			 scorer->pawns[cB][END] -= PDouOpeWk;
			}
			else
			{
			 scorer->pawns[cB][OPE] -= PDouOpe;
			 scorer->pawns[cB][END] -= PDouOpe;
			}
#ifdef SPEAK
		cout<<"\n bP pdoubled";
#endif
		}

		if(iso)
		{
			if(open)
			{
			 scorer->pawns[cB][OPE] -= PIsoOpeWk;
			 scorer->pawns[cB][END] -= PIsoOpeWk;
			}
			else
			{
			 scorer->pawns[cB][OPE] -= PIsoOpe;
			 scorer->pawns[cB][END] -= PIsoOpe;
			}
#ifdef SPEAK
		cout<<"\n bP pisolated";
#endif
		}
		else if(back)
		{
			scorer->pawns[cB][OPE] -= PBacOpe;
			scorer->pawns[cB][END] -= PBacOpe;
#ifdef SPEAK
		cout<<"\n bP pbackward";
#endif
		}
//rankrev[rank]

		if(passed)
		{
			scorer->passer[cB][OPE] += PPasOpe*rankrev[rank];
			scorer->passer[cB][END] += PPasEnd*rankrev[rank];

			if(P_BB(cB) & blackpawnconnect[sq64])
			{
				scorer->passer[cB][OPE] += PPasConOpe*rankrev[rank];
			    scorer->passer[cB][END] += PPasConEnd*rankrev[rank];
			}

			if(BIG(cW) == 0)
			{
			    uint promote = promsq[cB][bpf];
			    distp = scorer->distance[sq128][promote];
			    distk = scorer->distance[wks][promote];
			    if(side==cW) distk--;

			    if(distp<distk) scorer->passer[cB][END] += vQ-vP;
			}

			if(scorer->br != 0 && RANK(sq128) < RANK6)
			{
				u64 rookbb = R_BB(cB);
				uint rooksq;
				while(rookbb)
				{
					rooksq = POP64(rookbb);
					if(FILE(rooksq)==bpf && RANK(rooksq)>RANK(sq128))
					{
						scorer->passer[cB][END] += PPasRookEnd*rankrev[rank];
					}
				}
			}

		}
		else if(can)
		{
			scorer->passer[cB][OPE] += PCanOpe*rankrev[rank];
			scorer->passer[cB][END] += PCanEnd*rankrev[rank];
		}


	}

}
/*
void cEval::whitepasser(cBoard &brd, cMaterial &mat)
{
    if(
*/

bool whitecandidate(const u64 &wocc, const u64 &bocc, const uint &sq, const uint &sq64)
{
	uint tsq = 0;
	int supporters = 0;
	int attackers = 0;

	//cout<<"\n white candidate "<<printsquare(sq)<<" looping ";
	//first, loop up to count def pawns ahead of our pawn
    for(tsq = sq; ranks[tsq] < RANK7; tsq+=N)
	{
		//cout<<printsquare(tsq)<<" ";
		if(BRDPCE(tsq+NW)==pbP || BRDPCE(tsq+NE)==pbP)
	    break;
	}

	//cout<<"\nfinal tsq "<<printsquare(tsq);

    //tsq now holds the key sq, need to count supporters vs attackers on tsq
	if(BRDPCE(tsq+NW)==pbP) { attackers++; }
	if(BRDPCE(tsq+NE)==pbP) { attackers++; }
    if(BRDPCE(tsq+SW)==pwP) { supporters++; }
    if(BRDPCE(tsq+SE)==pwP) { supporters++; }

	//cout<<"\n total supp = "<<supporters;
    //cout<<"\n total atta = "<<attackers;
	//now see if, when there are no attackers, if we are passed
	if(attackers<=supporters)
	{
		//cout<<"\n could be a candidate, occ before att removed: \n";
		//printbitboard(bocc);
		//printbitboard(clearer[sqto64(tsq+NW)]);
		//printbitboard(clearer[sqto64(tsq+NE)]);
		//cout<<"occ with attackers removed: \n";
		u64 newocc = bocc;
		newocc &= clearer[SQTO64(tsq+NW)];
		newocc &= clearer[SQTO64(tsq+NE)];
		//printbitboard(newocc);
		if(!(whitepassed[sq64] & newocc)) {/*cout<<"\n will be a passer ";*/ return true;}

	//	cout<<"\n not passed when attackers are removed\n";
	}

	//cout<<"\n not enough supporters\n";

	return false;
}


bool blackcandidate(const u64 &wocc, const u64 &bocc, const uint &sq, const uint &sq64)
{
	uint tsq = 0;
	int supporters = 0;
	int attackers = 0;

	//first, loop up to count def pawns ahead of our pawn
    for(tsq = sq; ranks[tsq] > RANK2; tsq+=S)
	{
		if(BRDPCE(tsq+SW)==pwP || BRDPCE(tsq+SE)==pwP)
	    break;
	}

    //tsq now holds the key sq, need to count supporters vs attackers on tsq
	if(BRDPCE(tsq+SW)==pwP) attackers++;
    if(BRDPCE(tsq+SE)==pwP) attackers++;
    if(BRDPCE(tsq+NW)==pbP) supporters++;
    if(BRDPCE(tsq+NE)==pbP) supporters++;

	//now see if, when there are no attackers, if we are passed
	//now see if, when there are no attackers, if we are passed
	if(attackers<=supporters)
	{
		//cout<<"\n could be a candidate, occ before att removed: \n";
		//printbitboard(bocc);
		//printbitboard(clearer[sqto64(tsq+SW)]);
		//printbitboard(clearer[sqto64(tsq+SE)]);
		//cout<<"occ with attackers removed: \n";
		u64 newocc = wocc;
		newocc &= clearer[SQTO64(tsq+SW)];
		newocc &= clearer[SQTO64(tsq+SE)];
		//printbitboard(newocc);
		if(!(blackpassed[sq64] & newocc)) {/*cout<<"\n will be a passer ";*/ return true;}

		//cout<<"\n not passed when attackers are removed\n";
	}

	return false;
}



