#ifndef CLOCK_H
#define CLOCK_H
#include <time.h>
#include "defs.h"
#include "piecedefs.h"
#include "utils.h"


struct sClock {

    bool modetimepermove;
    bool modemovestogo;
    bool depthlimit;

    uint movespersession;

	uint movetime[numcolours];
	uint sessiontime[numcolours];
	uint inc[numcolours];
    uint movestogo[numcolours];
	uint depth; //also gets transferred as search parameter later
	uint timepermove;
	uint starttime;
	uint stoptime;
	uint alloctime;//time allocated for the move
	uint pondertime;//time spent pondering, used for ponderhits

};

extern sClock timer[1];

#define TIMEELAPSED ((myclock())-(timer->starttime))
#define GETPONDERTIME (timer->pondertime)
#define ISMODETPM ( timer->modetimepermove )
#define ISMODEMTG ( timer->modemovestogo )
#define ISMODETDEPTH ( timer->depthlimit )
#define GETMPS ( timer->movespersession )
#define GETMOVETIME(col) (timer->movetime[(col)])
#define GETSESSIONTIME(col) (timer->sessiontime[(col)])
#define GETINCTIME(col) (timer->inc[(col)])
#define GETMTG(col) (timer->movestogo[(col)])
#define GETDEPTH (timer->depth)
#define GETTPM (timer->modetimepermove)
#define GETALLOCTIME (timer->alloctime)
#define GETSTARTTIME (timer->startime)
#define GETSTOPTIME (timer->stoptime)
#define DECRMTG(col) (timer->movestogo[(col)]--)

void startsearchtimer(const uint col, const uint mode, const bool ponderhit);
void adjustforphit();
inline void settimepermove(const uint tpm){ timer->timepermove = tpm;}
inline void setsessiontime(const uint time, const uint col){ timer->sessiontime[col] = time;}
inline void setmovetime(const uint time, const uint col){ timer->movetime[col] = time;}
inline void setinc(const uint time, const uint col){ timer->inc[col] = time;}
inline void setmodetpm(const bool tpm){ timer->modetimepermove = tpm;}
inline void setmodemtg(const bool mtg){ timer->modemovestogo = mtg;}
inline void setmovestogo(const uint moves, const uint col){ timer->movestogo[col] = moves;}
inline void setmodemps(const uint mps){ timer->movespersession = mps;}
inline void setdepthlimit(const bool dl){ timer->depthlimit = dl;}
inline void setdepth(const uint dl){ timer->depth = dl;}
inline void setstoptime(const uint time) { timer->stoptime = time; }
//allocate the time based on the current variabe settings
void allocatemovetime(const uint col, const uint status);
//reset the time variables to start a search
void resettimeparam(const uint col);

inline bool timeup()
{
  if( (myclock()) > GETSTOPTIME)
    {
        return true;
    }
    return false;
}



#endif
