#ifndef ENGINE_H
#define ENGINE_H

#include <string>

#include "defs.h"

using namespace std;

struct SEngineOpt {
    uint engineside;
    uint moves;
    bool ponder;
    bool analyzemode;
    uint variant;//set to 1 fot normal, 2 for FRC
};

extern SEngineOpt engopt;

const uint FORCESIDE = 3;

extern void process_uci();
extern void process_xboard();
extern bool parse_move(string move);

#endif

