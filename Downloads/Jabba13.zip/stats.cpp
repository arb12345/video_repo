#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <list>
#include <algorithm>
#include <math.h>
#include <stdlib.h>


#include "stats.h"
#include "move.h"
#include "defs.h"
#include "board.h"
#include "material.h"
#include "movelist.h"
#include "history.h"
#include "fen.h"
#include "movegen.h"
#include "make.h"
#include "log.h"
#include "bits.h"
#include "utils.h"

#define RESDRAW 50
#define RESWHITEWIN 100
#define RESBLACKWIN 0
#define NORESULT 200
#define RESTAR 400;

#define WIN 100
#define LOSS 0
#define DRAW 50

using namespace std;


const double EloDiff = 150;
const int MinGames = 200;
const int Quietmoves = 5;
const double elomin = 2500;

const int matvals[numpieces] = {0, 100, 100, 300, 300, 300, 300, 500, 500, 900, 900, 0, 0};


/*
constructor used to create the size of the storage vector
*/
cStatmake::cStatmake()
{
    sEntry one;
    one.actualresult = 0;
        one.actualresult = 0;
        one.expectedresult = 0;
        one.totalgames = 0;
        one.wq = 0;
        one.wr = 0;
        one.wb = 0;
        one.wn = 0;
        one.wp = 0;
        one.bq = 0;
        one.br = 0;
        one.bb = 0;
        one.bn = 0;
        one.bp = 0;

        one.matdiff = 0;
    for(int i = 0; i < indexmax; ++i)
    {
        one.index = i;
        table.push_back(one);
    }
};


void cStatmake::cleartable()
{

 for(int i = 0; i < indexmax; ++i)
    {
        table[i].actualresult = 0;
        table[i].actualresult = 0;
        table[i].expectedresult = 0;
        table[i].totalgames = 0;
        table[i].wq = 0;
        table[i].wr = 0;
        table[i].wb = 0;
        table[i].wn = 0;
        table[i].wp = 0;
        table[i].bq = 0;
        table[i].br = 0;
        table[i].bb = 0;
        table[i].bn = 0;
        table[i].bp = 0;
        table[i].index = i;
        table[i].matdiff = 0;
    }
}



void cStatmake::addentry(const uint lastindex, const double expscore, const double score)
{
    if(lastindex==0) return;

    if(score==NORESULT) { cout<<"\n score error"; return;}

    stored++;

    uint index = lastindex;

    /*
    cout<<"\n Adding at "<<index;
    cout<<" score "<<score;
    cout<<" expected "<<expscore;
    cout<<" games was "<<table[index].totalgames;
   */

   if(table[lastindex].totalgames==0) newwrite++;

    table[lastindex].actualresult += score;
    table[lastindex].expectedresult += expscore;
    table[lastindex].totalgames++;
    /*
    cout<<" games is "<<table[index].totalgames;
    cout<<" act is "<<table[index].actualresult;
   */

   // cout<<" total games "<<table[index].totalgames;

    uint wq1 = index % 2; index /= 2;
    uint wr1 = index % 3; index /= 3;
    uint wb1 = index % 3; index /= 3;
    uint wn1 = index % 3; index /= 3;
    uint wp1 = index % 9; index /= 9;
    uint bq1 = index % 2; index /= 2;
    uint br1 = index % 3; index /= 3;
    uint bb1 = index % 3; index /= 3;
    uint bn1 = index % 3; index /= 3;
    uint bp1 = index % 9; index /= 9;

    table[lastindex].wq = wq1;
    table[lastindex].wr = wr1;
    table[lastindex].wb = wb1;
    table[lastindex].wn = wn1;
    table[lastindex].wp = wp1;
    table[lastindex].bq = bq1;
    table[lastindex].br = br1;
    table[lastindex].bb = bb1;
    table[lastindex].bn = bn1;
    table[lastindex].bp = bp1;

    int bmat =  matvals[pbQ]*table[lastindex].bq +
                matvals[pbR]*table[lastindex].br +
                matvals[pbB]*table[lastindex].bb +
                matvals[pbN]*table[lastindex].bn +
                matvals[pbP]*table[lastindex].bp;
    int wmat =  matvals[pwQ]*table[lastindex].wq +
                matvals[pwR]*table[lastindex].wr +
                matvals[pwB]*table[lastindex].wb +
                matvals[pwN]*table[lastindex].wn +
                matvals[pwP]*table[lastindex].wp;

    table[lastindex].matdiff = ( wmat-bmat );
    table[lastindex].index = lastindex;
}



uint cStatmake::getmatindex()
{
    uint wq,wr,wb,wn,wp,bq,br,bb,bn,bp;

    wq = PCENUM(pwQ);
    wr = PCENUM(pwR);
    wb = PCENUM(pwB);
    wn = PCENUM(pwN);
    wp = PCENUM(pwP);
    bq = PCENUM(pbQ);
    br = PCENUM(pbR);
    bb = PCENUM(pbB);
    bn = PCENUM(pbN);
    bp = PCENUM(pbP);

    if( (wq > 1) || (wr > 2) || (wb > 2) || (wn > 2) || (bq > 1) || (br > 2) || (bb > 2) || (bn > 2) ) {
        return 0;
    }

    uint index = wq +
                  2*(wr +
                  3*(wb +
                  3*(wn +
                  3*(wp +
                  9*(bq +
                  2*(br +
                  3*(bb +
                  3*(bn +
                  3*(bp)))))))));

    verifyindex( index );

    return index;
}

bool cStatmake::verifyindex(uint index)
{
    uint wq,wr,wb,wn,wp,bq,br,bb,bn,bp;

    wq = PCENUM(pwQ);
    wr = PCENUM(pwR);
    wb = PCENUM(pwB);
    wn = PCENUM(pwN);
    wp = PCENUM(pwP);
    bq = PCENUM(pbQ);
    br = PCENUM(pbR);
    bb = PCENUM(pbB);
    bn = PCENUM(pbN);
    bp = PCENUM(pbP);

    if( (wq > 1) || (wr > 2) || (wb > 2) || (wn > 2) || (bq > 1) || (br > 2) || (bb > 2) || (bn > 2) ) {
        return true;
    }

    uint wq1 = index % 2; index /= 2;
    uint wr1 = index % 3; index /= 3;
    uint wb1 = index % 3; index /= 3;
    uint wn1 = index % 3; index /= 3;
    uint wp1 = index % 9; index /= 9;
    uint bq1 = index % 2; index /= 2;
    uint br1 = index % 3; index /= 3;
    uint bb1 = index % 3; index /= 3;
    uint bn1 = index % 3; index /= 3;
    uint bp1 = index % 9; index /= 9;

    if( wq1 != wq || wr1 != wr || wb1 != wb || wn1 != wn || wp1 != wp || bq1 != bq || br1 != br || bb1 != bb || bn1 != bn || bp1 != bp ) {
        cout<<"*** Bad index!\n";
        printboard();
        return false;
    }

    return true;
}

void cStatmake::printtable()
{

    double percactual, percexpected;
    uint games,piece;

    cout<<"\n printing table..";

    for(int i = 0; i < indexmax; ++i)
    {
        games = table[i].totalgames;
        if(games > 200)
        {
         percactual = table[i].actualresult/games;
         percexpected = table[i].expectedresult/games;

         //cout<<"\nGames "<<i<<" Exp"<<table[i].expectedresult<<" Act"<<table[i].actualresult;
         cout<<"\nIndex "<<i<<" Games "<<games<<" Exp"<<percexpected<<" Act"<<percactual;
         cout<<" ";
         piece = table[i].wq; while(piece) {cout<<"Q";piece--;}
         piece = table[i].wr; while(piece) {cout<<"R";piece--;}
         piece = table[i].wb; while(piece) {cout<<"B";piece--;}
         piece = table[i].wn; while(piece) {cout<<"N";piece--;}
         piece = table[i].wp; while(piece) {cout<<"P";piece--;}
         piece = table[i].bq; while(piece) {cout<<"q";piece--;}
         piece = table[i].br; while(piece) {cout<<"r";piece--;}
         piece = table[i].bb; while(piece) {cout<<"b";piece--;}
         piece = table[i].bn; while(piece) {cout<<"n";piece--;}
         piece = table[i].bp; while(piece) {cout<<"p";piece--;}

         cout<<" material "<<table[i].matdiff;
        }
    }
}



bool cStatmake::makesan(const string make)
{

    if(make=="1/2-1/2" || make=="0-1" || make=="1-0" || make=="*" || make == " ")
    return false;
    SETPLY(0);
    uint move;
    string made;
    move = santomove(make);
    //cout<<"\nNEW "<<make;
    /*
    if the move was illegal, there was an error somewhere, so
    need to check the slow way...
    */
    if(makemove(move))
    {
       // cout<<"\n slow ";
       slow++;
        takemove();
        uint i;
        vector<string> made;
        vector<uint> templist;
        string temp;
        uint tempmove;
        gen_all_moves(NULLMOVE);

        for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
        {
           tempmove = MOVE(PLYNOW,i);
           if (makemove(tempmove)){takemove();continue;}
           takemove();
           temp = movetosan(tempmove);
           made.push_back(temp);
           templist.push_back(tempmove);
        }

        bool have = false;
        for(i=0; i < made.size(); ++i)
        {
            temp = made[i];
            move=templist[i];
            if(temp==make)
            {
             have = true;
             makemove(move);
            }
        }
        if(!have)
        {
            slownotok++;
            return false;
        }
    }
    return true;
}

double cStatmake::computescore(double Ra, double Rb)
{
    if(Ra==0 || Rb==0) return 0;
	double Qa = pow(10,(Ra/400));
    double Qb = pow(10,(Rb/400));

    double score = Qa/(Qa+Qb);

    return score*100;
}
/*

[WhiteElo "2660"]
[BlackElo "2630"]

*/

void cStatmake::getelo(const string line, double &Rw, double &Rb)
{
    int pos;
    string ourline = line;
    string elotext;


    if(findsubstrend("[WhiteElo \"", ourline, pos))
    {
      while(ourline[pos]!='"')
      {
          elotext += ourline[pos];
          pos++;
      }

      Rw = strtodbl(elotext,0);

      if(Rw<1000) cout<<"\n score problem Rw "<<Rw<<" "<<line;
      if(Rw>3300) cout<<"\n score problem Rw "<<Rw<<" "<<line;

      if(Rw<minelo) minelo=Rw; if(Rw>maxelo) maxelo=Rw;
    }

    if(findsubstrend("[BlackElo \"", ourline, pos))
    {
      while(ourline[pos]!='"')
      {
          elotext += ourline[pos];
          pos++;
      }

      Rb = strtodbl(elotext,0);

      if(Rb<1000) cout<<"\n score problem Rb "<<Rb<<" "<<line;
      if(Rb>3300) cout<<"\n score problem Rb "<<Rb<<" "<<line;

      if(Rb<minelo) minelo=Rb; if(Rb>maxelo) maxelo=Rb;
    }
}

void cStatmake::readpgn()
{
    //fillarrays();
    string fenline;

    //cleartable();
    //clean_eval();
    //printfeatures();
    uint gameresult=NORESULT;
    uint index;
    uint lastindex=0;
    double expscore=0;
    double Rw=0,Rb=0;
    discardeddiff=0;
    discardedelo=0;
    discardedres=0;
    stored=0;
    newwrite=0;
    minelo=3500,maxelo=0;
    slow=0;slownotok=0;
    countgames=0;
    whitescore=0;
    blackscore=0;

    string movetomake; //the move that will be pushed back into the vector

    string lines;//string reading in each line of the pgn file
    string gameline;//will conatin the whole game line as one strip
    ifstream file;//pgn file
    int found = -1;//set to 0 when we find the start of a game (string starts 1.)
    string::iterator pline = lines.begin();//iterate through the line

    bool ingame = false;
    bool lastline = false;
    int plysincecapture = 0;

    //cout<<endl;

    if (ifile.is_open())
    {
      while (! ifile.eof() )
      {
       getline (ifile,lines);

      // cout<<lines<<endl;
       if(lines[0]=='[')
       {
          // cout<<"\n header ";
          //cout<<lines<<endl;
          getelo(lines,Rw,Rb);
          continue;
       }
       if(!ingame)//if we're not in a game, see if we've started the next game
       {
        found=lines.find("1.",0,2);
        if(found==0)
        {
           // cout<<"starting game ";
            //if(countmoves<21) cout<<"\n last game less than 20";
            setepdposition(startfen);
            clearhistory();
            ingame=true;
            //if(countgames%10==0) cout<<" . ";
            gameline.clear();
            expscore = computescore(Rw,Rb);
            countgames++;
           // if(countgames==102) break;
           cout<<"\r---> game "<<countgames<<" discarded "<<discardeddiff+discardedelo+discardedres
           <<" written "<<stored<<" new "<<newwrite
           <<" slow "<<slow<<" notok "<<slownotok
           <<" white win "<<( (whitescore/(whitescore+blackscore))*100 )<<"%";
           /* if(countgames%1000==0) cout<<"\n---> game "<<countgames;
            if(countgames%10000==0) cout<<" *********************"<<countgames;*/
            //if(countgames==2000) exit(1);

            gameresult = NORESULT;

            found=lines.find("0-1",0,3);
            if(found!=-1)
            { gameresult = RESBLACKWIN; /*cout<<"\n black win "<<lines;*/}
            else
            {
                found=lines.find("1/2-1/2",0,7);
                if(found!=-1)
                { gameresult = RESDRAW;/*cout<<"\n draw  "<<lines;*/ }
                else
                {
                found=lines.find("1-0",0,3);
                if(found!=-1)
                { gameresult = RESWHITEWIN;/*cout<<"\n white win  "<<lines;*/ }
                else
                {
                    found=lines.find("*",0,1);
                    if(found!=-1)
                    { gameresult = RESTAR;/*cout<<"\n white win  "<<lines;*/ }
                }
             }
            }
            if(found!=-1)  { lastline=true; }
        }// now in a game
       }
       else // we're in a game - is this the last line?
       {
        gameresult = NORESULT;

        found=lines.find("0-1",0,3);
        if(found!=-1)
        { gameresult = RESBLACKWIN; }
        else
        {
            found=lines.find("1/2-1/2",0,7);
            if(found!=-1)
            { gameresult = RESDRAW; }

            else
            {
               found=lines.find("1-0",0,3);
               if(found!=-1)
               { gameresult = RESWHITEWIN; }
               else
               {
                found=lines.find("*",0,1);
                if(found!=-1)
                { gameresult = RESTAR; }
               }
            }
        }
        if(found!=-1)  { lastline=true; }
       }

       if(ingame) //game move now started, now store iterate and make moves
       {
         //if the new line doesn't start with a space, make sure there's a space put in if the last one didn't end with
         //a space - don't do this if we're processing the first line!
         if(!(lines[0]=='1' && lines[1]=='.'))
         {
             if(gameline[gameline.length()-1] != ' ')
             {
                 if(lines[0]!=' ')
                 {
                    gameline+=" ";
                 }
             }
         }
         gameline+=lines;
         if(!lastline) {continue;}

       /*
       now have the gameline stored in gameline as a one line string 1.e4 e5 2.Nf3 etc.
       */
         ingame=false;
         lastline=false;
         pline = gameline.begin();
         /*
         plysincecapture=0;

         if(expscore==0) cout<<"\n score error";

         if(gameresult==RESWHITEWIN) whitescore+= 100;
         else if (gameresult==RESBLACKWIN) blackscore+= 100;
         else if(gameresult==RESDRAW){ blackscore+= 50; whitescore+= 50; }
         else {Rw = 0; Rb = 0; expscore = 0;
          discardedres++;continue;}

         if(abs((int)Rw-(int)Rb) > (int)EloDiff)
         {Rw = 0; Rb = 0; expscore = 0;
          discardeddiff++;continue;}
         if(Rw<elomin || Rb<elomin)
         {Rw = 0; Rb = 0; expscore = 0;
         discardedelo++;continue;}

         lastindex = getmatindex();
         plysincecapture = 1;*/

         //cout<<"\n new game "<<countgames<<" "<<gameline;

         while(pline != gameline.end())
         {
               movetomake.clear();
               //if(countgames!=96) break;
              // break;
               //printboard();
               if(pline[0]=='.')//hit dot indicating move for white
               {
                pline++;
                if(pline[0]==' ') pline++;//if there's a space after the dot, move to next

                for(;pline != gameline.end();pline++)
                {
					if(*pline==' ') break;
					movetomake += *pline;
                }
                if(!makesan(movetomake)){ break; }
/*
      cout<<"\n Showing***********\n";
      printboard();
	 // printmaterial();
      printallhistory();
      cout<<"\n EndShowing***********\n";
*/
                index = getmatindex();
                if(index!=0){  if(verifyindex(index)==false) cout<<"\n index error2"; }
                if(index!=lastindex)
                {
                    if(plysincecapture>3)
                    addentry(lastindex, expscore, gameresult);
                    features(expscore,gameresult);
                    lastindex = index;
                    plysincecapture = 1;
                }
                else
                {
                    plysincecapture++;
                }


                pline++;//should be looking at the first letter of the black move..
                movetomake.clear();
                for(;pline != gameline.end();pline++)
                {
					if(*pline==' ') break;
					movetomake += *pline;
                }

               if(!makesan(movetomake)) {  break; }
/*
                cout<<"\n Showing***********\n";
      printboard();
	 // printmaterial();
	  //printmovelist(PLYNOW);
      printallhistory();
      cout<<"\n EndShowing***********\n";
*/

               index = getmatindex();
                if(index!=0){  if(verifyindex(index)==false) cout<<"\n index error2"; }
                if(index!=lastindex)
                {
                    if(plysincecapture>3)
                    addentry(lastindex, expscore, gameresult);
                    features(expscore,gameresult);
                    lastindex = index;
                    plysincecapture = 1;
                }
                else
                {
                    plysincecapture++;
                }

               }
               pline++;
               if(GAMEMOVES >= 512) break;
         }

         Rw = 0; Rb = 0; expscore = 0;

       }
      }
    }
    else
    {
        cout<<"\n File not found";
    }
    cout<<"\n minelo = "<<minelo<<" maxelo = "<<maxelo<<endl;

    printtable();
    writetable();
    printfeatures();
}

bool cStatmake::datameasured(const uint &plys, const uint result)
{
    //if less than 5 ply since a capture, return false, which keeps going through
    //the game. If not enough pawns, return true which will break the game loop
    if(plys < 5) return false;
    if(PCENUM(pwP) > 6 || PCENUM(pbP) > 6) return false;
    if(PCENUM(pwP) < 4 || PCENUM(pbP) < 4) return true;

    return false;
}



void cStatmake::writetable()
{

    int c;
    ofstream fout("material_final.dat", ios::binary);
    for(c=0; c < indexmax; ++c)
    {
         fout.write((char *)(&table[c]), sizeof(sEntry));
    }

     fout.close();
}

/*
read the table into the internal store
*/
void cStatmake::readtable()
{
  string filein;
  sEntry temp;


  //cout<<"\n enter file to read in -> ";
  //cin>>filein;

  ifstream fin("material_final.dat", ios::binary);
  if(!fin) { cout<<"\nno file found\n"; return;}
  table.clear();

  while (!fin.eof())
  {
      fin.read((char *) &temp, sizeof(temp));
      table.push_back(temp);
  }

    cout<<"\n read in "<<table.size()<<" material entries \n";

    fin.close();
}

void cStatmake::printresult(double exp, double act, double gam, string name)
{
    cout<<"\n\n "<<name;
    cout<<"\n gamesplayed "<<gam;
    cout<<"\n Expected score = "<<exp/gam;
    cout<<"\n Actual score = "<<act/gam;

    double winperc = (((act/gam)-(exp/gam))-whiteadvantage);
    cout<<"\n White wins by "<<winperc;

    cout<<"\n cp = "<<winperc/whitepawnup;


    cout<<endl;
}

double cStatmake::getresult(double exp, double act, double gam)
{
    double winperc = (((act/gam)-(exp/gam))-whiteadvantage);
    return (winperc/whitepawnup)*100;
}


uint cStatmake::makeindex(int wq, int wr, int wb, int wn, int wp, int bq, int br, int bb, int bn, int bp)
{
    if( (wq > 1) || (wr > 2) || (wb > 2) || (wn > 2) || (bq > 1) || (br > 2) || (bb > 2) || (bn > 2) ) {
        return 0;
    }

    uint index = wq +
                  2*(wr +
                  3*(wb +
                  3*(wn +
                  3*(wp +
                  9*(bq +
                  2*(br +
                  3*(bb +
                  3*(bn +
                  3*(bp)))))))));

    return index;
}


void cStatmake::printtableentry(uint i)
{

    double percactual, percexpected;
    uint games,piece;



        games = table[i].totalgames;
        percactual = table[i].actualresult/games;
        percexpected = table[i].expectedresult/games;
        double winperc = (percactual-percexpected-whiteadvantage);

		cout<<" Index "<<i<<" Games "<<games/*<<" Exp"<<percexpected<<" Act"<<percactual*/;
        cout<<" balance <";
		piece = table[i].wq; while(piece) {cout<<"Q";piece--;}
        piece = table[i].wr; while(piece) {cout<<"R";piece--;}
        piece = table[i].wb; while(piece) {cout<<"B";piece--;}
        piece = table[i].wn; while(piece) {cout<<"N";piece--;}
        piece = table[i].wp; while(piece) {cout<<"P";piece--;}
        piece = table[i].bq; while(piece) {cout<<"q";piece--;}
        piece = table[i].br; while(piece) {cout<<"r";piece--;}
        piece = table[i].bb; while(piece) {cout<<"b";piece--;}
        piece = table[i].bn; while(piece) {cout<<"n";piece--;}
        piece = table[i].bp; while(piece) {cout<<"p";piece--;}
		cout<<">";
        //cout<<" material "<<table[i].matdiff;
		cout<<" cp = "<<winperc/whitepawnup;
}


void cStatmake::analysedata()
{
    uint c;
    	uint i;
    		uint j;
    sEntry temp;
    uint entries = table.size();
    cout<<endl;

    double expres=0,actres=0,games=0;
    int wmin=0,bmin=0,wmaj=0,bmaj=0;

    whiteadvantage = 7.43;
    whitepawnup = 18.8; //comes from database



    //loop equal
    for(c=0; c < entries; ++c)
    {
        temp = table[c];
        if(temp.totalgames > 200 && temp.wp > 2 && temp.wp < 7 && temp.bp > 2 && temp.bp < 7)
        {
            if(temp.wb==temp.bb && temp.wq==temp.bq && temp.wr==temp.br && temp.wn==temp.bn && temp.wp==temp.bp)
            {
               expres+=temp.expectedresult;
               actres+=temp.actualresult;
               games+=double(temp.totalgames);
            }
        }
    }

    printresult(expres, actres, games, "EQUAL MATERIAL");

    //loop white pawn up
    expres=0,actres=0,games=0;
    for(c=0; c < entries; ++c)
    {
        temp = table[c];
        if(temp.totalgames > 200 && temp.wp > 2 && temp.wp < 7 && temp.bp > 2 && temp.bp < 7)
        {
            if(temp.wb==temp.bb && temp.wq==temp.bq && temp.wr==temp.br && temp.wn==temp.bn)
            {
             if(temp.matdiff == 100)
             {
               expres+=temp.expectedresult;
               actres+=temp.actualresult;
               games+=double(temp.totalgames);
             }
            }
        }
    }

    printresult(expres, actres, games, "WHITE PAWN UP");

    //loop black pawn up

    expres=0,actres=0,games=0;
    for(c=0; c < entries; ++c)
    {
        temp = table[c];
        if(temp.totalgames > 200 && temp.wp > 1 && temp.wp < 8 && temp.bp > 1 && temp.bp < 8)
        {

            if(temp.wb==temp.bb && temp.wq==temp.bq && temp.wr==temp.br && temp.wn==temp.bn)
            {
             if(temp.matdiff == -100)
             {
               expres+=temp.expectedresult;
               actres+=temp.actualresult;
               games+=double(temp.totalgames);
             }
            }
        }
    }

    printresult(expres, actres, games, "BLACK PAWN UP");

    //wNvsbB
     for(j=2; j<=14; j+=2)
    {
    expres=0,actres=0,games=0;
    for(c=0; c < entries; ++c)
    {
        temp = table[c];
        if(temp.totalgames > 100 && temp.wp + temp.bp == j && temp.bp == temp.wp)
        {
            wmin=temp.wn+temp.wb;bmin=temp.bn+temp.bb;wmaj=temp.wr+temp.wq;bmaj=temp.bq+temp.br;
            if(wmaj==bmaj && wmin==bmin && temp.wn-temp.bn==1)
            {
               expres+=temp.expectedresult;
               actres+=temp.actualresult;
               games+=double(temp.totalgames);
            }
        }
    }
    printf("\nwNvsbB %dpawns score = %f",j,getresult(expres,actres, games));
    }

    //bNvswB
     for(j=2; j<=14; j+=2)
    {
    expres=0,actres=0,games=0;
    for(c=0; c < entries; ++c)
    {
        temp = table[c];
        if(temp.totalgames > 100 && temp.wp + temp.bp == j && temp.bp == temp.wp)
        {
            wmin=temp.wn+temp.wb;bmin=temp.bn+temp.bb;wmaj=temp.wr+temp.wq;bmaj=temp.bq+temp.br;
            if(wmaj==bmaj && wmin==bmin && temp.wn-temp.bn==-1)
            {
               expres+=temp.expectedresult;
               actres+=temp.actualresult;
               games+=double(temp.totalgames);
            }
        }
    }
    printf("\nbNvswB %dpawns score = %f",j,getresult(expres,actres, games));
    }


    int wq,wr,wb,wn,wp,bq,br,bb,bn,bp;

	cout<<"\nNNpp";
	wp=0;bp=2;wn=2;bn=0;wb=0;bb=0;wr=0;br=0;wq=0;bq=0;
	i = makeindex(wq,wr,wb,wn,wp,bq,br,bb,bn,bp);
	printtableentry(i);
	cout<<"\nNNppp";
	wp=0;bp=3;wn=2;bn=0;wb=0;bb=0;wr=0;br=0;wq=0;bq=0;
	i = makeindex(wq,wr,wb,wn,wp,bq,br,bb,bn,bp);
	printtableentry(i);
	cout<<"\nNNpppp";
	wp=0;bp=4;wn=2;bn=0;wb=0;bb=0;wr=0;br=0;wq=0;bq=0;
	i = makeindex(wq,wr,wb,wn,wp,bq,br,bb,bn,bp);
	printtableentry(i);


	cout<<"\nPPnn";
	wp=2;bp=0;wn=0;bn=2;wb=0;bb=0;wr=0;br=0;wq=0;bq=0;
	i = makeindex(wq,wr,wb,wn,wp,bq,br,bb,bn,bp);
	printtableentry(i);
	cout<<"\nPPPnn";
	wp=3;bp=0;wn=0;bn=2;wb=0;bb=0;wr=0;br=0;wq=0;bq=0;
	i = makeindex(wq,wr,wb,wn,wp,bq,br,bb,bn,bp);
	printtableentry(i);
	cout<<"\nPPPPnn";
	wp=4;bp=0;wn=0;bn=2;wb=0;bb=0;wr=0;br=0;wq=0;bq=0;
	i = makeindex(wq,wr,wb,wn,wp,bq,br,bb,bn,bp);
	printtableentry(i);

	cout<<"\n**************************";
	cout<<"\n**************************\n";

	//print all for 200 games or more
	expres=0,actres=0,games=0;
    for(c=0; c < entries; ++c)
    {
        temp = table[c];
        if(temp.totalgames > 1000 && temp.matdiff >= -200 && temp.matdiff <= 200 )
        {
           printentry(temp);
        }
    }


}

void cStatmake::printentry(sEntry data)
{
    double percactual, percexpected;
    uint piece,games;

    //cout<<"\n printing entry..";

         percactual = data.actualresult;
         percexpected = data.expectedresult;
         games = data.totalgames;
         //cout<<"\nGames "<<i<<" Exp"<<table[i].expectedresult<<" Act"<<table[i].actualresult;
         cout<<"\nIndex "<<data.index<<" Games "<<games<<" Exp "<<percexpected/games<<" Act "<<percactual/games;
         cout<<" ";
         piece = data.wq; while(piece) {cout<<"Q";piece--;}
         piece = data.wr; while(piece) {cout<<"R";piece--;}
         piece = data.wb; while(piece) {cout<<"B";piece--;}
         piece = data.wn; while(piece) {cout<<"N";piece--;}
         piece = data.wp; while(piece) {cout<<"P";piece--;}
         piece = data.bq; while(piece) {cout<<"q";piece--;}
         piece = data.br; while(piece) {cout<<"r";piece--;}
         piece = data.bb; while(piece) {cout<<"b";piece--;}
         piece = data.bn; while(piece) {cout<<"n";piece--;}
         piece = data.bp; while(piece) {cout<<"p";piece--;}

         cout<<" material "<<data.matdiff;

         cout<<" cp="<<getresult(data.expectedresult, data.actualresult, data.totalgames);;

}

void cStatmake::clean_eval()
{
    uint i,j;

    for(i = 0; i < BRDSQ; ++i)
    {
      for(j = 0; j < 2; ++j)
      {
        p[j][i].expectedscore = p[j][i].actualscore = p[j][i].totalgames = 0;
        n[j][i].expectedscore = n[j][i].actualscore = n[j][i].totalgames = 0;
        b[j][i].expectedscore = b[j][i].actualscore = b[j][i].totalgames = 0;
        r[j][i].expectedscore = r[j][i].actualscore = r[j][i].totalgames = 0;
        q[j][i].expectedscore = q[j][i].actualscore = q[j][i].totalgames = 0;
        k[j][i].expectedscore = k[j][i].actualscore = k[j][i].totalgames = 0;
        knsup[j][i].expectedscore = knsup[j][i].actualscore = knsup[j][i].totalgames = 0;
        cout<<"\n p["<<j<<"]["<<i<<"].expectedscore = "<<p[j][i].expectedscore;
      }
    }
}

#define ENDGAME		(((4*vR)+(vB)+(vN)+(4*vP)))
//evalutation of psqt, scoring from database
void cStatmake::features(const double exp, const double act)
{
    uint phase = 0;

    uint stage = PCENUM(pwQ) + PCENUM(pbQ) +
                 PCENUM(pwR) + PCENUM(pbR) +
                 PCENUM(pwN) + PCENUM(pbN) +
                 PCENUM(pwP) + PCENUM(pbP) +
                 PCENUM(pwB) + PCENUM(pbB);

    if(stage <= ENDGAME) phase = END;
    else phase = OPE;

	uint sq;
    uint ptype;
    u64 wocc;
    u64 bocc;
    wocc = P_BB(cW);
    bocc = P_BB(cB);
    uint sq64;
    u64 pieceBB;

    for(ptype = pwP; ptype <= pbK; ptype++)
    {
        pieceBB = GET_BB(ptype);
        while(pieceBB)
        {
            sq = POP64(pieceBB);
            sq64 = SQTO64(sq);
            switch (ptype)
            {
                case pwP:
                p[phase][sq].expectedscore+=exp;
                p[phase][sq].actualscore+=act;
                p[phase][sq].totalgames++; break;
                case pwN:
                n[phase][sq].expectedscore+=exp;
                n[phase][sq].actualscore+=act;
                n[phase][sq].totalgames++;

                if(!(wknightsup[sq64] & bocc))
                {
                    knsup[0][sq].expectedscore+=exp;
                    knsup[0][sq].actualscore+=act;
                    knsup[0][sq].totalgames++;
                }
                break;
                case pbN:
                if(!(bknightsup[sq64] & wocc))
                {
                    knsup[1][sq].expectedscore+=exp;
                    knsup[1][sq].actualscore+=act;
                    knsup[1][sq].totalgames++;
                }
                break;
                case pwB:
                b[phase][sq].expectedscore+=exp;
                b[phase][sq].actualscore+=act;
                b[phase][sq].totalgames++; break;
                case pwR:
                r[phase][sq].expectedscore+=exp;
                r[phase][sq].actualscore+=act;
                r[phase][sq].totalgames++; break;
                case pwQ:
                q[phase][sq].expectedscore+=exp;
                q[phase][sq].actualscore+=act;
                q[phase][sq].totalgames++; break;
                case pwK:
                k[phase][sq].expectedscore+=exp;
                k[phase][sq].actualscore+=act;
                k[phase][sq].totalgames++; break;
                default: break;
            }
        }

    }
}

double cStatmake::resultcp(double exp, uint gam, double act)
{
    whiteadvantage = 7.43;
    whitepawnup = 18.8; //comes from database

    double winperc = (((act/gam)-(exp/gam))-whiteadvantage);
    double cp = winperc/whitepawnup;

    return cp;
}

void cStatmake::printfeatures()
{

    uint pce;
    int f,r;
    uint sq;
    double e,a;
    uint g;


    for(pce = 0; pce < numpieces; ++pce)
    {
        cout<<endl;
        cout<<"\n piece sq opening "<<piecechar(pce)<<endl;
        for( r = 7; r>=0; r--)
        {
        for( f = 0; f<=7; ++f)
        {
           sq = fr2sq(f,r);
           e=n[1][sq].expectedscore;
           a=n[1][sq].actualscore;
           g=n[1][sq].totalgames;
           cout<<setw(5)<<((int)((resultcp(e,g,a)*100)+0.5));
        }
        cout<<endl;
        }
    }

    cout<<"\n Knight supported ";
    for( r = 7; r>=0; r--)
        {
        for( f = 0; f<=7; ++f)
        {
           sq = fr2sq(f,r);
           e=knsup[1][sq].expectedscore;
           a=knsup[1][sq].actualscore;
           g=knsup[1][sq].totalgames;
           cout<<setw(5)<<((int)((resultcp(e,g,a)*100)+0.5));
        }
        cout<<endl;
        }

}


