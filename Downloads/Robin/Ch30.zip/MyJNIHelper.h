//
//  CCloud.h
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 06/03/14.
//
//

#ifndef __SimpleFloppyRobin__MyJNIHelper__
#define __SimpleFloppyRobin__MyJNIHelper__

#include <jni.h>

extern "C" {
	extern void CallMyJavaSideJNI(int num);
	extern void CallMyJavaToastJNI(int num, bool myBool);
	extern void Java_com_bluefever_simplefloppyrobin_CJNIHelper_CallCPPLayer(JNIEnv *env, jobject obj);

}

#endif /* defined(__SimpleFloppyRobin__MyJNIHelper__) */
