#ifndef HASH_H
#define HASH_H

#include "defs.h"

using namespace std;

struct sHashelem {
       u64 key;
       uint move;
       int score;
       int depth;
       uint flag;
};


struct sHashtable {

         sHashelem *table;

         uint elements;
         uint write;
         uint probe;
         uint hit;
};

extern sHashtable ttable[1];

extern void init_table_memory();
inline void resetcounters() { ttable->hit=ttable->probe=ttable->write=0;}
extern void reset_tables();
extern void delete_tables();
extern void makenewtable(const uint elem);

extern void ttablesays_stats();

extern uint probe_hashentry(int &score, const int depth, uint &move, const int &beta, bool &donull, const u64 &key, const uint ply);
extern void store_hashentry(const int score, const uint flag, const uint move, const int depth, const u64 &key);

#endif
