#include <iostream>
#include <iomanip>
#include <string>
#include "attack.h"
#include "piecedefs.h"
#include "squares.h"
#include "material.h"
#include "defs.h"
#include "magic.h"
#include "bits.h"

using namespace std;

const bool debug = false;
const uint wPbit = 1;
const uint bPbit = wPbit*2;
const uint Nbit = bPbit*2;
const uint Bbit = Nbit*2;
const uint Rbit = Bbit*2;
const uint Qbit = Rbit*2;
const uint Kbit = Qbit*2;

const uint pcebits[] =
{
  0,wPbit,bPbit,Nbit,Nbit,Bbit,Bbit,Rbit,Rbit,Qbit,Qbit,Kbit,Kbit
};

const uint slidersquares = 7;
const uint nonslidersquares = 1;


const uint nonattsliders[numcolours][3] =
{
     {pwK,pwN,pwP},
     {pbK,pbN,pbP}
};

unsigned int bitsfromdelta[256];
int stepfromdelta[256];

void init_attack_tables()
{
  const int *movedir = NULL;
  uint piece;
  uint slidenum;
  uint slide;
  int delta;
  int finaldelta;

  for(piece = 0; piece < 256; ++piece)
  {
      bitsfromdelta[piece]=0;
      stepfromdelta[piece]=0;
  }

  //major pieces first (non pawns)
  for(piece = pwN; piece <= pbK; ++piece)
  {
    if(ISSLIDE(piece)) slidenum = slidersquares;
    else slidenum = nonslidersquares;
    ASS(slidenum==7 || slidenum==1);
    for(movedir = MOVEDIR(piece); *movedir ; movedir++)
    {
       delta = *movedir;
       for(slide = 0; slide < slidenum; ++slide)
       {
          finaldelta = delta + (delta * slide)+128;
          ASS(finaldelta>=0&&finaldelta<256);
          bitsfromdelta[finaldelta] |= pcebits[piece];
          stepfromdelta[finaldelta] = delta;
       }
    }
  }

  uint i;
  for(piece = pwP; piece <= pbP; ++piece)
  {
    for(i = 0; i < 2; ++i)
    {
      delta = dirPawn[piece][i];
      finaldelta = delta + 128;
      ASS(finaldelta>=0&&finaldelta<256);
      bitsfromdelta[finaldelta] |= pcebits[piece];
      stepfromdelta[finaldelta] = delta;
    }
  }

}

//see if the current side "side" is in check
bool incheck(const uint &side)
{
    ASS(side==cW||side==cB);
    return isattack((side^1), KINGSQ(side));
}

void showattacks(const uint &side, const uint &target)
{

  uint sq64 = SQTO64(target);
  cout<<"\n p att ";
  printbitboard(pawn_att[side^1][sq64] & P_BB(side));
  cout<<"\n n att ";
  printbitboard(knight_moves[sq64] & N_BB(side));
  cout<<"\n b & q att ";
  printbitboard(getBishopAttBoard(sq64) & (B_BB(side) | Q_BB(side)));
  cout<<"\n r & q att ";
  printbitboard(getRookAttBoard(sq64)& (R_BB(side) | Q_BB(side)));
  cout<<"\n k att ";
  printbitboard(king_moves[sq64] & K_BB(side));
}

//is square attacked by side
bool isattack(const uint &side, const uint &target)
{
  uint sq64 = SQTO64(target);

  if(
    ( pawn_att[side^1][sq64] & P_BB(side) ) ||
    ( knight_moves[sq64] & N_BB(side) ) ||
    ( getBishopAttBoard(sq64) & (B_BB(side) | Q_BB(side)) ) ||
    ( getRookAttBoard(sq64)& (R_BB(side) | Q_BB(side)) ) ||
    ( king_moves[sq64] & K_BB(side) )
    )
    return true;

    else
    return false;
}


/*
piece on target is pinned by side
*/
bool ispinned(const uint &side, const uint &target)
{
  int delta, step, step2, delta2;
  uint iter, i;
  uint piece;
  uint sq;
  u64 pieceBB;
  uint ksq = KINGSQ(side^1);

  ASS(side==cW||side==cB);
  ASS(onbrd(target));
  for(i = 0; i < 3; ++i)
     {
       piece = sliders[side][i];
       ASS(piecegood(piece));
       ASS(ISSLIDE(piece));
       pieceBB = GET_BB(piece);
       while(pieceBB)
       {
         sq = POP64(pieceBB);
         ASS(onbrd(sq));
         ASS(BRDPCE(sq)==piece);
         delta = target - sq + 128;
         ASS(delta>=0&&delta<256);
         if(bitsfromdelta[delta]!=0)
         {
         if(pcebits[piece] & bitsfromdelta[delta])
         {
          step = stepfromdelta[delta];
          for(iter = sq+step; ;iter+=step)
          {
            if(iter==target)//could hit, now check if the ksq can also be hit
            {
                delta2 = ksq - sq + 128;
                if( (bitsfromdelta[delta2]!=0) && (pcebits[piece] & bitsfromdelta[delta2]) && stepfromdelta[delta] == stepfromdelta[delta2])
                {
                    step2 = stepfromdelta[delta2];
                    if(step2!=step)  cout<<"\n delta error ";
                    for(iter=step+target;;iter++)//iterate to king
                    {
                        if(iter==ksq)
                        {
                           return true;
                        }
                        if(BRDPCE(iter)!=pE) break;
                        if(iter&0x88) break;
                    }
                }
            }
            if(BRDPCE(iter)!=pE) break;
            if(iter&0x88) break;
          }
         }
         }
       }
     }

     return false;
}

void printattboard(const uint piece, const uint sq)
{
    uint f = 0;
    int  r = 0;
    int delta,finaldelta;
    uint s;

    cout<<endl;

    for( r = 7; r>=0; r--)
    {
        for( f = 0; f<=7; ++f)
        {
           s = fr2sq(f,r);
           ASS(onbrd(s));

           if(s==sq) cout<<setw(3)<<".";
           else
           {
               delta = s - sq;
               finaldelta = delta + 128;
               if(pcebits[piece] & bitsfromdelta[finaldelta])
               cout<<setw(3)<<"y";
               else
               cout<<setw(3)<<".";
           }
        }
        cout<<endl;
    }
    cout<<endl;
}


void printsquaresatt(const uint side)
{
    uint f = 0;
    int  r = 0;
    uint s;

    ASS(side==cW||side==cB);

    cout<<endl;

    for( r = 7; r>=0; r--)
    {
        for( f = 0; f<=7; ++f)
        {
           s = fr2sq(f,r);
           ASS(onbrd(s));

           if(isattack(side, s))
           {
             cout<<setw(3)<<"a";
           }
           else
           {
             cout<<setw(3)<<".";
           }
        }
        cout<<endl;
    }
    cout<<endl;
}

struct attentry {
    int val;
    uint sq;
};

attentry attlist[2][9];
int numused[2];

void sortlist(const uint &side)
{
    int i,j,f=0;
    int end = numused[side];
    attentry temp;

    for(i = 0; i < end; ++i)
    {
        f=0;
        for(j = 0; j < end-1; ++j)
        {
            if(attlist[side][j+1].val > attlist[side][j].val)
            {
                temp = attlist[side][j];
                attlist[side][j] = attlist[side][j+1];
                attlist[side][j+1] = temp;
                f=1;
            }
        }
        if(f==0) break;
    }
}

void fill_att_list(const uint &side, const uint target, const uint from, const u64 &occ, u64 *attackers)
{
  if(debug){  cout<<"\n fill att list, looking to see if "<<printsquare(target)<<" is attacked by "<<side;}

  uint piece;
  uint sq;
  attentry temp;
  uint sq64 = SQTO64(target);
  u64 att;

  u64 attbrd = (
    ( pawn_att[side^1][sq64] & P_BB(side) ) |
    ( knight_moves[sq64] & N_BB(side) ) |
    ( getBishopAttBoard(sq64) & (B_BB(side) | Q_BB(side)) ) |
    ( getRookAttBoard(sq64)& (R_BB(side) | Q_BB(side)) ) |
    ( king_moves[sq64] & K_BB(side) )
    );

  numused[side]=0;

  attbrd &= occ;
  att = attbrd;
  *attackers |= att;

  if(debug)
    {
        cout<<"\n att = ";
        printbitboard(att);
    }

  while(att)
  {
      sq = POP64(att);
      piece = BRDPCE(sq);
      temp.sq = sq;
      temp.val = piecevals[piece];
      if(debug){ cout<<" HIT!, adding val "<<temp.val<<" sq "<<printsquare(sq);}
      attlist[side][numused[side]++] = temp;
      if(debug){ cout<<" att now "<<numused[side];}
  }

  attlist[side][numused[side]].val=0;
}


void fillhidden( const uint &side, const int &target, const uint &from, u64 &occ, u64 *attbrd)
{
   if(debug){ cout<<"\n finding hidden from sq "<<printsquare(from);}
   if(debug)
    {
        cout<<"\n occ = ";
        printbitboard(occ);
    }

    clearbit(from,occ);//clear the attacker
    clearbit(from,*attbrd);

    if(debug)
    {
        cout<<"\n clear sq, occ = ";
        printbitboard(occ);
        cout<<"\n attbrd = ";
        printbitboard(*attbrd);
    }


    if(BRDPCE(from)==pwN || BRDPCE(from)==pbN)
    {
        if(debug){     cout<<"\n piece is N, no hidden ";}
        return; //knight move will not revela an attacker
    }


    uint sq64 = SQTO64(target);

    u64 att = (
    ( bishopmove((int)sq64, occ) & (B_BB(side) | Q_BB(side)) ) |
    ( rookmove((int)sq64, occ) & (R_BB(side) | Q_BB(side)) )
    );

    att &= occ;

    if(debug)
    {
        cout<<"\n new att = ";
        printbitboard(att);
        cout<<"\n attackers = ";
        printbitboard(*attbrd);
    }

    att &= (~*attbrd);

    if(debug)
    {
        cout<<"\n hidden att = ";
        printbitboard(att);
    }


    if(att)
    {
      uint sq = POP64(att);
      uint piece;
      attentry temp;

      piece = BRDPCE(sq);
      temp.sq = sq;
      temp.val = piecevals[piece];
      if(debug){ cout<<" Hidden HIT!, adding val "<<temp.val<<" sq "<<printsquare(sq);}
      attlist[side][numused[side]++] = temp;
      if(debug){ cout<<" att now "<<numused[side];}
    }
}

void printattlists()
{
    int i;

    cout<<"\n Attack lists: \nwhite attackers total : "<<numused[cW]<<endl;
	string sq;
    for(i=0;i<numused[cW];++i)
    {
        sq = printsquare(attlist[cW][i].sq);
		cout<<"Sq "<<sq<<" val "<<(attlist[cW][i].val)<<" index "<<i<<endl;
    }
    cout<<" black attackers total : "<<numused[cB]<<endl;
    for(i=0;i<numused[cB];++i)
    {
        sq = printsquare(attlist[cB][i].sq);
		cout<<"Sq "<<sq<<" val "<<attlist[cB][i].val<<" index "<<i<<endl;
    }
}

int loopcounter;
u64 attackers[2]; //ugh

int getnext(const uint side)
{
    if(numused[side]==0) return 0;
    else return attlist[side][--numused[side]].val;
}

int  xchange(int stm, int pceval, const uint target, u64 &occ)
{
    int loop = ++loopcounter;
  if(debug){  cout<<"\n ********loop ***********"<<loop;}
  if(debug){  cout<<" side "<<stm;}
  if(debug){  cout<<" pceval "<<pceval;}
  if(debug){  cout<<" left "<<numused[stm];}

   if(debug)
  {
        printattlists();
        cout<<"\n attackers[white] = ";
        printbitboard(attackers[cW]);
        cout<<"\n attackers[black] = ";
        printbitboard(attackers[cB]);
  }
 //if(debug){   system("PAUSE");}
    int value;
    int piece_value = getnext(stm);

  if(debug){  cout<<"\n Piece Value "<<piece_value;}


    if(!piece_value)
    {
    if(debug){    cout<<"\n no attackers, returning 0";}
        return 0;
    }

    /** find hidden here **/
  if(debug){  cout<<"\n used stm = "<<numused[stm];}
  fillhidden(stm,target,attlist[stm][numused[stm]].sq,occ,&attackers[stm]);

    value = pceval;

  if(debug){  cout<<"\n leaving loop "<<loop<<" value "<<value;}
    value -= xchange(stm^1, piece_value, target, occ);

  if(debug){  cout<<"\nback loop "<<loop<<" value "<<value;}

    if (value < 0)
    {
        value = 0;
      if(debug){  cout<<" value adjusted to "<<value;}
    }

    return value;
}

//4k3/8/8/3N4/8/5B2/8/4K3 w - - 0 1
int see(uint move)
{
    uint side = SIDENOW;
    uint oside = side^1;

    //cout<<"\n called see ";

  if(debug){  printboard(); }
  //if(debug){  mat.printmaterial();

    int val_captured = 0;
    int val_capturer = 0;

    uint from = FROM(move);
    uint to = TO(move);

    uint captured = CAP(move) /* pbP */;

	if(!captured) cout<<"\n error cap";
    //uint captured =  pbP ;

    u64 occ = ALL_BB;
    attackers[0] = 0x0ULL;
    attackers[1] = 0x0ULL;

    clearbit(from,occ);//remove moving piece

    val_captured = PCEVAL(captured);
    val_capturer = PCEVAL(BRDPCE(to));

    if(debug){cout<<"\n piece on board[to] = "<<piecechar(BRDPCE(to));}

    if(debug){cout<<"\n val_captured "<<val_captured<<" val_capturer "<<val_capturer;}

    fill_att_list(side,to,from,occ,&attackers[side]);
    fill_att_list(oside,to,from,occ,&attackers[oside]);

    sortlist(cW);
    sortlist(cB);

  if(debug)
  {
        printattlists();
        cout<<"\n attbrd[white] = ";
        printbitboard(attackers[cW]);
        cout<<"\n attbrd[black] = ";
        printbitboard(attackers[cB]);
  }

    if(numused[side]==0)
    {
       if(debug){ cout<<"\n no defenders ";}
        return val_captured;
    }

    loopcounter=0;

    val_captured -= xchange(side, val_capturer,to,occ);
if(debug){
    cout<<endl;}

    return (val_captured);
}
