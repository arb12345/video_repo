#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include "engine.h"
#include "board.h"
#include "squares.h"
#include "piecedefs.h"
#include "log.h"
#include "fen.h"
#include "make.h"
#include "movegen.h"
#include "attack.h"
#include "clock.h"
#include "eval.h"
#include "perft.h"
#include "searcher.h"
#include "utils.h"
#include "defs.h"
#include "book.h"
#include "bits.h"
#include "testers.h"

using namespace std;

#define FORCESIDE 3

uint pondermove;
uint ponderreply;

bool checkresult();
void xboardlevel(string str, int pos);
void sayfeatures();
void xboard_think();
void xboard_ponder();
void process_xboard();
//cXboard process;
bool parse_move(string move)
{
  if(move.length()<4)
  {
    if(islog())logger.file <<"Bad move length "<<move<<endl;
	return false;
  }

  //cout<<"\n into parse ";
  //printboard();cout<<endl;

  bool frcqsca = false;
  bool frcksca = false;
  if(tree->xb)
  {
		  if(move=="O-O") frcksca = true;
		  else if(move=="O-O-O") frcqsca = true;
  }

  if(engopt.variant!=2 || (frcksca==false && frcqsca==false))
  {
   if ((move[0] < 'a' || move[0] > 'h') || (move[1] < '1' || move[1] > '8') ||
	   (move[2] < 'a' || move[2] > 'h') || (move[3] < '1' || move[3] > '8') )
   {
	  if(islog())logger.file <<"Bad move chars "<<move<<endl;
	  return false;
   }
  }

  if(islog())logger.file <<"parsing "<<move<<endl;

  uint prompce = 0;
  if(move.length()>4 && frcqsca==false)
  {
	  if(move[4]=='q') { if(SIDENOW==cW) prompce = pwQ; else prompce = pbQ; }
	  else if(move[4]=='r') { if(SIDENOW==cW) prompce = pwR; else prompce = pbR; }
	  else if(move[4]=='b') { if(SIDENOW==cW) prompce = pwB; else prompce = pbB; }
	  else if(move[4]=='n') { if(SIDENOW==cW) prompce = pwN; else prompce = pbN; }
	  else
	  {
	      cout<<" UNDETECTED PROM ";
	      if(islog())logger.file <<"UNDETECTED PROM "<<move<<endl;
	      return false;
      }
  }

 unsigned int from = fr2sq(chartofile(move[0]), chartorank(move[1]));
 unsigned int to = fr2sq(chartofile(move[2]), chartorank(move[3]));

// cout<<"\n from "<<from<<" to "<<to<<endl;

 ASS(onbrd(from));
 ASS(onbrd(to));

 SETPLY(0);/** CRITICAL **/

 //check for FRC castle move in UCI mode - K takes R
 if(engopt.variant==2 && tree->uci)
 {
	 if(BRDPCE(from)==pwK && BRDPCE(to)==pwR)
	 {
		 if(RANK(from)!=RANK(to)) cout<<"\n Castling read error in FRC from UCI mode";
		 if(FILE(from)>FILE(to)) frcqsca=true;
		 else if(FILE(from)<FILE(to)) frcksca=true;
	 }
 }

 if(frcksca)
 {
	 if (SIDENOW==cW) { from = brd->frccasq[FRCWK]; to = G1; }
	 else { from = brd->frccasq[FRCBK]; to = G8; }
 }
 else if(frcqsca)
 {
	 if (SIDENOW==cW) { from = brd->frccasq[FRCWK]; to = C1; }
	 else { from = brd->frccasq[FRCBK]; to = C8; }
 }

 gen_all_moves(NULLMOVE);
 bool found = 0;
 uint movefound = 0;
 uint tempmove = NULLMOVE;
 //cout<<"\n genned "<<tree.mlist.getcount(tree.getply())<<" moves";
 for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
 {
   if(makemove(MOVE(PLYNOW,i)))
   {
     takemove();
     continue;
   }
   takemove();
   tempmove=MOVE(PLYNOW,i);

  // cout<<"\t\t"<<i+1<<": "<<printmove(tempmove)<<endl;

   if(FROM(tempmove)==from && TO(tempmove)==to)
   {
	   	if(prompce)
		{
			if(PROM(tempmove)==prompce) { movefound = tempmove; found = true; break;}
		}
		else
		{
			found=true;
			movefound = tempmove;
			break;
		}
   }
  }

   if(!found)
   {
	   cout<<"\n error move not found "<<move;
	   if(islog())logger.file <<"error move not found "<<move<<endl;
	   return false;
   }
    if(islog())logger.file <<"parsed move "<<move<<endl;


#ifdef DEBUG
  ASS(position_check());
#endif

   makemove(movefound);


  //cout<<"\n after parse ";
  //printboard();
   cout<<endl;
   return true;
}



bool checkresult()
{

    if(drawmaterial())
    {
        cout<<"\n1/2-1/2 {insufficient material(claimed by Jabba)}"<<endl;
		if(islog())logger.file <<"1/2-1/2 {insufficient material(claimed by Jabba)} "<<endl;
    }
    if (FIFTY > 100)
    {
     cout<<"\n1/2-1/2 {fifty move rule (claimed by Jabba)}"<<endl;
	 if(islog())logger.file <<"1/2-1/2 {fifty move rule (claimed by Jabba)} "<<endl;
    }
	if (countrepetition(BRDKEY) >= 2)
    {
     cout<<"\n1/2-1/2 {3-fold repetition (claimed by Jabba)}"<<endl;
	 if(islog())logger.file <<"1/2-1/2 {3-fold repetition (claimed by Jabba)} "<<endl;
	}



    gen_all_moves(NULLMOVE);

	uint played = 0;// no. moves we have played
	uint tempmove=NULLMOVE;
	for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
    {
        tempmove=MOVE(PLYNOW,i);
        if(makemove(MOVE(PLYNOW,i)))
        {
		 takemove();
		 continue;
		}
		played++;
     takemove();
	}

	if(played) return false;

	//no legal move for current side?
	bool inc = incheck(SIDENOW);

	if(inc)
	{
		if(SIDENOW == cW)
	    {
	      cout<<"\n0-1 {black mates (claimed by Jabba)}"<<endl;
	      if(islog())logger.file <<"0-1 {black mates (claimed by Jabba)} "<<endl;
	      return true;
        }
        else
        {
          cout<<"\n1-0 {white mates (claimed by Jabba)}"<<endl;
	      if(islog())logger.file <<"1-0 {white mates (claimed by Jabba)} "<<endl;
	      return true;
        }
    }
    else
    {
      cout<<"\n1/2-1/2 {stalemate (claimed by Jabba)}"<<endl;
	  if(islog())logger.file <<"1/2-1/2 {stalemate (claimed by Jabba)} "<<endl;
	  return true;
    }
}

//convert the level time control string to integers
void xboardlevel(string str, int pos)
{
   int val1=0,val2=0,val3=0,val4=0;
   str.erase(0, pos);

   //deal with time in "0:10" format
   if(str.find(':')!=string::npos)
   {
    string space = " ";
    str.replace(str.find(':'),1,space);
    istringstream iss(str);
    iss >> val1 >> val2 >> val3 >> val4;
    val2 = val2*60*1000 + val3*1000;
    val3 = val4*1000;
   }
   else
   {
    istringstream iss(str);
    iss >> val1 >> val2 >> val3;
    val2 = val2 * 60 * 1000;
    val3 = val3 * 1000;
   }

   //moves per session
   setmovestogo(val1,cW);
   setmovestogo(val1,cB);
   setmodemps(val1);
   engopt.moves = val1;

   //black and white time for session
   setsessiontime(val2,cW);
   setsessiontime(val2,cB);

   //increment
   setinc(val3,cW);
   setinc(val3,cB);

    //reset depth limiter
    setdepth(maxply);
    setdepthlimit(false);
}


void startxboard()
{
    engopt.engineside = FORCESIDE;
    engopt.ponder  = false;
    engopt.analyzemode = false;
    tree->uci = false;
    tree->xb = true;
	sayfeatures();
}

void sayfeatures()
{
	cout<<"\nfeature ping=1"<<endl;
	cout<<"feature setboard=1"<<endl;
	cout<<"feature usermove=1"<<endl;
	cout<<"feature time=1"<<endl;
	cout<<"feature reuse=1"<<endl;
	cout<<"feature analyze=1"<<endl;
	cout<<"feature myname=\""<<version<<"\""<<endl;
	cout<<"feature name=0"<<endl;
	cout<<"feature pause=0"<<endl;
	cout<<"feature playother=1"<<endl;
	cout<<"feature ics=1"<<endl;
	cout<<"feature variants=\"normal,fischerandom\""<<endl;
	cout<<"feature done=1"<<endl;
	fflush(stdout);
}


void xboard_think()
{
   if(islog())
     {
	   logger.file <<"Jabba entering think \nmovestogo "<<GETMTG(cW)<<"(w) "<<GETMTG(cB)<<"(b)";
	   logger.file <<"\ndepth "<<GETDEPTH;
	   logger.file <<"\nwtime "<<GETMOVETIME(cW);
	   logger.file <<"\nbtime "<<GETMOVETIME(cB);
	   logger.file <<"\nmovetime "<<GETTPM<<"\n";
	   if(GAMEMOVES > 1)
	   logger.file<<"last move made "<<printmove(lastmovemade())<<endl;
       if(onbrd(FROM(pondermove)) && onbrd(TO(pondermove)))
       {
           logger.file<<" was pondering "<<printmove(pondermove)<<endl;
           if(lastmovemade()==pondermove)
           logger.file<<" ponderhit "<<endl;
       }
     }

    cout<<" was pondering "<<printmove(pondermove)<<endl;

    if(lastmovemade()==pondermove)
    {
        PONDERHIT(true);
        cout<<" ponderhit "<<endl;
		//tree->status->mode = smPONDERHIT;
    }
    else
    {
        PONDERHIT(false);
    }

    pondermove = NULLMOVE;

	compute();
	fflush(stdout);
	uint side = SIDENOW;
    uint best = getbestmove();
    pondermove = getpondermove();

    if(islog()) logger.file <<"out of compute, bestmove "<<printmove(best);
    if(islog() && pondermove)logger.file<<" ponder "<<printmove(getpondermove())<<"\n";
#ifdef DEBUG
    logboard();
#endif
    if( !engopt.analyzemode )
	{
	    cout<<"\nmove "<<printmove(best)<<endl;
		if(pondermove) cout<<"pondermove "<<printmove(getpondermove())<<endl;

	    if(GETMPS!=0)
	    {
	       DECRMTG(side);
           if(islog())logger.file <<"reduced movestogo to "<<GETMTG(side)<<endl;
	    if(GETMTG(side)==0)
			     setmovestogo(GETMPS,side);
	    }
	    makemove(best);
	    checkresult();
	}
	fflush(stdout);
	if(islog())
	logger.file.flush();
}


void xboard_ponder()
{
	setmode(smPONDER);
	PONDERHIT(false);

	if(islog())
     {
	   logger.file <<"Jabba entering ponder\n";
     }

	  cout <<"Jabba entering ponder\n";

    uint ponderme = pondermove;

    if(checkmoveislegal(ponderme))
    {
        makemove(ponderme);
        compute();
	    takemove();
	    ponderreply = getbestmove();
    }
    else
    {
        compute();
		pondermove = NULLMOVE;
		ponderreply = NULLMOVE;
    }


    setmode(smNONE);
	timer->pondertime = (TIMEELAPSED);

    if(islog())
    {
        logger.file <<"called out of ponder, ";
		logger.file <<"pondered for "<<timer->pondertime;
        logger.file.flush();
    }

	cout<<"called out of ponder, ";
		cout <<"pondered for "<<timer->pondertime;
        fflush(stdout);

}


void process_xboard()
{
    setbuf(stdout, NULL);
    setbuf(stdout, NULL);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);

	startxboard();
	resettimeparam(cW);
	resettimeparam(cB);

	cout<<dec<<endl;

	string input;
	char line[65536];
	char command[65536];
    input.clear();
	int pos;
	char *ptr = NULL;

    for(;;)
    {
         /*
	   when starting a new loop, need to look for some things..
	   - is our side the side to move? If so, start the thinking process
	   - is the current position a draw, mate or stalemate? if so, spit out the result claim
        */
	   fflush(stdout);
	   input.clear();
	   logger.file.flush();

	//   cout<<"loop"<<endl;

	 if((SIDENOW == engopt.engineside ||  engopt.analyzemode ) && !checkresult())
	 {
	       xboard_think();
	       if(engopt.ponder)
	       {
	           xboard_ponder();
	       }
	 }

     if(!interrupted())
	 {
	     // if(!getline(cin, input)) input = "quit";
	     if (!fgets(line, 65535, stdin)) continue;
	     if (line[0] == '\n') continue;
         sscanf(line, "%s", command);
         ptr = line;
         while(*ptr !='\n' && *ptr != '\0')
         {
          input+=*ptr;
          *ptr++;
         }
	 }
	 else
	 {
	     input.clear();
	     resetinterrupted();
	     ptr = hascommand();
         while(*ptr !='\n' && *ptr != '\0')
         {
          input+=*ptr;
          *ptr++;
         }
         fflush(stdout);
	 }


	  if(islog()) logger.file<<"\nXBOARD COMMAND IN : "<<input<<endl;
	  cout<<"\nXBOARD COMMAND IN : "<<input<<endl;
	  fflush(stdout);


	  if(findsubstr("xboard", input, pos))
	  {
	     continue;
	  }
	  if(findsubstr("accepted ", input, pos))
	  {
        continue;
	  }
	  if(findsubstr("analyze", input, pos))
	  {
        engopt.analyzemode=true;
        setmode(smINFINITE);
        continue;
	  }
	  if(findsubstr("variant ", input, pos))
	  {
          input.erase(0, input.find("variant ")+8);
		  if(input=="fischerandom") engopt.variant=2;
		  else if(input=="normal") engopt.variant=1;

		  if(engopt.variant==2) cout<<"normal mode is on\n";
		  if(engopt.variant==2) cout<<"fischer random mode is on\n";
		  continue;
	  }
	  if(findsubstr("exit", input, pos))
	  {
        engopt.analyzemode=false;
        setmode(smNONE);
        continue;
	  }
	  else if(findsubstr("protover", input, pos))
	  {
	      sayfeatures();
          continue;
	  }
	  else if(findsubstr("new", input, pos))
	  {
	      engopt.engineside = cB;
	      setepdposition(startfen);
          resettimeparam(cW);
	      resettimeparam(cB);
		  reset_tables();
          continue;
	  }
	  else if(findsubstr("hard", input, pos))
	  {
	      engopt.ponder = true;
          continue;
	  }
	  else if(findsubstr("easy", input, pos))
	  {
	      engopt.ponder = false;
          continue;
	  }
	  else if(findsubstr("quit", input, pos))
	  {
	      delete_tables();
	      cout<<"\n Had quit command, bye!!!"<<endl;
	      exit(0);
	  }
	  else if(findsubstr("random", input, pos))
	  {
	      continue;
	  }
	  else if(findsubstr("force", input, pos))
	  {
	      engopt.engineside = FORCESIDE;
          continue;
	  }
	  else if(findsubstr("go", input, pos))
	  {
	      engopt.engineside = SIDENOW;
          continue;
	  }
	  else if(findsubstr("playother", input, pos))
	  {
	      engopt.engineside = (SIDENOW)^1;
          continue;
	  }
	  else if(findsubstr("white", input, pos))
	  {
	    /*  tree.game.setside(cW);
	      XbOpt->engineside = cB;
	      if(logfile.islog())
			  logfile.lognum("Setting engine side to ",XbOpt->engineside);
			  */
          continue;
	  }
	  else if(findsubstr("black", input, pos))
	  {
	     /* tree.game.setside(cB);
	      XbOpt->engineside = cW;
	      if(logfile.islog())
			  logfile.lognum("Setting engine side to ",XbOpt->engineside);
          */
		  continue;
	  }
	  else if(findsubstr("level ", input, pos))
	  {
	      xboardlevel(input, pos+6);
          continue;
	  }
	  else if(findsubstr("undo", input, pos))
	  {
	      if(GAMEMOVES>0)
		  {
			  takemove();
		  }
	      else
		  {
	       continue;
		  }
	  }
	  else if(findsubstr("sd ", input, pos))
	  {
	      setdepth(strtoint(input, pos+3));
          setmodetpm(false);
          setmodemtg(false);
          setdepthlimit(true);
          continue;
	  }
	  else if(findsubstr("st ", input, pos))
	  {
	      settimepermove(strtoint(input, pos+3)*1000);
          setmodetpm(true);
          setmodemtg(false);
          setdepthlimit(false);
          setdepth(maxply);
          continue;
	  }
	  else if(findsubstr("time ", input, pos))
	  {
          //cout<<"***************time recog ("<<input<<")"<<endl;
          fflush(stdout);
          setmodetpm(false);
          setdepth(maxply);
		  if(engopt.engineside==cW)
	      {
	          setmovetime(strtoint(input, pos+5)*10, cW);//note the *10 !!! xboard time comes in centiseconds
          }
	      else
	      {
	          setmovetime(strtoint(input, pos+5)*10, cB);//note the *10 !!! xboard time comes in centiseconds
          }
	      continue;
	  }
	  else if(findsubstr("otim ", input, pos))
	  {
	     // cout<<"*******************otim recog ("<<input<<")"<<endl;
	      fflush(stdout);
	      if(engopt.engineside==cW)
	      {
	          setmovetime(strtoint(input, pos+5)*10, cB);//note the *10 !!! xboard time comes in centiseconds
          }
	      else
	      {
	          setmovetime(strtoint(input, pos+5)*10, cW);//note the *10 !!! xboard time comes in centiseconds
	      }
	      continue;
	  }
	  else if(findsubstr("ping ", input, pos))
	  {
	      cout<<"pong "<<strtoint(input, pos+4)<<endl;
	      continue;
	  }
	  else if(findsubstr("usermove ", input, pos))
	  {
	      input.erase(0, input.find("usermove ")+9);
	      if(!parse_move(input))
	      {
	          cout<<"\n not understood move "<<input<<endl;
	          logboard();
	          logBB();
	          ASS(false);
			  continue;
	      }
	      continue;
	  }
	  else if(findsubstr("ics ", input, pos))
	  {
	      if(strtoint(input, pos+4)==1)
			  tree->opt->icsmode = true;
		  cout<<"\n ICS mode on \n";
          continue;
	  }
	  else if(findsubstr("print", input, pos))
	  {
	      printboard();
	      printmaterial();
	      cout<<endl;
	      continue;
	  }
	  else if(findsubstr("setboard ", input, pos))
	  {
	      input.erase(0, 9);
		  setepdposition(input.c_str());
	      continue;
	  }
	  else if(findsubstr("clearhash", input, pos))
	  {
          reset_tables();
          continue;
	  }
	  else if(findsubstr("perftfile", input, pos))
	  {
	   clearhistory();
       resettimeparam(cW);
	   resettimeparam(cB);
	   perftfile();
	   continue;
	  }
	  else if(findsubstr("eval", input, pos))
	  {
		 int ss = eval();
		 cout<<"\n eval score1: "<<ss;
		 mirrorboard();
		 int sss = eval();
		 cout<<"\n eval score2: "<<sss;
		 cout<<endl;
		 continue;
	  }
	  else if(findsubstr("fenstr", input, pos))
	  {
		 cout<<"\n";
		 cout<<fenfromboard();
		 continue;
	  }
	  else if(findsubstr("seeme", input, pos))
	  {
		 cout<<"\n";
		 setepdposition("k2r4/4n3/8/3N1R1R/8/1B6/K5b1/7q b - - 0 1");
         int move = (E3 | (D5<<7));
		 cout<<endl<<printmove(move);
		 cout<<see(move);
		 cout<<endl;
		 continue;
	  }
	  else if(findsubstr("probebook", input, pos))
	  {
		 uint mv;
		 uint sd = SIDENOW;
		 bookread.bookmove(mv,sd);
		 continue;
	  }
	  else if(findsubstr("movelist", input, pos))
	  {
		 cout<<"\n";
         gen_all_moves(NULLMOVE);
         printmovelist(PLYNOW);
		 cout<<endl;
		 continue;
	  }
	  else if(findsubstr("perft ", input, pos))
	  {
		 cout<<"\n";
         perftsingle(strtouint(input, pos+6));
		 cout<<endl;
		 continue;
	  }
	  else if(findsubstr("bitboards", input, pos))
	  {
		 cout<<"\n";
		 printBB();
		 cout<<endl;
		 continue;
	  }
	  else if(findsubstr("attack", input, pos))
	  {
		 cout<<"\n att";
		 showattacks(cB, F3);
		 cout<<endl;
		 continue;
	  }
	  else if(findsubstr("feature", input, pos))
	  {
		 features();
		 cout<<endl;
		 continue;
	  }
    }//end of while loop
}
//n1n5/1Pk5/8/8/8/8/5Kp1/5N1N w - - 0 1

