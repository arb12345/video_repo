#include <iostream>
#include <string>

#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "evalparam.h"
#include "magic.h"

int rookattackside = 10;
int rookattackdirect = 15;

int rookopenfile[2] = {5,5};
int rooksemiopenfile[2] = {10,10};
int rookseventhrank[2] = {20,20};


void score_rooks()
{
    uint piece;
	uint sq;
	uint rank;
	uint file;
	uint sq64;
	uint revsq;
	uint revsq64;
	uint oppkingrank;
	uint oppkingfile;

	piece = pwR;
	u64 pieceBB = GET_BB(piece);
	u64 moves;
	int mobop = 0;
	int mobend = 0;
	int sqrs;

    oppkingrank = ranks[KINGSQ(cB)];
    oppkingfile = files[KINGSQ(cB)];

    ASS(oppkingrank>=RANK1&&oppkingrank<=RANK8);

    while(pieceBB)
    {
      sq = POP64(pieceBB);
      sq64 = SQTO64(sq);

      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);

      file = files[sq];
      rank = ranks[sq];

      ASS(file>=FILEA&&file<=FILEH);
      ASS(rank>=RANK1&&rank<=RANK8);

      //mobility
      moves = rookmove(sq64,mat->allBB);
      moves &= (~mat->colBB[cW]);
      mobop = RmobminO;
      mobend = RmobminE;
      sqrs = popCount(moves);
      mobop += sqrs*RmobsqO;
      mobend += sqrs*RmobsqE;
      scorer->mob[cW][OPE] += mobop;
      scorer->mob[cW][END] += mobend;
      mobop = 0;
      mobend = 0;

      //king tropisim
      if(moves & scorer->bkcircle)
      {
          scorer->bkatt |= tropRbit;
      }

      if(FILEOPEN(P_BB(cW), file))
      {
          scorer->pos[cW][OPE] += RSemFile;
          scorer->pos[cW][END] += RSemFile;
          //cout<<"\n WR Semi open "<<printsquare(sq);
          if(FILEOPEN(P_BB(cB), file))
          {
              scorer->pos[cW][OPE] += ROpeFile;
              scorer->pos[cW][END] += ROpeFile;
          }

		  //opposing king is on the file
		  if(oppkingfile==file-1 || oppkingfile==file+1)
		  {
		      scorer->pos[cW][OPE] += RAttSide;
              scorer->pos[cW][END] += RAttSide;
		  }
		  else if(oppkingfile==file)
		  {
		      scorer->pos[cW][OPE] += RAttDir;
		      scorer->pos[cW][END] += RAttDir;
		  }

      }

      if(rank==RANK7 && ( RANKOCC(P_BB(cB), rank) || oppkingrank >= RANK7) )
      {
          scorer->pos[cW][OPE] += RSevOpe;
		  scorer->pos[cW][END] += RSevEnd;
      }
    }


    piece = pbR;
	pieceBB = GET_BB(piece);

    oppkingrank = ranks[KINGSQ(cW)];
    oppkingfile = files[KINGSQ(cW)];

    ASS(oppkingrank>=RANK1&&oppkingrank<=RANK8);

    while(pieceBB)
    {
      sq = POP64(pieceBB);
      sq64 = SQTO64(sq);
      revsq = SQREV(sq);
      revsq64 = SQTO64(revsq);

      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);

      file = files[sq];
      rank = ranks[sq];

      ASS(file>=FILEA&&file<=FILEH);
      ASS(rank>=RANK1&&rank<=RANK8);

      //mobility
      moves = rookmove(sq64,mat->allBB);
      moves &= (~mat->colBB[cB]);
      mobop = RmobminO;
      mobend = RmobminE;
      sqrs = popCount(moves);
      mobop += sqrs*RmobsqO;
      mobend += sqrs*RmobsqE;
      scorer->mob[cB][OPE] += mobop;
      scorer->mob[cB][END] += mobend;
      mobop = 0;
      mobend = 0;

      //king tropisim
      if(moves & scorer->wkcircle)
      {
          scorer->wkatt |= tropRbit;
      }

      if(FILEOPEN(P_BB(cB), file))
      {
          //cout<<"\n BR Semi open "<<printsquare(sq);
          scorer->pos[cB][OPE] += RSemFile;
          scorer->pos[cB][END] += RSemFile;

          if(FILEOPEN(P_BB(cW), file))
          {
              //cout<<" BR open "<<printsquare(sq);
              scorer->pos[cB][OPE] += ROpeFile;
              scorer->pos[cB][END] += ROpeFile;
          }

		  //opposing king is on the file
		  if(oppkingfile==file-1 || oppkingfile==file+1)
		  {
		      scorer->pos[cB][OPE] += RAttSide;
              scorer->pos[cB][END] += RAttSide;
		  }
		  else if(oppkingfile==file)
		  {
		      scorer->pos[cB][OPE] += RAttDir;
		      scorer->pos[cB][END] += RAttDir;
		  }

      }

      if(rank==RANK2 && ( RANKOCC(P_BB(cW), rank) || oppkingrank <= RANK2) )
      {
          scorer->pos[cB][OPE] += RSevOpe;
		  scorer->pos[cB][END] += RSevEnd;
      }
    }
}
