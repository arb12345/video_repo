#include <iostream>
#include <string>

#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "board.h"
#include "piecedefs.h"
#include "magic.h"
#include "evalparam.h"

void score_bishops()
{
    uint piece;
	uint sq64;
	uint enemy;

	piece = pwB;
	enemy = cB;

    int sqrs = 0;
    int mobop = 0;
    int mobend = 0;

    u64 pieceBB = GET_BB(piece);
    u64 moves;

    while(pieceBB)
    {
      sq64 = POP(pieceBB);
      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);

      //mobilitiy
      moves = bishopmove(sq64,mat->allBB);
      moves &= (~mat->colBB[cW]);
      mobop = BmobminO;
      mobend = BmobminE;
      sqrs = popCount(moves);
      mobop += sqrs*BmobsqO;
      mobend += sqrs*BmobsqE;
      scorer->mob[cW][OPE] += mobop;
      scorer->mob[cW][END] += mobend;
      mobop = 0;
      mobend = 0;

      //king tropisim
      if(moves & scorer->bkcircle)
      {
          scorer->bkatt |= tropBbit;
      }
    }


    sqrs = 0;
    piece = pbB;
	enemy = cW;
    pieceBB = GET_BB(piece);

    while(pieceBB)
    {
      sq64 = POP(pieceBB);
      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);

      //mobility
      moves = bishopmove(sq64,mat->allBB);
      moves &= (~mat->colBB[cB]);
      mobop = BmobminO;
      mobend = BmobminE;
      sqrs = popCount(moves);
      mobop += sqrs*BmobsqO;
      mobend += sqrs*BmobsqE;
      scorer->mob[cB][OPE] += mobop;
      scorer->mob[cB][END] += mobend;
      mobop = 0;
      mobend = 0;

      //king tropisim
      if(moves & scorer->wkcircle)
      {
          scorer->wkatt |= tropBbit;
      }
    }
}
