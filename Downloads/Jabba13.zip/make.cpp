#include <iostream>
#include "make.h"
#include "defs.h"
#include "attack.h"
#include "bits.h"
#include "material.h"

//r2q3n/ppp2pk1/3p4/5Pr1/2NP1Qp1/2P2pP1/PP3K2/4R2R w - -
//-epd -i wac.epd -o wac.txt -d 5
using namespace std;

const bool debug = true;

#define WKR brd->frccasq[FRCWKR]
#define WQR brd->frccasq[FRCWQR]
#define BKR brd->frccasq[FRCBKR]
#define BQR brd->frccasq[FRCBQR]


bool makemove(uint &move)
{
   // cout<<" make() ";
  //  printboard();
#ifdef DEBUG
  ASS(position_check());
#endif
  uint gamemoves = GAMEMOVES;
  uint side = SIDENOW;
  uint from = FROM(move);
  uint to = TO(move);
  uint captured = BRDPCE(to);
  uint piece = BRDPCE(from);

 // cout<<"\nfrom "<<from;
  //cout<<" to "<<to;
  //printboard();

  ASS(onbrd(from));
  ASS(onbrd(to));
  ASS(gamemoves<maxgamelength);
  ASS(side==cW||side==cB);
  ASS(piecegood(captured)||captured==pE);
  if(!piecegood(piece))
  {
      printboard();
	  printmaterial();
	  printmovelist(PLYNOW);
      cout<<"\n trying "<<printmove(move);
      cout<<"\n piece = "<<piece;
      printallhistory();
	  ASS(piecegood(piece));
  }

  ASS(piecegood(piece));

#ifdef DEBUG
  if(captured!=pE)
  {
    ASS(PCECOL(captured)!=side);
  }
#endif

  //put current info into the history...
  his->hisarray[gamemoves].move = move;
  his->hisarray[gamemoves].enpas = ENPAS;
  his->hisarray[gamemoves].castle = CAPERM;
  his->hisarray[gamemoves].fifty = FIFTY;
  his->hisarray[gamemoves].captured = captured;
  his->hisarray[gamemoves].key = BRDKEY;
  his->hisarray[gamemoves].pawnkey = PAWNKEY;

  hashcastle();
  hashside();
  hashenpas();

  //castle permissons and enpassant reset
  SETENPAS(NOSQ);
  brd->castleperm&=castlebits[from];
  brd->castleperm&=castlebits[to];

  if(piece==pwK) mat->kingsq[cW] = to;
  else if (piece==pbK) mat->kingsq[cB] = to;


  //castling - handled differently because in FRC the king can remain on the same sq
  //due to the fact the rook can also be on the target sq, the rook and king need to both
  //be removed before putting them on the target squares
  if(FLAG(move)==FlagCA)
  {
     ASS(piece==pwK || piece==pbK);
     if(to!=from)//remove the king if needed
     {
         //SETPCE(piece,to);
         SETPCE(pE,from);

         movepiece(piece, from, to);
         movepsqt(piece, from, to);

         hashpiece(piece,from);
         hashpiece(piece,to);
     }
     else
     {
         his->hisarray[gamemoves].captured = pE;
     }

     if(side==cW)
     {
       if(to==G1)
       {
         SETPCE(pE,WKR);
		 SETPCE(pwR,F1);
         SETPCE(pwK,to);
         movepiece(pwR, WKR, F1);
         movepsqt(pwR, WKR, F1);
         hashpiece(pwR,WKR);
         hashpiece(pwR,F1);
       }
       else
       {
         ASS(to==C1);
         SETPCE(pE,WQR);
		 SETPCE(pwR,D1);
         SETPCE(pwK,to);
         movepiece(pwR, WQR, D1);
         movepsqt(pwR, WQR, D1);
         hashpiece(pwR,WQR);
         hashpiece(pwR,D1);
       }
     }
     else
     {
       ASS(side==cB);
       if(to==G8)
       {
         SETPCE(pE,BKR);
		 SETPCE(pbR,F8);
         SETPCE(pbK,to);
         movepiece(pbR, BKR, F8);
         movepsqt(pbR, BKR, F8);
         hashpiece(pbR,BKR);
         hashpiece(pbR,F8);
       }
       else
       {
         ASS(to==C8);
         SETPCE(pE,BQR);
		 SETPCE(pbR,D8);
         SETPCE(pbK,to);
         movepiece(pbR, BQR, D8);
         movepsqt(pbR, BQR, D8);
         hashpiece(pbR,BQR);
         hashpiece(pbR,D8);
       }
     }
  }
  else
  {
  //move the piece being moved
  SETPCE(piece,to);
  SETPCE(pE,from);

  hashpiece(piece,from);
  hashpiece(piece,to);

  if(captured>pE)
  {
   SETFIFTY(0);
   removepiece(captured, to);
   removepsqt(captured, to);
   hashpiece(captured,to);
   if(ISPAWN(captured))
   {
    hashpawn(captured,to);
   }
  }
  //placing here critical due to BB bit setting
  movepiece(piece, from, to);
  movepsqt(piece, from, to);

  switch (piece)
  {
         case pwP:
              SETFIFTY(0);
              hashpawn(pwP,from);
              hashpawn(pwP,to);
              if(FLAG(move)==FlagEP)
              {
                SETPCE(pE,to+S);
                removepiece(pbP,(to+S));
                removepsqt(pbP, to+S);
                hashpiece(pbP,(to+S));
                hashpawn(pbP,(to+S));
              }
              else if(PROM(move))
              {
                   ASS(RANK(to)==RANK8);
                   removepiece(pwP,to);
                   removepsqt(pwP, to);
                   hashpiece(pwP,to);
                   hashpawn(pwP,to);
                   switch (PROM(move))
                   {
                      case pwQ :
                           SETPCE(pwQ,to);
                           addpiece(pwQ,to);
                           addpsqt(pwQ, to);
                           hashpiece(pwQ,to);
                           break;
                      case pwR :
                           SETPCE(pwR,to);
                           addpiece(pwR,to);
                           addpsqt(pwR, to);
                           hashpiece(pwR,to);
                           break;
                      case pwB :
                           SETPCE(pwB,to);
                           addpiece(pwB,to);
                           addpsqt(pwB, to);
                           hashpiece(pwB,to);
                           break;
                      case pwN :
                           SETPCE(pwN,to);
                           addpiece(pwN,to);
                           addpsqt(pwN, to);
                           hashpiece(pwN,to);
                           break;
                      default: cout<<"\n prom piece error"; exit(1);
                      break;

                   };
              }
              else if(RANK(from)==RANK2 && RANK(to)==RANK4)
              {
                   SETENPAS(to+S);
                   ASS(RANK(ENPAS)==RANK3);
              }
              break;
         case pbP:
              SETFIFTY(0);
              hashpawn(pbP,from);
              hashpawn(pbP,to);
              if(FLAG(move)==FlagEP)
              {
                SETPCE(pE,to+N);
                removepiece(pwP,(to+N));
                removepsqt(pwP,(to+N));
                hashpiece(pwP,(to+N));
                hashpawn(pwP,(to+N));
              }
              else if(PROM(move))
              {
                   ASS(RANK(to)==RANK1);
                   removepiece(pbP,to);
                   removepsqt(pbP, to);
                   hashpiece(pbP,to);
                   hashpawn(pbP,to);
                   switch (PROM(move))
                   {
                      case pbQ :
                           SETPCE(pbQ,to);
                           addpiece(pbQ,to);
                           addpsqt(pbQ, to);
                           hashpiece(pbQ,to);
                           break;
                      case pbR :
                           SETPCE(pbR,to);
                           addpiece(pbR,to);
                           addpsqt(pbR, to);
                           hashpiece(pbR,to);
                           break;
                      case pbB :
                           SETPCE(pbB,to);
                           addpiece(pbB,to);
                           addpsqt(pbB, to);
                           hashpiece(pbB,to);
                           break;
                      case pbN :
                           SETPCE(pbN,to);
                           addpiece(pbN,to);
                           addpsqt(pbN, to);
                           hashpiece(pbN,to);
                           break;

                      default: cout<<"\n prom piece error"; exit(1);
                      break;
                   };
              }
              else if(RANK(from)==RANK7 && RANK(to)==RANK5)
              {
                   SETENPAS(to+N);
                   ASS(RANK(ENPAS)==RANK6);
              }
              break;
         default: break;
  };
  }

#ifdef DEBUG
uint kingsq = KINGSQ(side);
  if(side==cW)
  ASS(BRDPCE(kingsq)==pwK);
  else
  ASS(BRDPCE(kingsq)==pbK);
#endif

//cout<<"\n before side change side = "<<SIDENOW;


  CHANGESIDE;
  INCRPLY;
  INCRGAMEMOVES;
 //cout<<"\n After side change side = "<<SIDENOW;

  hashcastle();
  hashside();
  hashenpas();


 #ifdef DEBUG
   ASS(position_check());
   #endif

  return incheck(side);
}

void takemove()
{

 // cout<<"\n take side in "<<SIDENOW;
 #ifdef DEBUG
   ASS(position_check());
   #endif

  DECRGAMEMOVES;
  DECRPLY;
  CHANGESIDE;

  uint gamemoves = GAMEMOVES;
  uint side = SIDENOW;

  uint move = HISMOVE(gamemoves);
  uint from = FROM(move);
  uint to = TO(move);
  uint piece = BRDPCE(to);
  uint captured = HISCAPTURE(gamemoves);

  SETKEY(HISKEY(gamemoves));
  SETPKEY(HISPKEY(gamemoves));
  SETFIFTY(HISFIFTY(gamemoves));
  SETENPAS(HISENPAS(gamemoves));
  SETCASTLE(HISCASTLE(gamemoves));


  if(piece==pwK) mat->kingsq[cW] = from;
  else if (piece==pbK) mat->kingsq[cB] = from;

  ASS(onbrd(from));
  ASS(onbrd(to));
  ASS(gamemoves<maxgamelength);
  ASS(side==cW||side==cB);
  ASS(piecegood(piece));
  ASS(captured!=pwK&&captured!=pbK);
#ifdef DEBUG
  if(captured!=pE)
  ASS(PCECOL(captured)!=side);//not changed the side yet, so captureds has the same colour
#endif

   //castling
   if(FLAG(move)==FlagCA)
   {
     ASS(piece==pwK || piece==pbK);
     if(to!=from)
     {
         SETPCE(pE,to);
         movepiece(piece, to, from);
         movepsqt(piece, to, from);
     }
     if(side==cW)
     {
       if(to==G1)
       {
         SETPCE(pE,F1);
		 SETPCE(pwR,WKR);
         SETPCE(pwK,from);
         movepiece(pwR, F1, WKR);
         movepsqt(pwR, F1, WKR);
       }
       else
       {
         ASS(to==C1);
		 SETPCE(pE,D1);
         SETPCE(pwR,WQR);
         SETPCE(pwK,from);
         movepiece(pwR, D1, WQR);
         movepsqt(pwR, D1, WQR);
       }
     }
     else
     {
       ASS(side==cB);
       if(to==G8)
       {
         SETPCE(pE,F8);
		 SETPCE(pbR,BKR);
         SETPCE(pbK,from);
         movepiece(pbR, F8, BKR);
         movepsqt(pbR, F8, BKR);
       }
       else
       {
         ASS(to==C8);
		 SETPCE(pE,D8);
         SETPCE(pbR,BQR);
         SETPCE(pbK,from);
         movepiece(pbR, D8, BQR);
         movepsqt(pbR, D8, BQR);
       }
     }
   }
   else
   {


  //move piece on board back
  SETPCE(piece,from);
  SETPCE(captured,to);

  movepiece(piece, to, from);
  movepsqt(piece, to, from);

  if(captured>pE)
  {
    addpiece(captured, to);
    addpsqt(captured, to);
  }


    //special pawn moves
   if(FLAG(move)==FlagEP)
   {
      if(side==cW)
      {
          SETPCE(pbP,to+S);
          addpiece(pbP,(to+S));
          addpsqt(pbP, (to+S));
      }
      else
      {
          SETPCE(pwP,to+N);
          addpiece(pwP,(to+N));
          addpsqt(pwP, (to+N));
      }
   }
   else if(PROM(move))
   {
      removepiece(PROM(move),from);
      removepsqt(PROM(move),from);
      if(side==cW)
      {
        addpiece(pwP,from);
        addpsqt(pwP, from);
        SETPCE(pwP,from);
      }
      else
      {
        addpiece(pbP,from);
        addpsqt(pbP, from);
        SETPCE(pbP,from);
      }
   }
   }


 // cout<<"\n take side out "<<SIDENOW;
   #ifdef DEBUG

   if(!position_check())
   {
       logger.file<<"\n ######## move was "<<printmove(move)<<" ######################### <<"<<move<<"\n";
       logger.file<<" ######## piece was "<<piecechars[piece]<<" #########################\n";
       logger.file<<" ######## captured was "<<piecechars[captured]<<" #########################\n";
   }
   ASS(position_check());
   #endif
}


void makenullmove()
{

  ASS(position_check());

  uint gamemoves = GAMEMOVES;

  ASS(gamemoves<maxgamelength);

  //put current info into the history...
  his->hisarray[gamemoves].move = NULLMOVE;
  his->hisarray[gamemoves].enpas = ENPAS;
  his->hisarray[gamemoves].castle = CAPERM;
  his->hisarray[gamemoves].fifty = FIFTY;
  his->hisarray[gamemoves].captured = pE;
  his->hisarray[gamemoves].key = BRDKEY;
  his->hisarray[gamemoves].pawnkey = PAWNKEY;

  hashside();
  hashenpas();

  SETENPAS(NOSQ);
  CHANGESIDE;
  INCRPLY;
  INCRGAMEMOVES;

  hashside();
  hashenpas();

#ifdef DEBUG
   ASS(!incheck(SIDENOW^1));
#endif

}

void takenullmove()
{

  DECRGAMEMOVES;
  DECRPLY;

  uint gamemoves = GAMEMOVES;
  ASS(gamemoves<maxgamelength);

  SETKEY(HISKEY(gamemoves));
  SETPKEY(HISPKEY(gamemoves));
  SETFIFTY(HISFIFTY(gamemoves));
  SETENPAS(HISENPAS(gamemoves));
  SETCASTLE(HISCASTLE(gamemoves));

  CHANGESIDE;

  #ifdef DEEPDEBUG
  ASS(position_check());
  #endif
}
