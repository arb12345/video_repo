#ifndef STATS_H
#define STATS_H

#include <vector>
#include <list>
#include <string>
#include <fstream>

#include "move.h"
#include "defs.h"
#include "board.h"
#include "material.h"
#include "movelist.h"
#include "history.h"

using namespace std;

const int indexmax = (2*3*3*3*9)*(2*3*3*3*9);


struct sEntry {
    double expectedresult;
    double actualresult;
    uint totalgames;
    uint index;

    int wq,wr,wb,wn,wp,bq,br,bb,bn,bp;
    int matdiff;
};

struct sSmallentry {
    double expectedscore;
    double actualscore;
    uint totalgames;
};

/*
class for collecting stats for material situations from a given database
*/

class cStatmake {

    private:

    //psqt stats
    sSmallentry p[2][BRDSQ];
    sSmallentry n[2][BRDSQ];
    sSmallentry b[2][BRDSQ];
    sSmallentry r[2][BRDSQ];
    sSmallentry q[2][BRDSQ];
    sSmallentry k[2][BRDSQ];

    sSmallentry knsup[2][BRDSQ];

    double minelo,maxelo;
    double slow,slownotok;
    double stored;
    int discardeddiff,discardedelo,discardedres,newwrite;
    double countgames,whitescore,blackscore;
    double whiteadvantage,whitepawnup;

    bool makesan(const string make);
    bool datameasured(const uint &plys, const uint result);
    double computescore(double Ra, double Rb);
    void getelo(const string line, double &Rw, double &Rb);
    void addentry(uint lastindex, double expscore, double score);
    void printtable();
    void writetable();
    void cleartable();
    void printentry(sEntry data);
    void printresult(double exp, double act, double gam, string name);
    void features(const double exp, const double act);
    void clean_eval();
	uint makeindex(int wq, int wr, int wb, int wn, int wp, int bq, int br, int bb, int bn, int bp);
	void printtableentry(uint i);
    uint getmatindex();
    bool verifyindex(uint index);
    double resultcp(double exp, uint gam, double act);
    void printfeatures();
    double getresult(double exp, double act, double gam);

    vector<sEntry> table;

    public:
    cStatmake();
    void readpgn();
    void readtable();
    void analysedata();

    ifstream ifile;
    ofstream ofile;
};

#endif

