#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <stdlib.h>

#include "tuner.h"
#include "move.h"
#include "defs.h"
#include "board.h"
#include "material.h"
#include "movelist.h"
#include "history.h"
#include "fen.h"
#include "movegen.h"
#include "make.h"
#include "log.h"
#include "bits.h"
#include "utils.h"
#include "clock.h"
#include "evalparam.h"
#include "eval.h"

using namespace std;

/*
 from a given pgn file, create a file of epd positions, taken from the stats class
*/

cTuner::cTuner()
{
    ;
}

bool cTuner::verifyindex(uint index)
{
    uint wq,wr,wb,wn,wp,bq,br,bb,bn,bp;

    wq = PCENUM(pwQ);
    wr = PCENUM(pwR);
    wb = PCENUM(pwB);
    wn = PCENUM(pwN);
    wp = PCENUM(pwP);
    bq = PCENUM(pbQ);
    br = PCENUM(pbR);
    bb = PCENUM(pbB);
    bn = PCENUM(pbN);
    bp = PCENUM(pbP);

    if( (wq > 1) || (wr > 2) || (wb > 2) || (wn > 2) || (bq > 1) || (br > 2) || (bb > 2) || (bn > 2) ) {
        return true;
    }

    uint wq1 = index % 2; index /= 2;
    uint wr1 = index % 3; index /= 3;
    uint wb1 = index % 3; index /= 3;
    uint wn1 = index % 3; index /= 3;
    uint wp1 = index % 9; index /= 9;
    uint bq1 = index % 2; index /= 2;
    uint br1 = index % 3; index /= 3;
    uint bb1 = index % 3; index /= 3;
    uint bn1 = index % 3; index /= 3;
    uint bp1 = index % 9; index /= 9;

    if( wq1 != wq || wr1 != wr || wb1 != wb || wn1 != wn || wp1 != wp || bq1 != bq || br1 != br || bb1 != bb || bn1 != bn || bp1 != bp ) {
        cout<<"*** Bad index!\n";
        printboard();
        return false;
    }

    return true;
}


uint cTuner::getmatindex()
{
    uint wq,wr,wb,wn,wp,bq,br,bb,bn,bp;

    wq = PCENUM(pwQ);
    wr = PCENUM(pwR);
    wb = PCENUM(pwB);
    wn = PCENUM(pwN);
    wp = PCENUM(pwP);
    bq = PCENUM(pbQ);
    br = PCENUM(pbR);
    bb = PCENUM(pbB);
    bn = PCENUM(pbN);
    bp = PCENUM(pbP);

    if( (wq > 1) || (wr > 2) || (wb > 2) || (wn > 2) || (bq > 1) || (br > 2) || (bb > 2) || (bn > 2) ) {
        return 0;
    }

    uint index = wq +
                  2*(wr +
                  3*(wb +
                  3*(wn +
                  3*(wp +
                  9*(bq +
                  2*(br +
                  3*(bb +
                  3*(bn +
                  3*(bp)))))))));

    verifyindex( index );

    return index;
}

bool cTuner::materialequal()
{
    return (MATERIAL(cW)-MATERIAL(cB));
}



bool compare(const fenstore &one, const fenstore &two)
{
        return (one.key < two.key);
}

void cTuner::sortfenlines()
{
   cout<<"\n read in "<<fenlines.size()<<" fen lines \n";

  // cout<<"\n";
  // for(uint i = 0; i < fenlines.size(); ++i)
  // cout<<fenlines[i].key<<endl;
   cout<<"\nbeginning sort.... \n";
   sort(fenlines.begin(), fenlines.end(), compare);
   cout<<"sort over \n";
  // for(uint i = 0; i < fenlines.size(); ++i)
  // cout<<fenlines[i].key<<endl;;
   cout<<"removing duplicates...\n";

   vector<fenstore> writeme;

   uint start = uint(clock());

   u64 lastkey = 0;
   for(uint i = 0; i < fenlines.size(); ++i)
   {
       if(fenlines[i].key != lastkey)
       {
           writeme.push_back(fenlines[i]);
           lastkey = fenlines[i].key;
       }
       if(uint(clock())-start > 1000) { start = uint(clock()); cout<<" . "; }
   }

  // for(uint i = 0; i < writeme.size(); ++i)
  // cout<<writeme[i].key<<endl;
   cout<<"found "<<writeme.size()<<" unique entries\n";

   ofstream fenfile;
   char filenum = '1';
   string fenfilename = FileOutName;
   fenfilename += filenum;
   fenfilename += ".epd";
   cout<<"\n opening "<<fenfilename;
   fenfile.open(fenfilename.c_str(), ios::trunc);

   for(uint i = 0; i < writeme.size(); ++i)
   {
       if(i >= maxperfile) break;	  
	   if(i!=0 && (i % maxperfile == 0))
       {
           fenfile.close();
           filenum++;
           fenfilename.clear();
           fenfilename = FileOutName;
           fenfilename += filenum;
           fenfilename += ".epd";
           cout<<"\n opening "<<fenfilename;
           fenfile.open(fenfilename.c_str(), ios::trunc);
       }
       fenfile<<writeme[i].fen<<endl;
   }
   fenfile.close();
   cout<<"writing complete\n";
}



bool cTuner::makesan(const string make)
{

    if(make=="1/2-1/2" || make=="0-1" || make=="1-0" || make=="*" || make == " ")
    return false;
    SETPLY(0);
    uint move;
    string made;
    move = santomove(make);
    if(makemove(move))
    {
       slow++;
        takemove();
        uint i;
        vector<string> made;
        vector<uint> templist;
        string temp;
        uint tempmove;
        gen_all_moves(NULLMOVE);

        for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
        {
           tempmove = MOVE(PLYNOW,i);
           if (makemove(tempmove)){takemove();continue;}
           takemove();
           temp = movetosan(tempmove);
           made.push_back(temp);
           templist.push_back(tempmove);
        }

        bool have = false;
        for(i=0; i < made.size(); ++i)
        {
            temp = made[i];
            move=templist[i];
            if(temp==make)
            {
             have = true;
             makemove(move);
            }
        }
        if(!have)
        {
            slownotok++;
            return false;
        }
    }
    return true;
}

void cTuner::readpgn()
{
    string fenline;
    fenstore tempfenstore;
    fenlines.clear();
    uint gameresult;
    uint index;
    uint lastindex;
    slow=0;
    slownotok=0;
    int countgames=0;

    string movetomake; //the move that will be pushed back into the vector

    string lines;//string reading in each line of the pgn file
    string gameline;//will conatin the whole game line as one strip
    int found = -1;//set to 0 when we find the start of a game (string starts 1.)
    string::iterator pline = lines.begin();//iterate through the line

    bool ingame = false;
    bool lastline = false;
    int plysincecapture = 0;

    if (FileIn.is_open())
    {
      while (! FileIn.eof() )
      {       
       getline (FileIn,lines);
       if(lines[0]=='[')
       {
          continue;
       }
       if(!ingame)//if we're not in a game, see if we've started the next game
       {
        if(fenlines.size() > maxperfile-1) break; //stop if we've processes max num of positions
        found=lines.find("1.",0,2);
        if(found==0)
        {
            setepdposition(startfen);
            clearhistory();
            ingame=true;
            gameline.clear();
            countgames++;
            cout<<"\r---> game "<<countgames<<" slow "<<slow<<" notok "<<slownotok<<" fen's stored "<<fenlines.size();

            gameresult = 0;

            found=lines.find("0-1",0,3);
            if(found!=-1)
            { gameresult = 0; /*cout<<"\n black win "<<lines;*/}
            else
            {
                found=lines.find("1/2-1/2",0,7);
                if(found!=-1)
                { gameresult = 0;/*cout<<"\n draw  "<<lines;*/ }
                else
                {
                found=lines.find("1-0",0,3);
                if(found!=-1)
                { gameresult = 0;/*cout<<"\n white win  "<<lines;*/ }
                else
                {
                    found=lines.find("*",0,1);
                    if(found!=-1)
                    { gameresult = 0;/*cout<<"\n white win  "<<lines;*/ }
                }
             }
            }
            if(found!=-1)  { lastline=true; }
        }// now in a game
       }
       else // we're in a game - is this the last line?
       {
        gameresult = 0;

        found=lines.find("0-1",0,3);
        if(found!=-1)
        { gameresult = 0; }
        else
        {
            found=lines.find("1/2-1/2",0,7);
            if(found!=-1)
            { gameresult = 0; }

            else
            {
               found=lines.find("1-0",0,3);
               if(found!=-1)
               { gameresult = 0; }
               else
               {
                found=lines.find("*",0,1);
                if(found!=-1)
                { gameresult = 0; }
               }
            }
        }
        if(found!=-1)  { lastline=true; }
       }

       if(ingame) //game move now started, now store iterate and make moves
       {
         //if the new line doesn't start with a space, make sure there's a space put in if the last one didn't end with
         //a space - don't do this if we're processing the first line!
         if(!(lines[0]=='1' && lines[1]=='.'))
         {
             if(gameline[gameline.length()-1] != ' ')
             {
                 if(lines[0]!=' ')
                 {
                    gameline+=" ";
                 }
             }
         }
         gameline+=lines;
         if(!lastline) {continue;}

       /*
       now have the gameline stored in gameline as a one line string 1.e4 e5 2.Nf3 etc.
       */
         ingame=false;
         lastline=false;
         pline = gameline.begin();
         plysincecapture=0;
         lastindex = getmatindex();
         plysincecapture = 1;

         //cout<<"\n new game "<<countgames<<" "<<gameline;

         while(pline != gameline.end())
         {
               movetomake.clear();
               if(pline[0]=='.')//hit dot indicating move for white
               {
                pline++;
                if(pline[0]==' ') pline++;//if there's a space after the dot, move to next

                for(;pline != gameline.end();pline++)
                {
					if(*pline==' ') break;
					movetomake += *pline;
                }
                if(!makesan(movetomake)){break; }

                if(BIG(cW)+BIG(cB) < (uint)minpieces) break;

                index = getmatindex();
                if(index!=0){  if(verifyindex(index)==false) cout<<"\n index error2"; }
                if(index!=lastindex)
                {
                    lastindex = index;
                    plysincecapture = 1;
                }
                else
                {
                    plysincecapture++;
                }

                if(plysincecapture>movesincecapture)
                {
                  if(abs(TOTMAT) <= materialbalance)
                  {
                   fenline = fenfromboard();
                   tempfenstore.fen = fenline;
                   tempfenstore.key = BRDKEY;
                   fenlines.push_back(tempfenstore);
                  }
                }

                pline++;//should be looking at the first letter of the black move..
                movetomake.clear();
                for(;pline != gameline.end();pline++)
                {
					if(*pline==' ') break;
					movetomake += *pline;
                }

               if(!makesan(movetomake)) {  break; }

               if(BIG(cW)+BIG(cB) < (uint)minpieces) break;

               index = getmatindex();
                if(index!=0){  if(verifyindex(index)==false) cout<<"\n index error2"; }
                if(index!=lastindex)
                {
                    lastindex = index;
                    plysincecapture = 1;
                }
                else
                {
                    plysincecapture++;
                }

                if(plysincecapture>movesincecapture)
                {
                  if(abs(TOTMAT) <= materialbalance)
                  {
                   fenline = fenfromboard();
                   tempfenstore.fen = fenline;
                   tempfenstore.key = BRDKEY;
                   fenlines.push_back(tempfenstore);
                  }
                }

               }
			    pline++;
               if(GAMEMOVES >= 512) break;
         }

       }
      }
    }
    else
    {
        cout<<"\n File not found";
    }
    sortfenlines();
}

/*
make an epd file from a file of pgn games, runs in console input mode for settings
*/
void cTuner::makeepd()
{
   cout<<"\n Jabba Tuner -> Make EPD file \n";

   cout<<"\n Paramters: please input required settings\n";
   cout<<"moves since capture (give -1 for all) -> ";
   cin>>movesincecapture;
   cout<<"min pieces on board -> ";
   cin>>minpieces;
   cout<<"material balance bounds (give 5000 for ireelevant) -> ";
   cin>>materialbalance;
   cout<<"max positions -> ";
   cin>>maxperfile;
   cout<<"pgn filename (without .pgn)-> ";
   cin>>FileInName;
   FileInName+=".pgn";
   cout<<"epd filename (without .epd)-> ";
   cin>>FileOutName;
   cout<<endl;

   FileIn.open(FileInName.c_str());

   if(!FileIn) { cout<<"\n pgn file not found"; return; }

   readpgn();

}

void cTuner::start(int what)
{
    if(what==1) makeepd();
    else if(what==0) tune();
    else cout<<"\n no definition of 'what'";
}

/*
runs through the epd database positions that have been scored by engines, giving an end stdev vs score in epd
*/
double cTuner::runpositions()
{

  uint loop;
  string fen;
  int count = 0;
  int t_score;
  int sq_t_score;
  double variance = 0;
  int wherearewe = 0;
  eval_init();
 // cout<<"\n running loop ";
  for(loop = 0 ; loop < resultlines.size(); ++ loop)
  {
    //fen = resultlines[loop].fen;
    count++;
    setepdposition(resultlines[loop].fen.c_str());
    setdepth(ply);
    setmodetpm(false);
    setmodemtg(false);
    setdepthlimit(true);
	//reset_tables();
	compute();
    t_score = getlastscore(ply);
    //t_score = eval();
    //  cout<<"\n "<<t_score;
    sq_t_score = (t_score-resultlines[loop].score) * (t_score-resultlines[loop].score);
    variance += sq_t_score;
  }
//  cout<<"\n end loop "<<(clock()-start)<<" ms ";
 // cout<<" var "<<variance;

  if(variance < 0) variance *= -1;
  variance /= samples;
  return (double)sqrt(variance);
}

//tune eval using stdev mathod vs other engine scores
void cTuner::tune()
{
  resultlines.clear();

  tree->opt->usehash = false;
  tree->opt->donull = false;
  tree->opt->pvs = false;
  tree->opt->futility1 = false;
  tree->opt->futility2 = false;
  tree->opt->iid = false;
  tree->opt->qprune = false;
  tree->opt->special = true;

  resultstore temp;
  string tstr;
  string line;
  string fen;
  int t_score;
  int sq_t_score;
  int iteration;

  FileIn.open(FileInName.c_str());
  if(!FileIn) { cout<<"\n no file "<<FileInName<<" found "; return; }

  //read in fens and scores, store the score squared
  size_t position;
  int posin = 0;
  samples = 0;
  while (!FileIn.eof() )
  {
      getline(FileIn,line);
      if(line.length() < 20) continue;
      position = line.find(";score ");
      temp.fen = line.substr(0,position);
      tstr = line.substr(position+7,line.size());
      t_score = atoi(tstr.c_str());
      sq_t_score = t_score;
      //if(t_score < 0) sq_t_score *= -1;
      temp.score = sq_t_score;
      resultlines.push_back(temp);
      //cout<<" fen "<<temp.fen<<" score "<<temp.score<<endl;
      posin++;
      samples++;
      if(samples%1000==0 && samples>0) cout<<"\n read in "<<samples<<" positions ";
     // if(posin > 998) break;
  }
  FileIn.close();

  FileOut.open(FileOutName.c_str(), ios::trunc);
  if(!FileOut) { cout<<"\n no file "<<FileOutName<<" opened "; return; }

  FileOut<<"\n Genetic Tuning \n";
  FileOut<<"ply set to "<<ply<<endl<<endl;
  tree->param->tuning = true;
  if(islog()) { setlog(false); logclose();}

  cout<<"\n Genetic Tuning \n";
  cout<<"ply set to "<<ply<<endl<<endl;

  /*
  now loop through the parameters
  */
  double orig_res,plus_one_res,minus_one_res,best_stdev;
  int start;
  int loop;
  int changed=1;
  int origval;
  int newval;
  double startdev,enddev;

  iteration = 0;
  origval = paramlist[0].value;
  newval = origval;
  orig_res = runpositions();
  best_stdev = orig_res;

  sEvalParam *entry = &paramlist[0];

  while(changed!=0)
  {
   changed = 0;
   cout<<"\n new loop started ";
   start = clock();
   entry = &paramlist[0];
   startdev = best_stdev;
   while(entry->name != "end")
   {
      if( !entry->test) { entry++; continue; }
      cout<<"\nParam "<<entry->name;
      //cout<<" max "<<entry->max<<" min "<<entry->min<<" name "<<entry->name;
      origval = entry->value;
     // cout<<"\n val "<<origval<<" stdev "<<best_stdev;
      cout<<" val "<<origval;
      newval = origval+1;
      if(newval > entry->max)
      {
          newval--;
          plus_one_res = best_stdev;
      }
      else
      {
       set_param_value(newval, entry->name);
       plus_one_res = runpositions();
      }
      //cout<<" val "<<newval<<" stdev "<<plus_one_res;
      if(plus_one_res < best_stdev)
      {
          best_stdev = plus_one_res;
      }
      else
      {
          newval = origval-1;
          if(newval < entry->min)
          {
              newval++;
              minus_one_res = best_stdev;
          }
          else
          {
           set_param_value(newval, entry->name);
           minus_one_res = runpositions();
          }
          //cout<<" val "<<newval<<" stdev "<<minus_one_res;
          if(minus_one_res < best_stdev)
          {
              best_stdev = minus_one_res;
          }
          else
          {
              newval = origval;
          }
      }

      if(newval!=origval)
      {
       cout<<" Set new best "<<newval;
       set_param_value(newval, entry->name);
       changed++;
      }
      else
      {
        set_param_value(origval, entry->name);
        cout<<" no change ";
      }
      entry++;
   }
   enddev = best_stdev;
   iteration++;
   cout<<"\n**************************************";
   cout<<"\n*         end of iteration           *"<<iteration;
   cout<<"\n**************************************";
   cout<<" "<<changed<<" changes made ";
   cout<<"\niteration time "<<(clock()-start)<<"ms";
   cout<<"\n stedev reduction "<<startdev-enddev;
   cout<<"\n*                                    *";
   cout<<"\n**************************************";

   //printevalparam();
   //system("PAUSE");


   FileOut<<"\n**************************************";
   FileOut<<"\n*         end of iteration "<<iteration<<"       *";
   FileOut<<"\n**************************************";
   FileOut<<" "<<changed<<" changes made ";
   FileOut<<"\niteration time "<<(clock()-start)<<"ms";
   FileOut<<"\n stedev reduction "<<startdev-enddev;

   FileOut<<"\n Eval Paramters: "<<endl;
   entry = &paramlist[0];
   //{ true,   "BmobminO",     -50,  50,   -10 },
   while(entry->name != "end")
   {
    FileOut<<"{ ";
    if(entry->test) FileOut<<" true, ";
    else FileOut<<" false, ";
    FileOut<<"\""<<entry->name<<"\",\t"<<entry->min<<",\t"<<entry->max<<",\t"<<entry->value<<" },";
    FileOut<<endl;
    entry++;
   }

      FileOut<<"\n*                                    *";
    FileOut<<"\n**************************************\n";
    FileOut.flush();
   }
   //printevalparam();
   FileOut<<"\n Tuning Finshed ";
   FileOut.close();
}