

#include "MYJNIHelper.h"
#include "platform/android/jni/JniHelper.h"
#include <android/log.h>
#include "cocos2d.h"

#define  LOG_TAG    "cocos2d-x debug info"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define  CLASS_NAME_CJNIHELPER "com/bluefever/simplefloppyrobin/CJNIHelper"
#define  CLASS_NAME_SIMPLEFLOPPYROBIN "com/bluefever/simplefloppyrobin/SimpleFloppyRobin"

typedef struct JniMethodInfo_
{
    JNIEnv *    env;
    jclass      classID;
    jmethodID   methodID;
} JniMethodInfo;



extern "C" {

	// get env and cache it
    static JNIEnv* getJNIEnv(void)
    {

        JavaVM* jvm = cocos2d::JniHelper::getJavaVM();
        if (NULL == jvm) {
            // -- LOGD("Failed to get JNIEnv. JniHelper::getJavaVM() is NULL");
            return NULL;
        }

        JNIEnv *env = NULL;
        // get jni environment
        jint ret = jvm->GetEnv((void**)&env, JNI_VERSION_1_4);

        switch (ret) {
            case JNI_OK :
                // Success!
                return env;

            case JNI_EDETACHED :
                // Thread not attached

                // TODO : If calling AttachCurrentThread() on a native thread
                // must call DetachCurrentThread() in future.
                // see: http://developer.android.com/guide/practices/design/jni.html

                if (jvm->AttachCurrentThread(&env, NULL) < 0)
                {
                    // -- LOGD("Failed to get the environment using AttachCurrentThread()");
                    return NULL;
                } else {
                    // Success : Attached and obtained JNIEnv!
                    return env;
                }

            case JNI_EVERSION :
                // Cannot recover from this error
                // -- LOGD("JNI interface version 1.4 not supported");
                return NULL;
            default :
                // -- LOGD("Failed to get the environment using GetEnv()");
                return NULL;
        }
    }

    // get class and make it a global reference, release it at endJni().
    static jclass getClassID(JNIEnv *pEnv, const char *class_name)
    {
        jclass ret = pEnv->FindClass(class_name);
        if (! ret)
        {
            LOGD("Failed to find class of %s", class_name);
        }

        return ret;
    }

    static bool getStaticMethodInfo(JniMethodInfo &methodinfo, const char *methodName, const char *paramCode, const char *class_name)
    {
        jmethodID methodID = 0;
        JNIEnv *pEnv = 0;
        bool bRet = false;

        do
        {
            pEnv = getJNIEnv();
            if (! pEnv)
            {
                break;
            }

            jclass classID = getClassID(pEnv, class_name);

            methodID = pEnv->GetStaticMethodID(classID, methodName, paramCode);
            if (! methodID)
            {
                LOGD("Failed to find static method id of %s", methodName);
                break;
            }

            methodinfo.classID = classID;
            methodinfo.env = pEnv;
            methodinfo.methodID = methodID;

            bRet = true;
        } while (0);

        return bRet;
    }

	void CallMyJavaSideJNI(int num) {
		LOGD("C++ Call CallMyJavaSideJNI()");
		JniMethodInfo methodInfo;

		if(!getStaticMethodInfo(methodInfo, "CallMyJavaSideJNI", "(I)V", CLASS_NAME_CJNIHELPER)) {
			LOGD("C++ Failed Call CallMyJavaSideJNI()");
			return;
		}
		LOGD("C++ Found Call CallMyJavaSideJNI()");
		methodInfo.env->CallStaticVoidMethod(methodInfo.classID, methodInfo.methodID, num );
		methodInfo.env->DeleteLocalRef(methodInfo.classID);
	}

	void CallMyJavaToastJNI(int num, bool myBool) {
		LOGD("C++ Call CallMyJavaToastJNI()");
		JniMethodInfo methodInfo;

		if(!getStaticMethodInfo(methodInfo, "CallMyJavaToastJNI", "(IZ)V", CLASS_NAME_SIMPLEFLOPPYROBIN)) {
			LOGD("C++ Failed Call CallMyJavaToastJNI()");
			return;
		}
		LOGD("C++ Found Call CallMyJavaToastJNI()");
		methodInfo.env->CallStaticVoidMethod(methodInfo.classID, methodInfo.methodID, num );
		methodInfo.env->DeleteLocalRef(methodInfo.classID);
	}

	void SetMusicVolJNI(int vol) {
		LOGD("C++ Call SetMusicVolJNI()");
		JniMethodInfo methodInfo;

		if(!getStaticMethodInfo(methodInfo, "SetMusicVolJNI", "(I)V", CLASS_NAME_CJNIHELPER)) {
			LOGD("C++ Failed Call SetMusicVolJNI()");
			return;
		}
		LOGD("C++ Found Call SetMusicVolJNI()");
		methodInfo.env->CallStaticVoidMethod(methodInfo.classID, methodInfo.methodID, vol );
		methodInfo.env->DeleteLocalRef(methodInfo.classID);
	}

	int GetMusicVolJNI() {
		LOGD("C++ Call GetMusicVolJNI()");
		JniMethodInfo methodInfo;
		jint ret = 0;
		if(!getStaticMethodInfo(methodInfo, "GetMusicVolJNI", "()I", CLASS_NAME_CJNIHELPER)) {
			LOGD("C++ Failed Call GetMusicVolJNI()");
			return 5;
		}
		LOGD("C++ Found Call GetMusicVolJNI()");
		ret = methodInfo.env->CallStaticIntMethod(methodInfo.classID, methodInfo.methodID );
		methodInfo.env->DeleteLocalRef(methodInfo.classID);
		return (int)ret;
	}

	void SetEffectsVolJNI(int vol) {
		LOGD("C++ Call SetMusicVolJNI()");
		JniMethodInfo methodInfo;

		if(!getStaticMethodInfo(methodInfo, "SetMusicVolJNI", "(I)V", CLASS_NAME_CJNIHELPER)) {
			LOGD("C++ Failed Call SetMusicVolJNI()");
			return;
		}
		LOGD("C++ Found Call SetMusicVolJNI()");
		methodInfo.env->CallStaticVoidMethod(methodInfo.classID, methodInfo.methodID, vol );
		methodInfo.env->DeleteLocalRef(methodInfo.classID);
	}

	int GetEffectsVolJNI() {
		LOGD("C++ Call GetEffectsVolJNI()");
		JniMethodInfo methodInfo;
		jint ret = 0;
		if(!getStaticMethodInfo(methodInfo, "GetEffectsVolJNI", "()I", CLASS_NAME_CJNIHELPER)) {
			LOGD("C++ Failed Call GetEffectsVolJNI()");
			return 5;
		}
		LOGD("C++ Found Call GetEffectsVolJNI()");
		ret = methodInfo.env->CallStaticIntMethod(methodInfo.classID, methodInfo.methodID );
		methodInfo.env->DeleteLocalRef(methodInfo.classID);
		return (int)ret;
	}

	void Java_com_bluefever_simplefloppyrobin_CJNIHelper_CallCPPLayer(JNIEnv *env, jobject obj) {
		LOGD("C++ CallCPPLayer() Was called from Java");
	}

}























