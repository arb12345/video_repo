#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include "fen.h"
#include "utils.h"
#include "log.h"
#include "defs.h"
#include "engine.h"

using namespace std;

const bool debug = false;

//1nbqkbrr/1pppppp1/5n2/p7/P7/5N2/1PPPPPP1/1NBQKBRR w Kk - 0 1

const string startfen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
//r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1 ;D1 48 ;D2 2039 ;D3 97862 ;D4 4085603 ;D5 193690690 ;D6 8031647685
//const string startfen = "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1";

//find outermost rook, not including A and H files
uint outerrook(uint start, int dir, uint side)
{
    uint pce;

    if(side==cW) pce = pwR;
    else pce=pbR;
    uint lastsq = NOSQ;

    for(uint i = start+dir; onbrd(i); i+= dir)
    {
        if( (i==A1 || i==H1) && lastsq!=NOSQ) break;
        if(BRDPCE(i)==pce) lastsq = i;
    }
    return lastsq;
}


//for AH
void setWCAbit(char letter)
{
    char spare = tolower(letter);
    uint f = chartofile(spare);
    uint wkonsq = brd->frccasq[FRCWK];
    uint sqr = fr2sq(f,RANK1);

     if(sqr < wkonsq)
     {
     //  cout<<"\n set castle bit wQca";
       castlebits[sqr]=11;
       brd->frccasq[FRCWQR] = sqr;
       SETCASTLE(WCAQS);
     }
     else
     {
   //    cout<<"\n set castle bit wKca";
       brd->frccasq[FRCWKR] = sqr;
       castlebits[sqr]=7;
       SETCASTLE(WCAKS);
     }
}


//for ah
void setBCAbit(char letter)
{
    char spare = tolower(letter);
    uint f = chartofile(spare);
    uint bkonsq = brd->frccasq[FRCBK];
    uint sqr = fr2sq(f,RANK8);

     if(sqr < bkonsq)
     {
     //  cout<<"\n set castle bit bQca";
       castlebits[sqr]=14;
       brd->frccasq[FRCBQR] = sqr;
       SETCASTLE(BCAQS);
     }
     else
     {
    //   cout<<"\n set castle bit bKca";
       brd->frccasq[FRCBKR] = sqr;
       castlebits[sqr]=13;
       SETCASTLE(BCAKS);
     }
}

void setKbit()
{
    uint s;
    uint wkonsq = brd->frccasq[FRCWK];
    s = outerrook(wkonsq, E, cW);
    if(s==NOSQ) cout<<"\n ERROR NO ROOK FOUND ON WKSCA \n";
    castlebits[s]=7;
    brd->frccasq[FRCWKR] = s;
    SETCASTLE(WCAKS);
   // cout<<"\n set castle bit wKca";
}


void setQbit()
{
    uint s;
    uint wkonsq = brd->frccasq[FRCWK];
    s = outerrook(wkonsq, W, cW);
    if(s==NOSQ) cout<<"\n ERROR NO ROOK FOUND ON WQSCA \n";
    castlebits[s]=11;
    brd->frccasq[FRCWQR] = s;
    SETCASTLE(WCAQS);
   // cout<<"\n set castle bit wQca";
}


void setkbit()
{
   uint s;
    uint bkonsq = brd->frccasq[FRCBK];
    s = outerrook(bkonsq, E, cB);
    if(s==NOSQ) cout<<"\n ERROR NO ROOK FOUND ON BKSCA \n";
    castlebits[s]=13;
    brd->frccasq[FRCBKR] = s;
    SETCASTLE(BCAKS);
    //cout<<"\n set castle bit bKca";
}


void setqbit()
{
    uint s;
    uint bkonsq = brd->frccasq[FRCBK];
    s = outerrook(bkonsq, W, cB);
    if(s==NOSQ) cout<<"\n ERROR NO ROOK FOUND ON BQSCA \n";
    castlebits[s]=14;
    brd->frccasq[FRCBQR] = s;
    SETCASTLE(BCAQS);
    //cout<<"\n set castle bit bQca";
}

void setFRCcastlebits(const vector<string> epdsections)
{

    uint i;
    for(i = 0; i < epdsections[2].length(); ++i)
    {
        if(epdsections[2].at(i) == '-') continue;
        else if(epdsections[2].at(i) == 'K')  { setKbit(); continue; }
        else if(epdsections[2].at(i) == 'Q')  { setQbit(); continue; }
        else if(epdsections[2].at(i) == 'k')  { setkbit(); continue; }
        else if(epdsections[2].at(i) == 'q')  { setqbit(); continue; }
        else if(epdsections[2].at(i) >= 'A' && epdsections[2].at(i) <= 'H') { setWCAbit(epdsections[2].at(i)); continue; }
        else if(epdsections[2].at(i) >= 'a' && epdsections[2].at(i) <= 'h') { setBCAbit(epdsections[2].at(i)); continue; }
    }
}

void setepdposition(const string epdline)
{
    //cout<<"\n new pos ";
    /***
    EPD will have:
    7x "/" indicating end of rank
    Start at A8
    Board section will be followed by
        -active piece
        -castling perm
        -ep square
        -halfmove clock
        -fullmovenumber

    Total of 6 sections
    ***/

    //init - including the castlebits array

    uint i;

     for(i=0; i < BRDSQ; ++i)
     {
         if(onbrd(i)) castlebits[i] = 15;
         else castlebits[i] = 0;
         if(i<6) brd->frccasq[i] = NOSQ; // FRC Castling index
     }

    clearboard();
    clearpcelists();
    clearhistory();

    vector<string> epdsections;
    epdsections.clear();

    char delim = ' ';
    stringsplitter(epdline,  delim, epdsections);



	//cout<<"\n epdsections.size() "<<epdsections.size();

    if(epdsections.size() < 4)
    {
        cout<<"\n ERROR FEN - Too few parameters supplied. ";
        cout<<"\n String supplied: ";
		cout<<epdline;
        cout<<"\n sections read in: ";
        for(i = 0; i < epdsections.size(); ++i)
        {
         cout<<"\n"<<i<<" < "<<epdsections[i]<<" >";
		}
       return;
    }


    /**
    now split the board detail into ranks
    **/
    vector<string> boarddetail;
    delim = '/';
    stringsplitter(epdsections[0],  delim, boarddetail);

    if(boarddetail.size() != 8)
    {
        cout<<"\n ERROR FEN - Too few/many ranks supplied. ";
        cout<<"\n sections read in: ";
       for(i = 0; i< boarddetail.size(); ++i)
       {
		  cout<<"\n"<<i<<" < "<<boarddetail[i]<<" >";
       }
       return;
    }

    uint f,r,j;
    uint s;
    string rankline;
    for(i = 0; i < boarddetail.size(); ++i)
    {
          f = 0;
          r = 7-i;

          for(j = 0; j < boarddetail[i].length(); ++j)
          {
              if(boarddetail[i].at(j) >= '1' && boarddetail[i].at(j) <= '8')
              {
                  f += boarddetail[i].at(j)-'0';
                  continue;
              }
              else
              {
                  ASS(f<=FILEH&&f>=FILEA);
                  ASS(r<=RANK8&&r>=RANK1);
                  s = fr2sq(f,r);
                  ASS(onbrd(s));

                  switch (boarddetail[i].at(j))
                  {
                      case 'P': SETPCE(pwP,s);break;
                      case 'B': SETPCE(pwB,s);break;
                      case 'N': SETPCE(pwN,s);break;
                      case 'R': SETPCE(pwR,s);break;
                      case 'Q': SETPCE(pwQ,s);break;
                      case 'K': SETPCE(pwK,s); castlebits[s]=3; brd->frccasq[FRCWK]=s; break;
                      case 'p': SETPCE(pbP,s);break;
                      case 'b': SETPCE(pbB,s);break;
                      case 'n': SETPCE(pbN,s);break;
                      case 'r': SETPCE(pbR,s);break;
                      case 'q': SETPCE(pbQ,s);break;
                      case 'k': SETPCE(pbK,s);castlebits[s]=12; brd->frccasq[FRCBK]=s; break;
                      default: cout<<"\n piece char error <"<<boarddetail[i].at(j)<<">"; return;
                  };
                  f++;
              }
          }
    }

    if(epdsections[1].at(0) == 'w') SETSIDE(cW);
   else if(epdsections[1].at(0) == 'b') SETSIDE(cB);
   else
   {
	   cout<<"\n SIDE error - input < "<<epdsections[1]<<" >";
	   return;
   }

   //castling
   setFRCcastlebits(epdsections);

   //if(epdsections[3] != "-")
   SETENPAS(NOSQ);
   if(epdsections[3].length() == 2)
   {
       SETENPAS(str2sq(epdsections[3]));
   }

  if(epdsections.size() > 4)
  {
   i = strtoint(epdsections[4], 0);
   if(i<0||i>100) i = 0;
   SETFIFTY(i);
  }

   setpiecelists(brd->board);

   SETKEY(genhashkey());
   SETPKEY(genpawnkey());

   if(debug)
   {
    if(islog())
    logboard();
    printboard();
    printmaterial();
   }
/*
   if(engopt.variant==2)
   {
    cout<<"\n castle bits : \n";
    for(i=0; i < BRDSQ; ++i)
     {
         if(i%16==0 && i>0) cout<<endl;
         if(onbrd(i)) cout<<setw(3)<<castlebits[i];
     }
    cout<<"\n Wk "<<printsquare(brd->frccasq[0]);
    cout<<"\n Wkr "<<printsquare(brd->frccasq[1]);
    cout<<"\n Wqr "<<printsquare(brd->frccasq[2]);
    cout<<"\n Bk "<<printsquare(brd->frccasq[3]);
    cout<<"\n Bkr "<<printsquare(brd->frccasq[4]);
    cout<<"\n Bqr "<<printsquare(brd->frccasq[5]);
    printboard();
   }
*/
   ASS(position_check());
}


//mirror the position (set white as black, set black as white
void mirrorboard()
{
    uint sq64,sq128,inv128;

    uint holdside = SIDENOW;
    uint holdfifty = FIFTY;
    uint holdenpas = ENPAS;
    uint holdcastle = CAPERM;

    uint backup_board[BRDSQ];
    for(sq128=A1; sq128 < BRDSQ; ++sq128) backup_board[sq128] = BRDPCE(sq128);

    clearboard();
    clearpcelists();
    clearhistory();

    for (sq64=0; sq64<64; ++sq64)
    {
       sq128 = SQFROM64(sq64);
       inv128 = SQREV(sq128);
       ASS(onbrd(sq128));
       ASS(onbrd(inv128));
       if(backup_board[sq128] == pwK) SETPCE(pbK,inv128);
       else if(backup_board[sq128] == pwQ) SETPCE(pbQ,inv128);
       else if(backup_board[sq128] == pwR) SETPCE(pbR,inv128);
       else if(backup_board[sq128] == pwB) SETPCE(pbB,inv128);
       else if(backup_board[sq128] == pwN) SETPCE(pbN,inv128);
       else if(backup_board[sq128] == pwP) SETPCE(pbP,inv128);
       else if(backup_board[sq128] == pbK) SETPCE(pwK,inv128);
       else if(backup_board[sq128] == pbQ) SETPCE(pwQ,inv128);
       else if(backup_board[sq128] == pbR) SETPCE(pwR,inv128);
       else if(backup_board[sq128] == pbB) SETPCE(pwB,inv128);
       else if(backup_board[sq128] == pbN) SETPCE(pwN,inv128);
       else if(backup_board[sq128] == pbP) SETPCE(pwP,inv128);
       else SETPCE(pE,inv128);
    }

   SETSIDE(holdside^1);
   SETCASTLE(0);

   if (holdcastle & 8)  SETCASTLE(BCAKS);
   if (holdcastle & 4)  SETCASTLE(BCAQS);
   if (holdcastle & 2)  SETCASTLE(WCAKS);
   if (holdcastle & 1)  SETCASTLE(WCAQS);

   if(onbrd(holdenpas)) SETENPAS(SQREV(holdenpas));

   SETFIFTY(holdfifty);
   SETKEY(genhashkey());
   SETPKEY(genpawnkey());
   setpiecelists(brd->board);

   ASS(position_check());
}

string fenfromboard()
{
  uint file;
  int rank;
  string epdline;
  uint sq;
  uint empty;
  uint pce;
  uint index;
  uint castle;
  const char counter[9] = {'0','1','2','3','4','5','6','7','8'};
  vector<string> ranks;
  string temp,temp2;
  char start = '0';

 if(debug)
 {
  cout<<"\n converting following to epd:";
  printboard();
  cout<<endl;
 }
  for( rank = 7; rank>=0; rank--)
  {
      temp.clear();
      for( file = FILEA; file<=FILEH; ++file)
      {
       sq = fr2sq(file,rank);
       ASS(onbrd(sq));
       pce = BRDPCE(sq);
       ASS(pce>=pE&&pce<=pbK);
       temp+=piecechar(pce);
      }

      //now replace the dots with a number
      ASS(temp.length()==8);
      empty=0;
      temp2.clear();

      for(index = 0; index < temp.length(); ++index)
      {
          if(temp[index]!='.')
          {
            if(empty!=0)
            {
                temp2+=counter[empty];
                empty=0;
            }
            temp2+=temp[index];
            continue;
          }
          ASS(temp[index]=='.');
          empty++;
      }
      if(empty!=0)
      {
          temp2+=counter[empty];
      }
      if(rank>0) temp2+='/';
      ranks.push_back(temp2);
  }

  for(index = 0; index < ranks.size(); ++index)
  {
      epdline+=ranks[index];
  }


  //epd line now has the board, trivial to add the remaining parts....
  //side;
  epdline+=' ';
  epdline+=colourchar(SIDENOW);

  //castle permission
  epdline+=' ';
  castle = CAPERM;
  temp.clear();

  if(castle==0)
  {
      epdline+='-';
  }
  else if(engopt.variant!=2)
  {
   if (castle & WCAKS)  temp+='K';
   if (castle & WCAQS)  temp+='Q';
   if (castle & BCAKS)  temp+='k';
   if (castle & BCAQS)  temp+='q';
  }
  else
  {
   if (castle & WCAKS)  temp+=toupper(filetostr[FILE(brd->frccasq[FRCWKR])]);
   if (castle & WCAQS)  temp+=toupper(filetostr[FILE(brd->frccasq[FRCWQR])]);
   if (castle & BCAKS)  temp+=filetostr[FILE(brd->frccasq[FRCBKR])];
   if (castle & BCAQS)  temp+=filetostr[FILE(brd->frccasq[FRCBQR])];
  }

  epdline+=temp;

  //epsqaure
  epdline+=' ';
  if(onbrd(ENPAS)) epdline+=printsquare(ENPAS);
  else epdline+='-';

  //fifty
  epdline+=' ';
  epdline+=(start+FIFTY);

  //fullmove count
  epdline+=' ';
  epdline+=(start+(PLYNOW/2)+1);

  //cout<<epdline;

  return epdline;
}

