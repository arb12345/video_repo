#include <iostream>
#include "log.h"
#include "init.h"
#include "defs.h"

using namespace std;

sLog logger;

void loginit()
{
    if(!mainopt.logon)
	{
#ifdef DEBUG
		cout<<"\n No log file defined";
#endif
		logger.logging = false;
		return;
	}
	else logger.logging = true;

  char  *pfileName = new char[128];
  sprintf(pfileName, "%s.log",__DATE__);
#ifdef DEBUG
  cout<<"\nlog file "<< pfileName <<endl;
#endif
  if(pfileName != NULL)
  {
    logger.file.open(pfileName, ios::ate | ios::app | ios::out);
    char *buffer = new char[128];
    sprintf(buffer, "\n***New Log Started %s %s***\n", __DATE__, __TIME__);
    logger.file << buffer;
    delete buffer;
  }
  delete pfileName;
}

void logclose()
{
     if(logger.file)
     logger.file.close();
}



