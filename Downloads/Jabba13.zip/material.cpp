#include <iostream>
#include <iomanip>
#include <string>

#include "material.h"
#include "defs.h"
#include "piecedefs.h"
#include "bits.h"


using namespace std;

sMaterial mat[1];

void clearpcelists()
{
  uint piece = 0;

  for(piece = pE; piece <= pbK; ++piece)
  {
      mat->pcecount[piece] = 0;
      mat->pceBB[piece] = 0x0ULL;
  }

          mat->majors[cW] = 0;
          mat->minors[cW] = 0;
          mat->bigpieces[cW] = 0;
          mat->material[cW] = 0;
          mat->psqvalope[cW] = 0;
          mat->psqvalend[cW] = 0;
          mat->kingsq[cW] = NOSQ;
          mat->majors[cB] = 0;
          mat->minors[cB] = 0;
          mat->bigpieces[cB] = 0;
          mat->material[cB] = 0;
          mat->psqvalope[cB] = 0;
          mat->psqvalend[cB] = 0;
          mat->kingsq[cB] = NOSQ;
          mat->allBB=0x0ULL;
          mat->colBB[cW]=mat->colBB[cB]=0x0ULL;
}

//initialise uint list to the current board
void setpiecelists(const uint *board)
{
        clearpcelists();
        uint squares;
        uint sq;
        uint currentpiece = pE;
        uint currentcolour = cN;

        for(squares = 0; squares < 64; ++squares)
        {
            sq = SQFROM64(squares);
            ASS(onbrd(sq));

            currentpiece = board[sq];

            if(currentpiece==pE) continue;

            currentcolour = PCECOL(currentpiece);

            ASS(piecegood(currentpiece));
            ASS(colourgood(currentcolour));
            ASS(currentpiece!=pE);

            /** king sq set **/
            if(currentpiece==pwK) mat->kingsq[cW] = sq;
            else if(currentpiece==pbK) mat->kingsq[cB] = sq;

            /** pce counter set **/
            mat->pcecount[currentpiece]++;
            /** counter set **/
            if(ISMAJOR(currentpiece)) mat->majors[currentcolour]++;
            else if(ISMINOR(currentpiece)) mat->minors[currentcolour]++;
            if(ISBIG(currentpiece)) mat->bigpieces[currentcolour]++;

            /** material and psqt set **/
            if(currentpiece < pwK)
            mat->material[currentcolour] += PCEVAL(currentpiece);

            mat->psqvalope[PCECOL(currentpiece)] += PSQVAL(currentpiece,OPE,sq);
            mat->psqvalend[PCECOL(currentpiece)] += PSQVAL(currentpiece,END,sq);

            /** piece bitboard set **/
            setbit(sq, mat->pceBB[currentpiece]);
            setbit(sq, mat->colBB[PCECOL(currentpiece)]);
            setbit(sq, mat->allBB);
        }

  }

void printmaterial()
{
      cout<<endl<<" Material lists : ";

        printBB();
        cout<<endl;
        cout<<setw(8)<<" ";
        cout<<setw(3)<<colourchar(cW)<<setw(3)<<colourchar(cB);
        cout<<setw(8)<<"\n majors"<<setw(5)<<mat->majors[cW]<<setw(5)<<mat->majors[cB];
        cout<<setw(8)<<"\n minors"<<setw(5)<<mat->minors[cW]<<setw(5)<<mat->minors[cB];
        cout<<setw(8)<<"\n bigpce"<<setw(5)<<mat->bigpieces[cW]<<setw(5)<<mat->bigpieces[cB];
        cout<<setw(8)<<"\n pawns"<<setw(5)<<mat->pcecount[pwP]<<setw(5)<<mat->pcecount[pbP];
        cout<<setw(8)<<"\n material "<<setw(5)<<endl<<mat->material[cW]<<setw(5)<<mat->material[cB];
        cout<<setw(8)<<"\n psqope "<<setw(5)<<mat->psqvalope[cW]<<endl<<setw(5)<<mat->psqvalope[cB];
        cout<<setw(8)<<"\n psqend "<<setw(5)<<mat->psqvalend[cW]<<endl<<setw(5)<<mat->psqvalend[cB];
}

void printBB()
{
   uint currentpiece;
      for(currentpiece = pwP; currentpiece <= pbK; ++currentpiece)
        {
            cout<<endl<<" BB for piece "<<piecechar(currentpiece)<<" ";
            printbitboard(mat->pceBB[currentpiece]);
        }
        cout<<"\n all white BB ";
        printbitboard(mat->colBB[cW]);
        cout<<"\n all black BB ";
        printbitboard(mat->colBB[cB]);
        cout<<"\n allocc allBB ";
        printbitboard(mat->allBB);
}


void logBB()
{
   uint currentpiece;
      for(currentpiece = pwP; currentpiece <= pbK; ++currentpiece)
        {
            logger.file<<endl<<" BB for piece "<<piecechar(currentpiece)<<" ";
            logbitboard(mat->pceBB[currentpiece]);
        }
        logger.file<<"\n all white BB ";
        logbitboard(mat->colBB[cW]);
        logger.file<<"\n all black BB ";
        logbitboard(mat->colBB[cB]);
        logger.file<<"\n allocc allBB ";
        logbitboard(mat->allBB);
}



