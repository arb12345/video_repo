#include <iostream>

#include "movelist.h"
#include "move.h"
#include "squares.h"
#include "piecedefs.h"
#include "defs.h"
#include "material.h"
#include "attack.h"
#include "log.h"

using namespace std;
const uint HISMAX = 50000;

#define	HASH	2600000
#define	M_KILLER	2500000
#define	WIN_CAPT	2400000
#define	Q_PROM_CAPT	2300000
#define	Q_PROM	2200000
#define	GCAP_QQ	2100000
#define	GCAP_RR	2000000
#define	GCAP_NN	1900000
#define	GCAP_BB	1800000
#define	GCAP_PP	1700000
#define	SEECAP	1600000
#define	KILLER1	1500000
#define	KILLER1_PLY	1400000
#define	KILLER2	1300000
#define	KILLER2_PLY	1200000
#define	OO	1100000
#define	OOO	1000000
#define	MINORPROM	900000



using namespace std;

sMovelist mlist[1];

static const int equalcap[13] =
{0,GCAP_PP,GCAP_PP,GCAP_NN,GCAP_NN,
   GCAP_BB,GCAP_BB,GCAP_RR,GCAP_RR,
   GCAP_QQ,GCAP_QQ,0,0};

/*moveorderingpsqt*/
static const int orderpawn[64] = {
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
10	,	10	,	10	,	10	,	10	,	10	,	10	,	10	,
20	,	20	,	20	,	20	,	20	,	20	,	20	,	20	,
30	,	30	,	30	,	30	,	30	,	30	,	30	,	30	,
40	,	40	,	40	,	40	,	40	,	40	,	40	,	40	,
60	,	60	,	60	,	60	,	60	,	60	,	60	,	60	,
80	,	80	,	80	,	80	,	80	,	80	,	80	,	80	,
100	,	100	,	100	,	100	,	100	,	100	,	100	,	100
};

static const int orderknight[64] = {
0	,	10	,	10	,	10	,	10	,	10	,	10	,	0	,
10	,	15	,	30	,	30	,	30	,	30	,	15	,	10	,
10	,	20	,	50	,	50	,	50	,	50	,	20	,	10	,
10	,	20	,	50	,	80	,	80	,	50	,	20	,	10	,
10	,	20	,	50	,	80	,	80	,	50	,	20	,	10	,
10	,	20	,	50	,	50	,	50	,	50	,	20	,	10	,
10	,	15	,	30	,	30	,	30	,	30	,	15	,	10	,
0	,	10	,	10	,	10	,	10	,	10	,	10	,	0
};

static const int orderbishop[64] = {
80	,	60	,	50	,	30	,	30	,	50	,	60	,	80	,
60	,	80	,	60	,	50	,	50	,	60	,	80	,	60	,
50	,	60	,	80	,	60	,	60	,	80	,	60	,	50	,
30	,	50	,	60	,	80	,	80	,	60	,	50	,	30	,
30	,	50	,	60	,	80	,	80	,	60	,	50	,	30	,
50	,	60	,	80	,	60	,	60	,	80	,	60	,	50	,
60	,	80	,	60	,	50	,	50	,	60	,	80	,	60	,
80	,	60	,	50	,	30	,	30	,	50	,	60	,	80
};

static const int orderkingmid[64] = {
80	,	80	,	80	,	40	,	40	,	70	,	80	,	40	,
20	,	20	,	20	,	10	,	10	,	20	,	20	,	20	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0
};

static const int orderkingend[64] = {
0	,	10	,	20	,	40	,	40	,	20	,	10	,	0	,
10	,	20	,	30	,	50	,	50	,	30	,	20	,	10	,
20	,	30	,	40	,	60	,	60	,	40	,	30	,	20	,
40	,	50	,	60	,	80	,	80	,	60	,	50	,	40	,
40	,	50	,	60	,	80	,	80	,	60	,	50	,	40	,
20	,	30	,	40	,	60	,	60	,	40	,	30	,	20	,
10	,	20	,	30	,	50	,	50	,	30	,	20	,	10	,
0	,	10	,	20	,	40	,	40	,	20	,	10	,	0
};

static const int orderrook[64] = {
10	,	10	,	10	,	20	,	20	,	10	,	10	,	10	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
20	,	20	,	20	,	20	,	20	,	20	,	20	,	20	,
80	,	80	,	80	,	80	,	80	,	80	,	80	,	80	,
40	,	40	,	40	,	40	,	40	,	40	,	40	,	40
};


static const int *midordertab[] = {
    0,
    orderpawn, orderpawn,
    orderknight, orderknight,
    orderbishop, orderbishop,
    orderrook, orderrook,
    orderrook, orderrook,
    orderkingmid, orderkingmid
};

static const int *endordertab[] = {
    0,
    orderpawn, orderpawn,
    orderknight, orderknight,
    orderbishop, orderbishop,
    orderrook, orderrook,
    orderrook, orderrook,
    orderkingend, orderkingend
};

void mlist_init_opt()
{
    mlist->opt.histab = true;
    mlist->opt.mvvlva = true;
    mlist->opt.killer = true;
    mlist->opt.hashmove = true;
    mlist->opt.matekiller = true;
}

void resethistab()
{
    uint pce,sq;
    for(pce = pE; pce <= pbK; ++pce)
    {
        for(sq = 0; sq < BRDSQ; ++sq)
        mlist->histab.value[pce][sq] = 1;
    }
    mlist->histab.max = 1;
}

void resetmliststats()
{
    mlist->stats.killer1=mlist->stats.killer2=mlist->stats.matekiller=0;
    mlist->stats.histab=mlist->stats.capture=mlist->stats.badcapture=0;
    mlist->stats.hashmove=0;
    mlist->stats.qprom=mlist->stats.minorprom=0;
    mlist->stats.epcapture=mlist->stats.castle=0;
}

void resetkillers()
{
    for(uint i = 0; i < maxply; ++i)
    {
        mlist->killers.k1[i]=mlist->killers.k2[i]=mlist->killers.mk[i]=NULLMOVE;
    }
}

void sortmoves(const uint &ply)
{
    uint j,i;    // set flag to 1 to begin initial pass
    uint tempmove;
    int tempscore;             // holding variable
    for(i = 0; i < mlist->movecount[ply]; ++i)
    {
      for (j = 0; j < mlist->movecount[ply]-1; ++j)
      {
        if (mlist->movescores[ply][j+1]  > mlist->movescores[ply][j] )      // ascending order simply changes to <
        {
          tempscore = mlist->movescores[ply][j] ;             // swap score
          mlist->movescores[ply][j] = mlist->movescores[ply][j+1];
          mlist->movescores[ply][j+1] = tempscore;
          tempmove = mlist->movelist[ply][j] ;             // swap score
          mlist->movelist[ply][j] = mlist->movelist[ply][j+1];
          mlist->movelist[ply][j+1] = tempmove;
        }
      }
    }
}


void scoremove(uint &move, const uint &depth, const uint &pce)
{
    uint to = TO(move);
    ASS(onbrd(to));
    ASS(piecegood(pce));
    ASS(depth>=0&&depth<maxply);

    //histab.value[pce][to] += depth*depth;
    INCRHISTAB(pce,to,depth);
    if(HISTABVAL(pce,to)  > mlist->histab.max)
    mlist->histab.max = HISTABVAL(pce,to);

}


void failowmove(uint &move, const uint &depth, const uint &pce)
{
    uint to = TO(move);
    ASS(onbrd(to));
    ASS(piecegood(pce));
    ASS(depth>=0&&depth<maxply);

    if(HISTABVAL(pce,to)>depth*depth)
    {
    HISTABVAL(pce,to) -= depth*depth;
    if(HISTABVAL(pce,to)  < 1)
    HISTABVAL(pce,to) = 1;
    }

}


void score_killer(uint &move, const int score, uint &ply)
{

  ASS(ply>=0 && ply<maxply);
  ASS(onbrd(FROM(move))&&onbrd(TO(move)));
  ASS(score>=-matescore&&score<=matescore);
  if(score > matescore-200)
  {
   mlist->killers.mk[ply] = move;
   return;
  }

  if( !(FlagCAPEP&move) )
  {
     if(move != mlist->killers.k1[ply])
     {
       mlist->killers.k2[ply] = mlist->killers.k1[ply];
       mlist->killers.k1[ply] = move;
     }
     else
     {
      mlist->killers.k2[ply] = move;
     }
  }
}


int ordercapture(uint &move)
{

  int from,to,val;
  from = FROM(move);
  to = TO(move);
  uint side;
  uint pcefrom = BRDPCE(from);
  uint pceto = BRDPCE(to);

  ASS(piecegood(pcefrom));
  ASS(piecegood(pceto)||pceto==pE);
  ASS(onbrd(from));
  ASS(onbrd(to));

  if(PROM(move))//promotion
  {
      if(PROM(move)==pbQ||PROM(move)==pwQ)//queen
      {
          mlist->stats.capture++;
          return Q_PROM_CAPT;
      }
      else
      {
          mlist->stats.badcapture++;
          return MINORPROM;
      }
  }
  else//not a prom
  {
	val = PCEVAL(pceto) - PCEVAL(pcefrom);
	if(val>0)
	{
	 ASS( (WIN_CAPT+val) < M_KILLER && (WIN_CAPT+val) > Q_PROM_CAPT );
	 mlist->stats.capture++;
	 return WIN_CAPT+val;
	}
    else if(val == 0)
    {
     ASS(  equalcap[pcefrom] < Q_PROM && equalcap[pcefrom] > SEECAP );
     mlist->stats.capture++;
     return equalcap[pcefrom];
    }
    else
    {
        side = SIDENOW;
        ASS(side==cW||side==cB);
        if(isattack(side^1, to))
        {
           mlist->stats.badcapture++;
           return 1;
        }
        else
        {
           mlist->stats.capture++;
           return SEECAP;
        }
    }
  }
}

void ordermove(uint &move, uint &cap, const uint &flag, const uint &prom, uint &ply, uint pce,int *score)
{
       *score = -200;
     if(move==mlist->pvmove)
     {
        *score = HASH;
         mlist->stats.hashmove++;
     }
     else if(move==mlist->killers.mk[ply])
     {
         *score = M_KILLER;
         mlist->stats.matekiller++;
     }
     else if( cap )
     {
       ASS(cap>=pwP&&cap<pwK);
       *score = ordercapture(move);
     }
     else if(move & FlagEP)
     {
         *score = GCAP_PP;
         mlist->stats.epcapture++;
     }
     else if(prom!=pE)
     {
         ASS(prom>=pwN&&prom<=pbQ);
         if(prom==pwQ||prom==pbQ)
         {
             *score=Q_PROM;
             mlist->stats.qprom++;
         }
         else
         {
             *score=MINORPROM;
             mlist->stats.minorprom++;
         }
     }
     else if(move==mlist->killers.k1[ply])
     {
         *score = KILLER1;
         mlist->stats.killer1++;
     }
     else if(move==mlist->killers.k2[ply])
     {
         *score = KILLER2;
         mlist->stats.killer2++;
     }
     else if (move & FlagCA)
     {
         ASS(FILE(TO(move))==FILEC || FILE(TO(move))==FILEG);
         mlist->stats.castle++;
         if(FILE(TO(move))==FILEC)
         {
             *score = OOO;
         }
         else
         {
             *score = OO;
         }
     }
     else
     {
    	    ASS(piecegood(pce));
	    ASS(SQTO64(TO(move))>=0&&SQTO64(TO(move))<=63);
	    ASS(SQTO64(FROM(move))>=0&&SQTO64(FROM(move))<=63);
           if(TOTMAT > (int)ENDMAT)
           {
               mlist->tab = midordertab[pce];
           }
           else
           {
               mlist->tab = endordertab[pce];
           }

           *score=mlist->tab[SQTO64(TO(move))]-mlist->tab[SQTO64(FROM(move))];
           mlist->stats.histab++;
           ASS(*score < int(HISMAX) );
	 }
	 ASS(*score<=HASH && *score>=-100 && *score!=-200);
}

void printmovelist(uint &thisply)
{
     uint count = MOVECOUNT(thisply);
     ASS(thisply<maxply);
     ASS(count<maxmoves);
     uint i;
     printboard();
     cout<<endl<<"|--------------------|"<<endl;
     cout<<"list of "<<count<<" moves"<<endl;
     for(i = 0; i < count; ++i)
     {
           printmovelong(MOVE(thisply,i));
           cout<<" score "<<MOVESCORE(thisply,i)<<endl;
     }
     cout<<"|--------------------|"<<endl;
}

void mlistsays_stats()
{
#ifdef DEBUG
    cout<<"\nOrdered move stats: ";
    cout<<"\n killer1: "<<mlist->stats.killer1;
    cout<<" killer2: "<<mlist->stats.killer2;
    cout<<" matekiller: "<<mlist->stats.matekiller;
    cout<<"\nhistab: "<<mlist->stats.histab;
    cout<<" capture: "<<mlist->stats.capture;
    cout<<" badcapture: "<<mlist->stats.badcapture;
    cout<<"\nhashmove: "<<mlist->stats.hashmove;
    cout<<" qprom: "<<mlist->stats.qprom;
    cout<<" minorprom: "<<mlist->stats.minorprom;
#endif
    if(islog())
    {
    logger.file<<"\nOrdered move stats: ";
    logger.file<<"\n killer1: "<<mlist->stats.killer1;
    logger.file<<" killer2: "<<mlist->stats.killer2;
    logger.file<<" matekiller: "<<mlist->stats.matekiller;
    logger.file<<"\nhistab: "<<mlist->stats.histab;
    logger.file<<" capture: "<<mlist->stats.capture;
    logger.file<<" badcapture: "<<mlist->stats.badcapture;
    logger.file<<"\nhashmove: "<<mlist->stats.hashmove;
    logger.file<<" qprom: "<<mlist->stats.qprom;
    logger.file<<" minorprom: "<<mlist->stats.minorprom;
    }
}
