#ifndef SEARCHER_H
#define SEARCHER_H

#include "defs.h"
#include "board.h"
#include "history.h"
#include "material.h"
#include "movelist.h"
#include "clock.h"
#include "hashtab.h"
//#include "eval.h"
//#include "pawntab.h"
//#include "book.h"


//search modes
const uint smPERFTSINGLE = 1;
const uint smPERFTFILE = 2;
const uint smDEPTHSET = 4;
const uint smPONDER = 8;
const uint smPONDERHIT = 64;
const uint smINFINITE = 16;
const uint smNONE = 32;
const uint STOPPED = 1;
const uint RUNNING = 2;


struct sData {
       u64 nodes;
       u64 qnodes;
	   uint bestmove;
	   uint pondermove;
	   uint seldepth;
	   uint pvlen[maxply];
	   uint pv[maxply][maxply];
	   bool incheck[maxply];
	   char commandin[0xffff];
	   uint currentdepth;
	   bool extended;
	   int lastscore[maxply];
       uint iterationstart;

};

struct sParameters {
       uint iterdepth;
       uint nullred;
       bool ponderhit; //set to true by protocol criver if we're entering the search with a ponderhit
       bool special;
	   bool epd;
	   bool tuning;
};

struct sStatus {
       uint mode;
       uint stopped;
       bool interrupted;
};

struct sStats {
    int nulltry;
    int nullcuts;
    int hashcuts;
    int fh;
    int fhf;
    int checkext;
    int pawnseventh;
    int intopawnend;
    int pvssearch;
    int pvsresearch;
	int qcuts;
	int fut1;
	int fut2;
};

struct sSearchOpt {
    bool usehash;
    bool donull;
    bool pvs;
    bool special; //used for interrupt in epd or benchmark searches
    int nullredfact;
    string inifilename;
    bool aspiration;
    int aspwindow;
	bool icsmode;
	bool futility1;
	bool futility2;
	bool iid;
	bool qprune;
	int f1marg;
	int f2marg;
};

struct sSearcher {

        sData data[1];
        sParameters param[1];
        sStatus status[1];
        sStats stats[1];
        sSearchOpt opt[1];

        bool uci;
        bool xb;
};

extern sSearcher tree[1];

void iter_deep();
int  presearch(const uint depth);
int  alphabeta(int alpha, int beta, int depth, bool nullperm, bool check);
int  rootsearch(int alpha, int beta, int depth);
int  quies(int alpha, int beta);
bool prune_capture(uint &move);
void updateiteration(const int score, const uint d);
void printpv();
void picknext(const int from);
void pvupdate(const uint &move);
void loopcleanup(const int score);
bool checkdraw();
void extender(const int &pvnode, uint &ext, uint &move);
int checkinput();
void check_early_stop();
void preparerootlist();

extern void search_init_opt();


#define GETALLNODES ( (tree->data->nodes)+(tree->data->qnodes))
#define GETQNODES (tree->data->qnodes)
#define GETNODES (tree->data->nodes)
#define GETTSARTDEPTH (tree->param->iterdepth)
#define INCRNODES (tree->data->nodes++)
#define INCRQNODES (tree->data->qnodes++)
#define SETBEST(b) (tree->data->bestmove = (b))
#define PONDERHIT(p) (tree->param->ponderhit = (p) )

inline void setiterdepth(const uint depth) { tree->param->iterdepth = depth; }
inline void setmode(const uint mode) { tree->status->mode = mode; }
inline void setnullred(const uint nr) { tree->param->nullred = nr; }
inline void setininame(string name);

       //main "run" function - called to start the engine searching, perfting etc.

bool checkmoveislegal(uint move);

inline char *hascommand() { return tree->data->commandin; }
inline uint getpondermove() { return tree->data->pondermove; }
inline uint getbestmove() { return tree->data->bestmove; }
inline uint getlastscore(int ply) { return tree->data->lastscore[ply]; }
inline uint getmode() {return tree->status->mode;}
inline bool interrupted() { return tree->status->interrupted; }
inline void resetinterrupted() { tree->status->interrupted = false; }

extern void compute();
extern void readini(string file);
extern void showinivals();
extern int checkinput();
extern int checkinputtuning();

#endif
