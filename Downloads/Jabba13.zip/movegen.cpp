#include <iostream>
#include <iomanip>
#include <string>

#include "movegen.h"
#include "attack.h"
#include "defs.h"
#include "engine.h"
#include "magic.h"

void frcawks(uint &ply)
{
    uint kingsq = brd->frccasq[FRCWK];
    uint rooksq = brd->frccasq[FRCWKR];
    int kdir = (kingsq < G1) ? E : W;
    int rdir = (rooksq < F1) ? E : W;
    uint i;
    uint tsq = G1;

    // cout<<"\n assessing WCAKS, kdir "<<kdir<<" rdir "<<rdir;

    //first, see if the king can reach
    // cout<<"\nloop 1 ";
    if(kingsq!=G1)
    {
      if(BRDPCE(G1)!=pE && rooksq!=G1) return;
      for(i = kingsq+kdir; i != G1; i+=kdir)
      {
        // cout<<" "<<printsquare(i);

        if(BRDPCE(i) != pE && i != rooksq) return;
      }
    }

    //now the rook needs to have empty squares between it's square and F1
    // cout<<"\nloop 2 ";
    if(rooksq!=F1)
    {
     if(BRDPCE(F1)!=pE && kingsq!=F1) return;
     for(i = rooksq+rdir; i != F1; i+=rdir)
     {
       //  cout<<" "<<printsquare(i);
        if(BRDPCE(i) != pE && i != kingsq) return;
     }
    }

    //now see if the king will move across an attacked square
    // cout<<"\nloop 3 ";
     for(i = kingsq; i != G1; i+=kdir)
     {
        // cout<<" "<<printsquare(i);
        if(isattack(cB, i)) return;
     }

    //we can legally castle
    addmove(kingsq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply,pwK);
}


void frcawqs(uint &ply)
{
    uint kingsq = brd->frccasq[FRCWK];
    uint rooksq = brd->frccasq[FRCWQR];
    int kdir = (kingsq < C1) ? E : W;
    int rdir = (rooksq < D1) ? E : W;
    uint i;
    uint tsq = C1;

	//cout<<"\n assessing WCAQS, kdir "<<kdir<<" rdir "<<rdir;

    //first, see if the king can reach
	//cout<<"\nloop 1 ";
    if(kingsq!=C1)
    {
      if(BRDPCE(C1)!=pE && rooksq!=C1) return;
      for(i = kingsq+kdir; i != C1; i+=kdir)
      {
     //   cout<<" "<<printsquare(i);
        if(BRDPCE(i) != pE && i != rooksq) return;
      }
    }

    //now the rook needs to have empty squares between it's square and F1
	//cout<<"\nloop 2 ";
    if(rooksq!=D1)
    {
     if(BRDPCE(D1)!=pE && kingsq!=D1) return;
     for(i = rooksq+rdir; i != D1; i+=rdir)
     {
	//	 cout<<" "<<printsquare(i);
        if(BRDPCE(i) != pE && i != kingsq) return;
     }
    }

	//cout<<" ok, now attacks ";

    //now see if the king will move across an attacked square
     for(i = kingsq; i != C1; i+=kdir)
     {
        if(isattack(cB, i)) return;
     }

    //we can legally castle
    addmove(kingsq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply,pwK);
}

void frcabks(uint &ply)
{
    uint kingsq = brd->frccasq[FRCBK];
    uint rooksq = brd->frccasq[FRCBKR];
    int kdir = (kingsq < G8) ? E : W;
    int rdir = (rooksq < F8) ? E : W;
    uint i;
    uint tsq = G8;

    //first, see if the king can reach
    if(kingsq!=G8)
    {
      if(BRDPCE(G8)!=pE && rooksq!=G8) return;
      for(i = kingsq+kdir; i != G8; i+=kdir)
      {
        if(BRDPCE(i) != pE && i != rooksq) return;
      }
    }

    //now the rook needs to have empty squares between it's square and F1
    if(rooksq!=F8)
    {
     if(BRDPCE(F8)!=pE && kingsq!=F8) return;
     for(i = rooksq+rdir; i != F8; i+=rdir)
     {
        if(BRDPCE(i) != pE && i != kingsq) return;
     }
    }

    //now see if the king will move across an attacked square
     for(i = kingsq; i != G8; i+=kdir)
     {
        if(isattack(cW, i)) return;
     }

    //we can legally castle
    addmove(kingsq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply,pbK);
}


void frcabqs(uint &ply)
{
    uint kingsq = brd->frccasq[FRCBK];
    uint rooksq = brd->frccasq[FRCBQR];
    int kdir = (kingsq < C8) ? E : W;
    int rdir = (rooksq < D8) ? E : W;
    uint i;
    uint tsq = C8;

    //first, see if the king can reach
    if(kingsq!=C8)
    {
      if(BRDPCE(C8)!=pE && rooksq!=C8) return;
      for(i = kingsq+kdir; i != C8; i+=kdir)
      {
        if(BRDPCE(i) != pE && i != rooksq) return;
      }
    }

    //now the rook needs to have empty squares between it's square and F1
    if(rooksq!=D8)
    {
     if(BRDPCE(D8)!=pE && kingsq!=D8) return;
     for(i = rooksq+rdir; i != D8; i+=rdir)
     {
        if(BRDPCE(i) != pE && i != kingsq) return;
     }
    }

    //now see if the king will move across an attacked square
     for(i = kingsq; i != C8; i+=kdir)
     {
        if(isattack(cW, i)) return;
     }

    //we can legally castle
    addmove(kingsq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply,pbK);
}

inline void show_magic_bishopmoves(const uint &pce, const uint &side, uint &ply)
{
    u64 bboard = mat->pceBB[pce];
    u64 moves;
    int sq;
    uint sqto;
    uint sqfrom;
    while(bboard)
    {
        sq = POP(bboard);
        sqfrom = SQFROM64(sq);
     //   cout<<"\nbishop on "<<printsquare(SQFROM64(sq));
       // cout<<"\n sq "<<printsquare(SQFROM64(sq));

        moves = bishopmove(sq,mat->allBB);
       // cout<<"\n moves ";
       // printbitboard(moves);
        moves &= (~mat->colBB[side]);
       // cout<<"\n remove white pieces, move board = ";
       // printbitboard(moves);
        while(moves)
        {
            sqto = POP64(moves);
         //   cout<<"\n adding "<<printsquare(sqto);
            addmove(sqfrom, sqto, BRDPCE(sqto), FlagE, FlagE, ply, pce);
          //  cout<<"\n to = "<<printsquare(sqto);
        }
    }
}


inline void show_magic_rookmoves(const uint &pce, const uint &side, uint &ply)
{
    u64 bboard = mat->pceBB[pce];
    u64 moves;
    int sq;
    uint sqto;
    uint sqfrom;
    while(bboard)
    {
        sq = POP(bboard);
        sqfrom = SQFROM64(sq);
        //cout<<"\nrook on "<<printsquare(SQFROM64(sq));
        //  cout<<"\n sq "<<printsquare(SQFROM64(sq));
        //cout<<"\n allocc = ";
        //printbitboard(mat->allBB);
        moves = rookmove(sq,mat->allBB);
        //cout<<"\n moves ";
        //printbitboard(moves);
        moves &= (~mat->colBB[side]);
        //cout<<"\n remove opp pieces, move board = ";
        //printbitboard(moves);
        while(moves)
        {
            sqto = POP64(moves);
            //cout<<"\n adding "<<printsquare(sqto);
            addmove(sqfrom, sqto, BRDPCE(sqto), FlagE, FlagE, ply, pce);
          //  cout<<"\n to = "<<printsquare(sqto);
        }
    }
}


inline void show_magic_queenmoves(const uint &pce, const uint &side, uint &ply)
{
    u64 bboard = mat->pceBB[pce];
    u64 moves;
    int sq;
    uint sqto;
    uint sqfrom;
    while(bboard)
    {
        sq = POP(bboard);
        sqfrom = SQFROM64(sq);
      //  cout<<"\n sq "<<printsquare(SQFROM64(sq));

        moves = rookmove(sq,mat->allBB);
        moves |= bishopmove(sq,mat->allBB);
      //  cout<<"\n moves ";
      //  printbitboard(moves);
        moves &= (~mat->colBB[side]);
      //  cout<<"\n remove white pieces, move board = ";
      //  printbitboard(moves);
        while(moves)
        {
            sqto = POP64(moves);
            addmove(sqfrom, sqto, BRDPCE(sqto), FlagE, FlagE, ply, pce);
          //  cout<<"\n to = "<<printsquare(sqto);
        }
    }
}


inline void show_magic_bishopmoves_cap(const uint &pce, const uint &side, uint &ply)
{
    u64 bboard = mat->pceBB[pce];
    u64 moves;
    int sq;
    uint sqto;
    uint sqfrom;
    while(bboard)
    {
        sq = POP(bboard);
        sqfrom = SQFROM64(sq);
        moves = bishopmove(sq,mat->allBB);
        moves &= (mat->colBB[side^1]);
        while(moves)
        {
            sqto = POP64(moves);
            addmove(sqfrom, sqto, BRDPCE(sqto), FlagE, FlagE, ply, pce);
        }
    }
}


inline void show_magic_rookmoves_cap(const uint &pce, const uint &side, uint &ply)
{
    u64 bboard = mat->pceBB[pce];
    u64 moves;
    int sq;
    uint sqto;
    uint sqfrom;
    while(bboard)
    {
        sq = POP(bboard);
        sqfrom = SQFROM64(sq);
        moves = rookmove(sq,mat->allBB);
        moves &= (mat->colBB[side^1]);
        while(moves)
        {
            sqto = POP64(moves);
            addmove(sqfrom, sqto, BRDPCE(sqto), FlagE, FlagE, ply, pce);
        }
    }
}


inline void show_magic_queenmoves_cap(const uint &pce, const uint &side, uint &ply)
{
    u64 bboard = mat->pceBB[pce];
    u64 moves;
    int sq;
    uint sqto;
    uint sqfrom;
    while(bboard)
    {
        sq = POP(bboard);
        sqfrom = SQFROM64(sq);
        moves = rookmove(sq,mat->allBB);
        moves |= bishopmove(sq,mat->allBB);
        moves &= (mat->colBB[side^1]);
        while(moves)
        {
            sqto = POP64(moves);
            addmove(sqfrom, sqto, BRDPCE(sqto), FlagE, FlagE, ply, pce);
        }
    }
}


void gen_all_moves(uint hashmove)
{
     const uint side = SIDENOW;
     uint ply = PLYNOW;

     uint piece,sq,i,tsq;

     RESETCOUNT(ply);
     SETPVMOVE(hashmove);

     show_magic_bishopmoves(bishops[side], side, ply);
     show_magic_rookmoves(rooks[side], side, ply);
     show_magic_queenmoves(queens[side], side, ply);

     u64 moves;
     u64 pieceBB;

     //knights
     piece = knights[side];
     pieceBB = GET_BB(piece);
     while(pieceBB)
     {
      sq = POP64(pieceBB);
      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);
      moves = knight_moves[SQTO64(sq)];
      moves &= (~mat->colBB[side]);
      while(moves)
      {
         tsq = POP64(moves);
         addmove(sq, tsq, BRDPCE(tsq), FlagE, FlagE, ply, piece);
      }
    }

     //king non castle
     piece = kings[side];
     sq = KINGSQ(side);
     ASS(onbrd(sq));
     ASS(BRDPCE(sq)==piece);
     moves = king_moves[SQTO64(sq)];
     moves &= (~mat->colBB[side]);
     while(moves)
     {
         tsq = POP64(moves);
         addmove(sq, tsq, BRDPCE(tsq), FlagE, FlagE, ply, piece);
     }

     //now pawns - first captures, then forward moves
     piece = pawns[side];
     pieceBB = GET_BB(piece);
     ASS(piecegood(piece));
     ASS(!ISSLIDE(piece));
     ASS(piece==pwP||piece==pbP);
     while(pieceBB)
     {
       sq = POP64(pieceBB);
       ASS(onbrd(sq));
       ASS(BRDPCE(sq)==piece);
       for(i = 0; i < 2 ; ++i)
       {
        tsq = sq+dirPawn[piece][i];
        if(!(tsq & 0x88))
        {
           if(PCECOL(BRDPCE(tsq)) == (side^1))
           {
             addpawnmove(sq, tsq, BRDPCE(tsq), side,ply, piece);
           }
           else if(tsq == ENPAS)
           {
             addmove(sq, tsq, BRDPCE(tsq), FlagEP, FlagE,ply, piece);
           }
        }
       }//end of for loop for captures
       tsq = sq + dirPawn[piece][2];
       ASS(onbrd(tsq));//pawns don't get to rank 8, so +1sq north is always on the board
       if(BRDPCE(tsq)== pE)
       {
         addpawnmove(sq, tsq, BRDPCE(tsq), side, ply, piece);
         tsq += dirPawn[piece][2];
         if(RANK(sq)==startrank[side] && BRDPCE(tsq)== pE)
         {
            addmove(sq, tsq, BRDPCE(tsq), FlagE, FlagE, ply, piece);
         }
       }
     }

     //finally, the horror of king castling moves
     if(side==cW)
     {
     if (CAPERM & WCAKS)//King side
     {
      sq=E1;
      if(engopt.variant == 1)
      {
       if (BRDPCE(F1) == pE && BRDPCE(G1) == pE)
       {
         if (!(isattack(cB, F1)))
         {
           if (!(isattack(cB, E1)))
           {
             tsq=G1;
             addmove(sq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply, piece);
           }
         }
       }
      }//if variant==1
      else if(engopt.variant==2)//FRC
      {
          frcawks(ply);
      }
     }
     if (CAPERM & WCAQS)
     {
     sq=E1;
     if(engopt.variant == 1)
      {
       if (BRDPCE(C1) == pE && BRDPCE(D1) == pE && BRDPCE(B1) == pE)
       {
         if (!(isattack(cB, C1)))
         {
           if (!(isattack(cB, D1)))
           {
             if (!(isattack(cB, E1)))
             {
               tsq=C1;
                addmove(sq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply, piece);
             }
           }
         }
       }
      }
      else if(engopt.variant==2)//FRC
      {
          frcawqs(ply);
      }
     }
     }
     else
     {
     if (CAPERM & BCAKS)//King side
     {
      sq=E8;
     if(engopt.variant == 1)
      {
       if (BRDPCE(F8) == pE && BRDPCE(G8) == pE)
       {
         if (!(isattack(cW, F8)))
         {
           if (!(isattack(cW, E8)))
           {
               tsq=G8;
               addmove(sq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply, piece);
           }
         }
       }
      }
      else if(engopt.variant==2)//FRC
      {
          frcabks(ply);
      }
     }
     if (CAPERM & BCAQS)
     { sq=E8;
     if(engopt.variant == 1)
      {
       if (BRDPCE(C8) == pE && BRDPCE(D8) == pE && BRDPCE(B8) == pE)
       {
         if (!(isattack(cW, C8)))
         {
           if (!(isattack(cW, D8)))
           {
             if (!(isattack(cW, E8)))
             {
               tsq=C8;
               addmove(sq, tsq, BRDPCE(tsq), FlagCA, FlagE,ply, piece);
             }
           }
         }
       }
      }
      else if(engopt.variant==2)//FRC
      {
          frcabqs(ply);
      }
     }
     }
}


void gen_all_captures()
{
     const uint side = SIDENOW;
     uint ply = PLYNOW;

     uint piece,sq,i,tsq;

     RESETCOUNT(ply);

     show_magic_bishopmoves_cap(bishops[side], side, ply);
     show_magic_rookmoves_cap(rooks[side], side, ply);
     show_magic_queenmoves_cap(queens[side], side, ply);

     u64 moves;
     u64 pieceBB;

     //knights
     piece = knights[side];
     pieceBB = GET_BB(piece);
     while(pieceBB)
     {
      sq = POP64(pieceBB);
      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);
      moves = knight_moves[SQTO64(sq)];
      moves &= (mat->colBB[side^1]);
      while(moves)
      {
         tsq = POP64(moves);
         addmove(sq, tsq, BRDPCE(tsq), FlagE, FlagE, ply, piece);
      }
    }

     //king non castle
     piece = kings[side];
     sq = KINGSQ(side);
     ASS(onbrd(sq));
     ASS(BRDPCE(sq)==piece);
     moves = king_moves[SQTO64(sq)];
     moves &= (mat->colBB[side^1]);
     while(moves)
     {
         tsq = POP64(moves);
         addmove(sq, tsq, BRDPCE(tsq), FlagE, FlagE, ply, piece);
     }

     //now pawns - first captures, then forward moves
     piece = pawns[side];
     pieceBB = GET_BB(piece);
     ASS(piecegood(piece));
     ASS(!ISSLIDE(piece));
     ASS(piece==pwP||piece==pbP);
     while(pieceBB)
     {
       sq = POP64(pieceBB);
       ASS(onbrd(sq));
       ASS(BRDPCE(sq)==piece);
       for(i = 0; i < 2 ; ++i)
       {
        tsq = sq+dirPawn[piece][i];
        if(!(tsq & 0x88))
        {
           if(PCECOL(BRDPCE(tsq)) == (side^1))
           {
             addpawnmove(sq, tsq, BRDPCE(tsq), side,ply, piece);
           }
           else if(tsq == ENPAS)
           {
             addmove(sq, tsq, BRDPCE(tsq), FlagEP, FlagE,ply, piece);
           }
        }
       }//end of for loop for captures
     }
}
