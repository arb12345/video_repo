#include <iostream>
#include <string>

#include "searcher.h"
#include "movegen.h"
#include "make.h"
#include "log.h"
#include "attack.h"
#include "utils.h"
#include "hashtab.h"
#include "fen.h"
#include "eval.h"
#include "perft.h"
#include "movelist.h"
#include "book.h"
#include "defs.h"

using namespace std;

sSearcher tree[1];

void logpv();
void log_options()
{
	if(islog())
	{
		logger.file<<"\nSearching with options: ";
		if(tree->opt->usehash == true) logger.file<<"\n hashcuts on "; else logger.file<<"\n hashcuts off ";
		if(tree->opt->donull == true) logger.file<<"\n donull on "; else logger.file<<"\n donull off ";
		if(tree->opt->pvs == true)logger.file<<"\n pvs on "; else logger.file<<"\n pvs off ";
		if(tree->opt->aspiration == true)logger.file<<"\n aspiration on "; else logger.file<<"\n aspiration off ";
		if(tree->opt->icsmode == true)logger.file<<"\n icsmode on "; else logger.file<<"\n icsmode off ";
		if(tree->opt->futility1 == true)logger.file<<"\n futility1 on "; else logger.file<<"\n futility1 off ";
		if(tree->opt->futility2 == true)logger.file<<"\n futility2 on "; else logger.file<<"\n futility2 off ";
		if(tree->opt->iid == true)logger.file<<"\n iid on "; else logger.file<<"\n iid off ";
		logger.file<<"\n aspwindow = "<<tree->opt->aspwindow;
		logger.file<<"\n nullredfact = "<<tree->opt->nullredfact;
		logger.file<<"\n f1marg = "<<tree->opt->f1marg;
		logger.file<<"\n f2marg = "<<tree->opt->f2marg;
	}
}

void search_init_opt()
{
    tree->opt->usehash = true;
    tree->opt->donull = true;
    tree->opt->pvs = true;
    tree->opt->nullredfact = 3;
    tree->opt->inifilename = "jabba.ini";//default, can be changed as commandline argument
    tree->opt->aspiration = false;
    tree->opt->aspwindow = 50;
	tree->opt->icsmode = false;
	tree->opt->futility1 = true;
	tree->opt->futility2 = true;
	tree->opt->qprune = true;
	tree->opt->iid = true;
	tree->opt->f1marg = 50;
	tree->opt->f2marg = 500;

	tree->param->special = false;
	tree->param->epd = false;
	tree->param->tuning = false;
}



void printstats()
{
    double p;
//#ifdef DEBUG
    //if(logger.islog())logger.file<<"cSearcher::printstats()\n";
    cout<<"\nnulltry "<<tree->stats->nulltry;
    cout<<" nullcuts "<<tree->stats->nullcuts;
    p = percent(tree->stats->nulltry, tree->stats->nulltry+tree->stats->nullcuts);
    cout<<" "<<p<<"%";
	cout<<"\nfutility 1 "<<tree->stats->fut1;
	cout<<" futility 2 "<<tree->stats->fut2;
    cout<<"\nhashcuts "<<tree->stats->hashcuts;
    cout<<"\nfh "<<tree->stats->fh;
    cout<<" fhf "<<tree->stats->fhf<<" ordering ";
    p = percent(tree->stats->fhf, tree->stats->fhf+tree->stats->fh);
    cout<<" "<<p<<"%";
    cout<<"\nnodes "<<tree->data->nodes;
    cout<<" qnodes "<<tree->data->qnodes<<" ";
    p = percent(tree->data->qnodes, tree->data->nodes+tree->data->qnodes);
    cout<<" "<<p<<"%";
	cout<<"\nqcuts "<<tree->stats->qcuts;
    cout<<"\ncheckext = "<<tree->stats->checkext;
    cout<<" pawnseventh = "<<tree->stats->pawnseventh;
    cout<<" intopawnend = "<<tree->stats->intopawnend;
    cout<<"\npvssearch = "<<tree->stats->pvssearch;
    cout<<" pvsresearch = "<<tree->stats->pvsresearch;
    p = percent(tree->stats->pvsresearch, tree->stats->pvssearch);
    cout<<" "<<p<<"%"<<endl;
//#endif
    if(islog())
    {
    logger.file<<"\nnulltry "<<tree->stats->nulltry;
    logger.file<<" nullcuts "<<tree->stats->nullcuts;
    p = percent(tree->stats->nulltry, tree->stats->nulltry+tree->stats->nullcuts);
    logger.file<<" "<<p<<"%";
	logger.file<<"\nfutility 1 "<<tree->stats->fut1;
	logger.file<<" futility 2 "<<tree->stats->fut2;
    logger.file<<"\nhashcuts "<<tree->stats->hashcuts;
    logger.file<<"\nfh "<<tree->stats->fh;
    logger.file<<" fhf "<<tree->stats->fhf<<" ordering ";
    p = percent(tree->stats->fhf, tree->stats->fhf+tree->stats->fh);
    logger.file<<" "<<p<<"%";
    logger.file<<"\nnodes "<<tree->data->nodes;
    logger.file<<" qnodes "<<tree->data->qnodes<<" ";
    p = percent(tree->data->qnodes, tree->data->nodes+tree->data->qnodes);
    logger.file<<" "<<p<<"%";
    logger.file<<"\nqcuts "<<tree->stats->qcuts;
    logger.file<<"\ncheckext = "<<tree->stats->checkext;
    logger.file<<" pawnseventh = "<<tree->stats->pawnseventh;
    logger.file<<" intopawnend = "<<tree->stats->intopawnend;
    logger.file<<"\npvssearch = "<<tree->stats->pvssearch;
    logger.file<<" pvsresearch = "<<tree->stats->pvsresearch;
    p = percent(tree->stats->pvsresearch, tree->stats->pvssearch);
    logger.file<<" "<<p<<"%"<<endl;
    logger.file.flush();
    }
}


void resetstats()
{
   // if(logger.islog())logger.file<<"cSearcher::resetstats()\n";
    tree->stats->nulltry=0;
    tree->stats->nullcuts=0;
    tree->stats->fh=0;
    tree->stats->fhf=0;
    tree->stats->hashcuts=0;
    tree->stats->checkext=0;
    tree->stats->pawnseventh=0;
    tree->stats->intopawnend=0;
    tree->stats->pvssearch=0;
    tree->stats->pvsresearch=0;
	tree->stats->qcuts=0;
	tree->stats->fut1=0;
	tree->stats->fut2=0;
}

void resetdata()
{
     SETPLY(0);
     tree->data->qnodes=0;
     tree->data->nodes=0;
     tree->data->bestmove = NULLMOVE;
     tree->data->pondermove = NULLMOVE;
     tree->data->iterationstart = 0;
     tree->data->seldepth = 0;
     tree->status->stopped = RUNNING;
     tree->status->interrupted = false;
	 tree->data->extended = false;
     for(uint i = 0; i < maxply; ++i)
	 {
       tree->data->lastscore[i] = -matescore;
	   tree->data->pvlen[i] = 0;
	   tree->data->incheck[i] = false;
		 for(uint j = 0; j < maxply; ++j)
			 tree->data->pv[i][j] = NULLMOVE;
	 }
     resethistab();
     resetkillers();
     resetmliststats();
     resetstats();
     tree->param->iterdepth = GETDEPTH;

     ASS(tree->param->iterdepth>0&&tree->param->iterdepth<=maxply);

    // if(logger.islog())logger.file<<"cSearcher::resetdata()\n";
}

void resetparam()
{
   //  if(logger.islog())logger.file<<"cSearcher::resetparam()\n";
     tree->param->iterdepth=0;
}

/*
fill vector of rootmoves, sort them, remove illegal moves
*/
//2r3r1/3nkp1p/p1N1p2p/1q2P3/Qp6/5N1P/PP3bP1/2RR3K b - - 11 25
void preparerootlist()
{
    ASS(PLYNOW==0);
    ASS(position_check());

    //game.printboard();

    gen_all_moves(NULLMOVE);
	uint legals = 0;
	//cout<<"\n root move list ";
	//printmovelist(PLYNOW);
	for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
	{
		if (makemove(MOVE(PLYNOW,i)))
        {
         takemove();
         SETMOVESCORE(PLYNOW,i,-matescore);
         continue;
        }
        legals++;
        takemove();
	}

    sortmoves(PLYNOW);
    SETMOVECOUNT(PLYNOW,legals);

    //cout<<"\n root move list sorted, count is "<<legals;
	//printmovelist(PLYNOW);

    if(legals==1 && tree->param->iterdepth > 3) tree->param->iterdepth = 3;
}

bool scoreismate(int &score)
{
	int backupscore = score;
	int maxmate = maxply+1;

	if( score > (matescore-maxmate))
	{
		score = matescore - backupscore;
		return true;
	}
	else if(score < -matescore + maxmate)
	{
		score = -matescore - score;
		return true;
	}
	if(score!=backupscore) cout << "matescore error ";
	return false;
}

void updateiteration(const int score, const uint d)
{
     ASS(score>=-matescore&&score<=matescore);
     if(tree->param->tuning)  return;

     if(tree->data->currentdepth==1) return;
	 int backupscore = score;

   //  if(logger.islog())logger.file<<"cSearcher::updateiteration()\n";
     if(tree->xb)
     {
       cout<<d;
       cout<<" "<<score;
       cout<<"  "<<int(TIMEELAPSED)/10;
       cout<<" "<<GETALLNODES;
       cout<<" ";
     }
     else//info depth 2 score cp 214 time 1242 nodes 2124 nps 34928 pv e2e4 e7e5 g1f3
     {
         cout<<"info depth "<<d;
		 cout<<" seldepth "<<tree->data->seldepth;
		 if(scoreismate(backupscore))
		 cout<<" score mate "<<backupscore;
         else
         cout<<" score cp "<<score;
         cout<<"  time "<<int(TIMEELAPSED);
         cout<<" nodes "<<GETALLNODES;
         cout<<" pv ";
     }

	  printpv();

     if(islog()){logger.file<<"depth "<<d<<" score cp "<<score;
                    logger.file<<"  time "<<int(TIMEELAPSED)<<" nodes "<<GETALLNODES;
                    logger.file<<" pv ";logpv();}

	  if(tree->opt->icsmode && d > 6)
	  {
         backupscore = score;
         cout<<"tellothers depth "<<d;
         if(scoreismate(backupscore))
		 cout<<" score mate "<<backupscore;
         else
         cout<<" score cp "<<score;
         cout<<"  time "<<int(TIMEELAPSED);
         cout<<" nodes "<<GETALLNODES;
         cout<<" pv ";
		 printpv();
      }

	  tree->data->seldepth = 0;

}

void printpv()
{
    uint movenum;
    uint length = tree->data->pvlen[0];

    ASS(length<maxply);
    for(movenum = 0; movenum < length; ++movenum)
    {
           cout<<" "<<printmove(tree->data->pv[0][movenum]);
    }
    cout<<endl;
}


void logpv()
{
    if(!islog()) return;
	uint movenum;
    uint length = tree->data->pvlen[0];

    ASS(length<maxply);
    for(movenum = 0; movenum < length; ++movenum)
    {
            logger.file<<" "<<printmove(tree->data->pv[0][movenum]);
    }
    logger.file<<"\n";
}

void pvupdate(const uint &move)
{
	uint i;
	uint ply = PLYNOW;

    for (i = ply + 1;  i < tree->data->pvlen[ply+1]; i++)
        tree->data->pv[ply][i] = tree->data->pv[ply + 1][i];

    tree->data->pv[ply][ply] = move;
    tree->data->pvlen[ply] = tree->data->pvlen[ply+1];

}


uint movefromhash(uint &makemefirst)
{
    uint hashmove = NULLMOVE;
    int beta = 0, hashscore = 0;//dummy
    bool nullperm;//dummy
    uint depth = 1;//100% certain of a hit...
    uint hashflag = tFlagNOTSET;

   // cout<<"\n stage 11";

    makemove(makemefirst);
    hashflag = probe_hashentry(hashscore, depth, hashmove, beta, nullperm, BRDKEY, PLYNOW);
    takemove();

    return hashmove;
}


void loopcleanup(const int score)
{
     SETBEST(tree->data->pv[0][0]);
     tree->data->lastscore[tree->data->currentdepth] = score;
     resetkillers();
     if(tree->param->tuning) return;
    // cout<<"\n stage 5";
     if(tree->data->pvlen[0]>1)//load of hash hits, no pv past move one
     {
   //   cout<<"\n stage 6";
      tree->data->pondermove = tree->data->pv[0][1];
    //  cout<<"\n stage 7";
     }
     else if(tree->data->currentdepth > 1)
     {
    //  cout<<"\n stage 8";
      tree->data->pondermove = movefromhash(tree->data->bestmove);
    //  cout<<"\n stage 9";
     }
    // cout<<"\n stage 10";
}


void compute()
{
    if(islog() && !tree->param->tuning)
    {
        logger.file<<"cSearcher::compute()\n";
        logger.file<<fenfromboard()<<endl;
		logboard();
        logeval();
    }

    if((tree->status->mode & smPERFTFILE)!=0) perftsingle(5);
    else
	{
        startsearchtimer(SIDENOW, tree->status->mode, tree->param->ponderhit);
		if(!tree->param->tuning) log_options();
        resetdata();
        preparerootlist();//also limits depth in the case of one legal move
	    iter_deep();
	    if(!tree->param->tuning) ttablesays_stats();
	    if(!tree->param->tuning) mlistsays_stats();
	    if(!tree->param->tuning) printstats();
	}
}


bool checkmoveislegal(uint move)
{
    gen_all_moves(NULLMOVE);
	bool found = false;// no. moves we have played
	uint i;
	for(i = 0; i < MOVECOUNT(PLYNOW); ++i)
	{
		if( MOVE(PLYNOW,i) == move) found=true;
	}

	if(!found) return false;

	if (makemove(move))
	{
		 takemove();
		 return false;
    }

    takemove();

    return true;
}

//if more than half the allocated time has been used, and the score has jumped up or down more than
//50cp from the previous iteration, double the allocated time for this position
bool check_panic()
{
    if(timer->modetimepermove || timer->modemovestogo) return false;
	if(tree->data->extended = true) return false;
	if((tree->status->mode & (smPONDER|smINFINITE))!=0) return false;

    int scorenow = tree->data->lastscore[tree->data->currentdepth];
    int scorebefore = tree->data->lastscore[tree->data->currentdepth-1];

	if( (myclock()-timer->starttime)*2 > timer->stoptime)
	{
     if(tree->data->currentdepth > 5 || scorenow-scorebefore > 50)
     {
        if(islog()) logger.file<<"\npanic time";
        cout<<"\n awarding extra time for interesting position ";
		tree->data->extended=true;
        uint timeallocated = timer->alloctime;
        uint timetoadd = timeallocated;
        logger.file<<", adding "<<timetoadd<<endl;
        setstoptime(timer->starttime+timeallocated+timetoadd);
        return true;
     }
	}
     return false;
}

void check_early_stop()
{
    if(tree->opt->special) return;
	if((tree->status->mode & (smPONDER|smINFINITE))!=0) return;

    uint timenow = myclock();
    uint timeforlastply = timenow - tree->data->iterationstart;

    check_panic();
    //cout<<"\n last iteraiton time "<<timeforlastply<<endl;

    //assume next ply takes at least as long as the last
    if(timenow + timeforlastply > GETSTOPTIME)
    {
        //cout<<"\n Early stop, no time for next ply "<<endl;
        tree->status->stopped = STOPPED;
    }
/*
    //now an easy move stop. Here, if the first move on the root list
    //has a value of 80 more than the second move, it's classed as easy
    if(tree->data->currentdepth == 1)
    {
        int *sc = mlist.p2scores(PLYNOW);
	uint *list = mlist.p2list(PLYNOW);

        cout<<"\n move 0 "<<printmove(list[0])<<" score "<<sc[0];
        cout<<"\n move 1 "<<printmove(list[1])<<" score "<<sc[1]<<endl;

        if(sc[0] > sc[1]+80)
        {
         cout<<"\n Early stop, easy move "<<endl;
         tree->status->stopped = STOPPED;
        }
    }
*/
}


void iter_deep()
{
    int score;
    uint bookmv = NULLMOVE;

    if(islog() && !tree->param->tuning)logger.file<<"\niter_deep() mode "<<tree->status->mode<<"\n";

    if((tree->status->mode & (smPONDER|smINFINITE))==0 && !tree->param->tuning)
    {
     if(bookread.bookmove(bookmv, SIDENOW))
	 {
		 if(checkmoveislegal(bookmv))
         {
          tree->data->bestmove = bookmv;
          if(islog())logger.file<<" book move "<<printmove(bookmv)<<endl;
          return;
         }
         else
         {
            if(islog())logger.file<<" illegal book move "<<printmove(bookmv)<<endl;
         }
     }
    }
    /* iterative deepening loop */
    for(uint i = 1; i <= GETTSARTDEPTH ; ++i)
    {
       tree->data->currentdepth = i;
     //  cout<<"\n depth "<<i;
       tree->data->iterationstart = myclock();
       score = presearch(i);//main search function here
       if(i > 2 && tree->status->stopped == STOPPED) return;
     //  cout<<"\n stage 1";
       loopcleanup(score);
     //  cout<<"\n stage 2";
       updateiteration(score,i);
     //  cout<<"\n stage 3";
       sortmoves(PLYNOW);
      // cout<<"\n stage 4";
    //  if(!check_panic())
	 if( !tree->param->tuning) check_early_stop();
     }

}

int presearch(const uint depth)
{
    ASS(depth<maxply);

    int score;
    int alpha = -matescore;
    int beta = matescore;
/*
    if(tree->opt->aspiration && depth > 2)//at least one score from the search to base the window on
    {
      alpha = cpscore(tree->data->lastscore) - tree->opt->aspwindow;
      beta = cpscore(tree->data->lastscore) + tree->opt->aspwindow;
#ifdef DEBUG
      if(logger.islog())
      {
          logger.file<<"window "<<tree->opt->aspwindow<<" alpha "<<alpha;
          logger.file<<" beta "<<beta<<" lastscore "<<cpscore(tree->data->lastscore)<<endl;
      }
      cout<<"\nwindow "<<tree->opt->aspwindow<<" alpha "<<alpha;
      cout<<" beta "<<beta<<" lastscore "<<cpscore(tree->data->lastscore)<<endl;
#endif
      score = alphabeta(alpha, beta, depth, true, incheck(game,mat,game.getside()));
      if(depth > 2 && tree->status->stopped == STOPPED) return score;
      if(score <= alpha || score >= beta) //research
      {
#ifdef DEBUG
      if(logger.islog())
          logger.file<<"***********RESEARCH**********"<<endl;
      cout<<"**********RESEARCH*********"<<endl;
#endif
        alpha = -matescore;
        beta = matescore;
        score = alphabeta(alpha, beta, depth, true, incheck(game,mat,game.getside()));
      }
      return score;
    }
    else
    {
      alpha = -matescore;
      beta = matescore;
      score = alphabeta(alpha, beta, depth, true, incheck(game,mat,game.getside()));
      return score;
    }
    */
    score = rootsearch(alpha, beta, depth);
    return score;
}





//check if we have a rep, fifty, or interruption
bool checkdraw()
{
    if(findrepetition(BRDKEY) && PLYNOW>0) { return true;}
    if(FIFTY>100) {return true;}
    return false;
}

int  rootsearch(int alpha, int beta, int depth)
{

 ASS(position_check());
 tree->data->pvlen[PLYNOW] = PLYNOW;
 uint side = SIDENOW;
 int val = -matescore+1;
 if(alpha+1 != val) cout<<"\n Root alpha error";
 uint played = 0;
 uint bestmove = NULLMOVE;
 int bestscore = -matescore;
 uint ext;
 uint from;
 bool check;
 int old_alpha = alpha;

 //cout<<"\n Checking root status...";

 //mlist.printmovelist(ply);

 if(incheck(side)) { tree->stats->checkext++; depth++; }

 for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
 {
//	cout<<"\n root taking next "<<i;
	picknext(i);
    if (makemove(MOVE(PLYNOW,i)))
     {
       takemove();
       cout<<"\nILLEGAL ROOTMOVE!!!";
       continue;
     }

    // cout<<"\n root making "<<i;
    // cout<<" "<<printmove(MOVE(PLYNOW-1,i));
   //  cout<<" depth "<<depth;


     if(tree->uci && tree->data->currentdepth > 9 && ((tree->status->mode & (smPONDER|smINFINITE))==0)  && !tree->param->tuning)
     {
         cout<<"info currmove "<<printmove(MOVE(PLYNOW-1,i))<<" currmovenumber "<<i+1<<endl;
         cout<<"info depth "<<tree->data->currentdepth<<endl;
		 //cout<<"info hashfull "<<(percent(ttable->write,ttable->elements)*100);
     }

     check = incheck(SIDENOW);
     ext = 0;
     if(check) { tree->stats->checkext++; ext = 1; }
     if (tree->opt->pvs)
     {
        if( played == 0)
        {
         val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);
        }
        else
        {
         val = -alphabeta(-alpha-1, -alpha, depth-1+ext, true, check);
         tree->stats->pvssearch++;
         if (val > alpha)
         {
            tree->stats->pvsresearch++;
            val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);
         }
        }
     }
     else
     {
       val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);
     }
     //val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);

     takemove();

   //  cout<<"\n back in root() "<<PLYNOW;
  //   cout<<" last move n umber "<<i<<" "<<printmove(MOVE(PLYNOW,i));

     if(tree->status->stopped == STOPPED) { return 0;}

     played++;

     from = FROM(MOVE(PLYNOW,i));

     if(val>bestscore)
     {
          bestscore=val;
          if(tree->data->currentdepth == 1)
          pvupdate(MOVE(PLYNOW,i));
     }

     if(tree->data->currentdepth > 1)
     {

       if (val <= alpha)  SETMOVESCORE(PLYNOW,i,old_alpha);
       else if (val >= beta)   SETMOVESCORE(PLYNOW,i,beta);
       else SETMOVESCORE(PLYNOW,i,val);
     }
     else SETMOVESCORE(PLYNOW,i,val);

     if (val > alpha && tree->data->currentdepth > 1)
     {
        bestmove = MOVE(PLYNOW,i);
        if (val >= beta)
        {
            if(played==1) tree->stats->fhf++;
            else tree->stats->fh++;
            store_hashentry(val, tFlagLOWER, bestmove, depth, BRDKEY);
            alpha = beta;
            break;
        }
        alpha = val;
        pvupdate(MOVE(PLYNOW,i));
     }
   }
  // cout<<"\n root loop done ";

 //cout<<"\n returning alpha "<<alpha;
 if(alpha<old_alpha) cout<<"\n Root moves all too low";
 if(alpha!=beta)
 store_hashentry(alpha, tFlagEXACT, bestmove, depth, BRDKEY);
 //cout<<"\n stroe hash done ";
 if(tree->data->currentdepth > 1)
 return alpha;
 else
 return bestscore;
}

int  alphabeta(int alpha, int beta, int depth, bool nullperm, bool check)
{
    ASS(position_check());
    if(checkdraw()) return 0;

    if(( (GETALLNODES) & 2047) == 0)
    {
     if(tree->data->currentdepth > 2)
     {
      if(timeup() || checkinput())
      {
        tree->status->stopped = STOPPED;
        if(islog())logger.file<<"Search timeout\n";
        return 0;
      }
     }
    }

   // cout<<"\n alphabeta() "<<PLYNOW;

    if(PLYNOW>=maxply) return eval();

    tree->data->pvlen[PLYNOW] = PLYNOW;

    if(depth<=0)
    {
        ASS(check==false);
        return quies(alpha,beta);
    }

	INCRNODES;

	uint hashflag = tFlagNOTSET;
	uint hashmove = NULLMOVE;
	int hashscore = -matescore;

	if(PLYNOW)
    {
         hashflag = probe_hashentry(hashscore, depth, hashmove, beta, nullperm, BRDKEY, PLYNOW);
         if(hashflag!=tFlagNOTSET && tree->opt->usehash)
         {
           switch(hashflag)
           {
                   case tFlagEXACT:
                   tree->stats->hashcuts++;
                   return hashscore;
                   break;
                   case tFlagUPPER:
                   if (hashscore <= alpha)
                   {tree->stats->hashcuts++; return hashscore;}
                   break;
                   case tFlagLOWER:
                   if (hashscore >= beta)
                   {tree->stats->hashcuts++; return hashscore;}
                   break;
                   default:
                   break;
           }
         }
    }


        int pvnode = ((beta-alpha)>1);

	if(tree->opt->donull)
	{
	 if(depth >= 2 && nullperm && check == false && BIG(cW)+BIG(cB) > 0 && !pvnode)
	 {
       int nscore;
       tree->stats->nulltry++;
       makenullmove();
       nscore = -alphabeta( -beta, -beta+1, depth-1-tree->opt->nullredfact, false, false);
       takenullmove();
       ASS(position_check());
       if(nscore>=beta) { tree->stats->nullcuts++;return beta; }
	 }
	}

	if(hashmove==NULLMOVE && pvnode && depth > 2 && tree->opt->iid)
	{
		int iidscore = alphabeta(alpha, beta, depth-2, true, check);
        if (iidscore <= alpha) alphabeta(-matescore, beta, depth-2, true, check);
		hashmove = tree->data->pv[PLYNOW][PLYNOW];
	}

    gen_all_moves(hashmove);
    int val = -matescore;
    uint played = 0;
    uint bestmove = NULLMOVE;
	uint tempmove = NULLMOVE;
    uint ext;
    uint from;
	bool wascheck = check;
    int old_alpha = alpha;
	int evscore = lazyeval();

    if(check && PLYNOW==0) { tree->stats->checkext++; depth++; }

    for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
    {
	  picknext(i);
	  tempmove = MOVE(PLYNOW,i);

      if (makemove(tempmove))
       {

         takemove();
         continue;
       }

    //   cout<<"\n alphabeta "<<PLYNOW-1<<"making "<<printmove(MOVE(PLYNOW-1,i));


     check = incheck(SIDENOW);
     ext = 0;
     if(check) { tree->stats->checkext++; ext = 1; }
     else extender(pvnode, ext, tempmove);

	 //futility
	 if(tree->opt->futility1 && depth == 1 && !wascheck && ext==0 && !pvnode && played != 0)
	 {
		 if ( (evscore + materialgainmove(tempmove) + tree->opt->f1marg) <= alpha)
		 {
			 cfr = 7;
			 takemove();
			 cfr = 8;
			 tree->stats->fut1++;
			 continue;
		 }
	 }

	 if(tree->opt->futility2 && depth == 2 && !wascheck && ext==0 && !pvnode && played != 0)
	 {
		 if ( (cancutmove(tempmove) && (evscore + tree->opt->f2marg <= alpha) ) )
		 {
			 takemove();
			 tree->stats->fut2++;
			 continue;
		 }
	 }

	 if (tree->opt->pvs)
     {
        if( played == 0)
        {
         val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);
        }
        else
        {
		 val = -alphabeta(-alpha-1, -alpha, depth-1+ext, true, check);
         tree->stats->pvssearch++;
         if (val > alpha)
         {
            tree->stats->pvsresearch++;
            val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);
         }
        }
     }
     else
     {
       val = -alphabeta( -beta, -alpha, depth-1+ext, true, check);
     }
     takemove();
   //   cout<<"\n back in alphabeta() "<<PLYNOW;
     if(tree->status->stopped == STOPPED) { return 0;}

     played++;

     from = FROM(tempmove);

     if (val > alpha)
     {
        bestmove = tempmove;
        if (val >= beta)
        {
            if(played==1) tree->stats->fhf++;
            else tree->stats->fh++;

            store_hashentry(val, tFlagLOWER, bestmove, depth, BRDKEY);
            score_killer(bestmove, val, PLYNOW);
            scoremove(tempmove, depth, BRDPCE(from));
            return beta;
        }
            alpha = val;
            pvupdate(tempmove);
     }
   }

   if (played == 0)
	{
		if (check)
		{
		    return -matescore + PLYNOW;
		}
		else
		{
			return 0;
		}
	}

	if(alpha>old_alpha)
	store_hashentry(alpha, tFlagEXACT, bestmove, depth, BRDKEY);
    else
    store_hashentry(old_alpha, tFlagUPPER, NULLMOVE, depth, BRDKEY);

    return alpha;
}


int  quies(int alpha, int beta)
{


 #ifdef DEBUG
   ASS(position_check());
   #endif
 //  cout<<"\n here ";
	if(PLYNOW>=maxply) return eval();
    if(checkdraw()) return 0;

	if(PLYNOW > tree->data->seldepth) tree->data->seldepth = PLYNOW;

   //  cout<<"\n quies() "<<PLYNOW;

    int score = eval();
    INCRQNODES;
    if(score>=beta) return beta;
    if(score > alpha) alpha = score;

    gen_all_captures();

    int val = -matescore;
	uint move;

  //  cout<<"\n captures() "<<PLYNOW;
  //  cout<<" have "<<MOVECOUNT(PLYNOW)<<" moves ";

   // printmovelist(PLYNOW);

     for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
     {
	  picknext(i);
	  move = MOVE(PLYNOW,i);
      if (makemove(move))
      {

       takemove();
       continue;
      }

      // cout<<"\n quies "<<PLYNOW-1<<"making "<<printmove(MOVE(PLYNOW-1,i));

     if(tree->opt->qprune && prune_capture(move))
     {
	   tree->stats->qcuts++;
	   takemove();
	   //logger.file<<endl<<fenfromboard()<<endl;
	   //logboard();
	   //logger.file<<"\n pruned move "<<printmove(move)<<endl;
	   continue;
     }

     val = -quies( -beta, -alpha);
     takemove();


     if (val >= beta)
            return beta;
     if (val > alpha)
     {
            alpha = val;
      }
   }

    return alpha;
}


void picknext(const int from)
{
    uint i;
    int bs;
    int bi;
    uint g;
    uint ply = PLYNOW;

    bs = -matescore;
    bi = from;
    int s;

    for (i = from; i < MOVECOUNT(PLYNOW); ++i)
    {
        s = mlist->movescores[ply][i];
        if ( s > bs)
        {
            bs = mlist->movescores[ply][i];
            bi = i;
        }
    }

    g =  mlist->movelist[ply][from];
    mlist->movelist[ply][from] = mlist->movelist[ply][bi];
    mlist->movelist[ply][bi] = g;

    g =  mlist->movescores[ply][from];
    mlist->movescores[ply][from] = mlist->movescores[ply][bi];
    mlist->movescores[ply][bi] = g;
}

void extender(const int &pvnode, uint &ext, uint &move)
{
    uint to = TO(move);
    uint cap = CAP(move);
    uint lastside;
    uint pce;
    ASS(ext==0);
    ASS(onbrd(to));

    lastside = SIDENOW^1;
    pce = BRDPCE(to);
    ASS(piecegood(pce));
    ASS(lastside==cW || lastside==cB);
    ASS(PCECOL(pce)==lastside);

    if(pvnode)
    {
        if(pce==pwP && RANK(to)==RANK7)
        {
            ext=1;
            tree->stats->pawnseventh++;
        }
        else if(pce==pbP && RANK(to)==RANK2)
        {
            ext=1;
            tree->stats->pawnseventh++;
        }
    }

    if( (BIG(cW)+BIG(cB) == 0) && cap > pbP)
    {
        ASS(cap<pwK);
        ext=2;
        tree->stats->intopawnend++;
    }
    ASS(ext==0||ext==1||ext==2);
}

bool prune_capture(uint &move)
{
	uint to = TO(move);
	uint pcefrom = BRDPCE(to);
	uint pceto = CAP(move);

	//logger.file<<"\n looking to prune "<<printmove(move);
	//logger.file<<" pcefrom "<<piecechar(pcefrom);
	//logger.file<<" pceto "<<piecechar(pceto);

    //promotion - underpromotion cut
    if(PROM(move))
    {
      //logger.file<<" is a prom ";
      if(PROM(move) < pwQ)
      {
         // logger.file<<" under prom, pruning ";
          return true;
      }
      else
      {
         // logger.file<<" queen prom, not pruning ";
          return false;
      }
    }

    //ep capture always ok
	else if(move & FlagEP)
	{
	   // logger.file<<" enpas, not pruning ";
	    return false;
	}

	if(!pceto)
	{
	    cout<<"\n capture error ";
	    printboard();
	    cout<<"\n move "<<printmove(move);
	    printallhistory();
	    system("PAUSE");
	}

    // logger.file<<" val from = "<<VALUE(pcefrom)<<" val to = "<<VALUE(pceto);
    //if piece from has greater value than piece to, capture is good
    if(PCEVAL(pcefrom) <= PCEVAL(pceto))
    {
       // logger.file<<" val from <= to, all ok, no prune ";
        return false;
    }

	//other caps, see() less than 0 is bad cap
	else if (see(move) < 0)
	{
	   // logger.file<<" bad see() ";
	   // logger.file<<endl<<fenfromboard(game,mat)<<endl;
	   // game.logboard();
	   // logger.file<<"\n numerical move "<<move;
	    return true;
	}

    //logger.file<<" no prune++++++ ";
	//capture is not bad
	return false;
}

