#ifndef MAGIC_H
#define MAGIC_H

#include "bits.h"

extern u64 bishopmoves[64][4096];
extern u64 rookmoves[64][4096];
extern const u64 BMagic[64];
extern const u64 RMagic[64];
extern const int BBits[64];
extern const int RBits[64];
extern const u64 BishopFullMasks[64];
extern const u64 RookFullMasks[64];

extern void init_magic();


inline int transform(u64 b, u64 magic, int bits) {
#if defined(USE_32_BIT_MULTIPLICATIONS)
  return
    (unsigned)((int)b*(int)magic ^ (int)(b>>32)*(int)(magic>>32)) >> (32-bits);
#else
  return (int)((b * magic) >> (64 - bits));
#endif
}


inline u64 bishopmove(const int &sq, u64 &occ)
{
        int bits = BBits[sq];
      //  cout<<"\n in bishopmove()\nbits = "<<bits;
        u64 magic = BMagic[sq];
        u64 slimocc;
      //  cout<<"\n magic "<<hex<<magic<<dec;

      //  cout<<"\n occ =";
      //  printbitboard(occ);

      //  cout<<"\n full mask[sq] =";
      //  printbitboard(BishopFullMasks[sq]);

        slimocc = occ&BishopFullMasks[sq];

      //  cout<<"\n slimocc =";
      //  printbitboard(slimocc);

        int index = transform(slimocc,magic,bits);

      //  cout<<"\n move index = "<<index;
      //  printbitboard(bishopmoves[sq][index]);

        return bishopmoves[sq][index];
}

inline u64 rookmove(const int &sq, u64 &occ)
{
        int bits = RBits[sq];
       // cout<<"\n in rookmove()\nbits = "<<bits;
        u64 magic = RMagic[sq];
        u64 slimocc;
       // cout<<"\n magic "<<hex<<magic<<dec;

       // cout<<"\n occ =";
       // printbitboard(occ);

       // cout<<"\n full mask[sq] =";
       // printbitboard(RookFullMasks[sq]);

        slimocc = occ&RookFullMasks[sq];

       // cout<<"\n slimocc =";
       // printbitboard(slimocc);

        int index = transform(slimocc,magic,bits);

       // cout<<"\n move index = "<<index;
       // printbitboard(rookmoves[sq][index]);

        return rookmoves[sq][index];
}

#endif
