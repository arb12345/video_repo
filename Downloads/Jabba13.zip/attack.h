#ifndef ATTACK_H
#define ATTACK_H

#include "defs.h"
#include "board.h"
#include "piecedefs.h"
#include "material.h"
#include "movegen.h"
#include "magic.h"


extern void init_attack_tables();
extern void printattboard(const uint piece, const uint sq);
extern bool isattack(const uint &side, const uint &target);
extern void printsquaresatt(const uint side);
extern bool incheck( const uint &side);
extern int see(uint move);
extern bool ispinned(const uint &side, const uint &target);
extern void showattacks(const uint &side, const uint &target);


inline u64 getBishopAttBoard(const int &sq)
{
      return bishopmove(sq,mat->allBB);
}


inline u64 getRookAttBoard(const int &sq)
{
       return rookmove(sq,mat->allBB);
}

#endif


