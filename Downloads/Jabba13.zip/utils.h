#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include <string.h>

#include "defs.h"



using namespace std;



extern void stringsplitter(const string &string, char delim, vector<std::string> &split);
extern int strtoint(string str, int pos);
extern uint strtouint(string str, int pos);
extern bool findsubstr(string word, string input, int &pos);
extern bool findsubstrend(string word, string input, int &pos);
extern double percent(int tester, int all);
extern double strtodbl(string str, int pos);
extern uint myclock();

#endif
