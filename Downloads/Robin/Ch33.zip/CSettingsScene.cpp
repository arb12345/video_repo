//
//  CSettingsScene.cpp
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 11/03/14.
//
//


#include "CSettingsScene.h"
#include "Constants.h"
#include "CGameManager.h"

USING_NS_CC;

void CSettingsLayer::ccTouchesBegan(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	CCSetIterator i;
	CCTouch *touch;
	CCPoint tap;
	
	bool playTap = false;
	
	for (i = pTouches->begin(); i != pTouches->end(); i++) {
		touch = (CCTouch *)(*i);
		if(touch) {
			tap = touch->getLocation();
			CCLOG("Touched at %.2f,%.2f",tap.x,tap.y);
			if(_backButton->boundingBox().containsPoint(tap)) {
				CGameManager::Instance()->RunScene(kSceneGame);
				playTap = true;
			} else if(_effectPlusBox.containsPoint(tap)) {
				playTap = true;
				IncEffects(1);
			} else if(_effectMinusBox.containsPoint(tap)) {
				playTap = true;
				IncEffects(-1);
			} else if(_musicPlusBox.containsPoint(tap)) {
				playTap = true;
				IncMusic(1);
			} else if(_musicMinusBox.containsPoint(tap)) {
				playTap = true;
				IncMusic(-1);
			}
			if(playTap) {
				CGameManager::Instance()->PlayEffect(kEffectRobinTap);
			}
		}
	}
}

void CSettingsLayer::ccTouchesMoved(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	
}

void CSettingsLayer::ccTouchesEnded(cocos2d::CCSet *pTouches, cocos2d::CCEvent *event) {
	
}

void CSettingsLayer::IncEffects(const int inc) {
	int CurrentEffVol = CGameManager::Instance()->GetEffectsVol();
	
	if(inc == -1 && CurrentEffVol > 0) {
		CGameManager::Instance()->SetEffectsVol(CurrentEffVol - 1);
	} else if(inc == 1 && CurrentEffVol < 10) {
		CGameManager::Instance()->SetEffectsVol(CurrentEffVol + 1);
	}
	SetLabelValues();
}

void CSettingsLayer::IncMusic(const int inc) {
	int CurrentMusicVol = CGameManager::Instance()->GetMusicVol();
	
	if(inc == -1 && CurrentMusicVol > 0) {
		CGameManager::Instance()->SetMusicVol(CurrentMusicVol - 1);
		if(CurrentMusicVol == 1) {
			CGameManager::Instance()->StopBGMusic();
		}
	} else if(inc == 1 && CurrentMusicVol < 10) {
		CGameManager::Instance()->SetMusicVol(CurrentMusicVol + 1);
		if(CurrentMusicVol == 0) {
			CGameManager::Instance()->StartBGMusic();
		}
	}
	SetLabelValues();
}

CCScene* CSettingsLayer::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CSettingsLayer *layer = CSettingsLayer::create();
	
    // add layer as a child to scene
    scene->addChild(layer);
	
    // return the scene
    return scene;
}

void CSettingsLayer::AddLabelAtPosition(const CCPoint pos, CCLabelTTF *label, const int zIndex, const CCPoint anchor) {
	label->setAnchorPoint(anchor);
	label->setPosition(pos);
	label->setColor(ccRED);
	this->addChild(label, zIndex);
}


void CSettingsLayer::SetLabelValues() {
	char ValueString[16];
	sprintf(ValueString, "%d", CGameManager::Instance()->GetMusicVol());
	_musicValue->setString(ValueString);
	
	memset(ValueString, 0, sizeof(ValueString));
	sprintf(ValueString, "%d", CGameManager::Instance()->GetEffectsVol());
	_effectValue->setString(ValueString);
}

bool CSettingsLayer::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
		{
        return false;
		}
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
	char FileName[32];
	
	
	GETFILENAME(FileName, 32, "BG", ".png");
	CCSprite *bgSprite = CCSprite::create(FileName);
	SCALENODE_XY(bgSprite);
	bgSprite->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(bgSprite, kZindexBackground);
	
	const float GapToAdjust = 140 * GETSCALEX * GETSCALEFAC;
	const float LeftGap = 120 * GETSCALEX * GETSCALEFAC;
	const float ButtonToBottom = 40 * GETSCALEY * GETSCALEFAC;
	const float FontSize = SCALEFONT(40);
	
	CCLabelTTF *title = CCLabelTTF::create("SETTINGS", kFontName, FontSize);
	CCLabelTTF *eff = CCLabelTTF::create("EFFECTS VOL.", kFontName, FontSize);
	CCLabelTTF *_effectPlus = CCLabelTTF::create("+", kFontName, FontSize);
	CCLabelTTF *_effectMinus = CCLabelTTF::create("-", kFontName, FontSize);
	CCLabelTTF *mus = CCLabelTTF::create("MUSIC VOL.", kFontName, FontSize);
	CCLabelTTF *_musicPlus = CCLabelTTF::create("+", kFontName, FontSize);
	CCLabelTTF *_musicMinus = CCLabelTTF::create("-", kFontName, FontSize);
	
	_musicValue = CCLabelTTF::create("0", kFontName, FontSize);
	_backButton = CCLabelTTF::create("BACK", kFontName, FontSize);
	_effectValue = CCLabelTTF::create("0", kFontName, FontSize);
	
	AddLabelAtPosition(ccp(visibleSize.width / 2, visibleSize.height - ButtonToBottom), title, kZindexBackground, ccp(0.5,1));
	AddLabelAtPosition(ccp(LeftGap, ButtonToBottom), _backButton, kZindexBackground, ccp(0,0));
	AddLabelAtPosition(ccp(LeftGap, visibleSize.height / 2 + ButtonToBottom), eff, kZindexBackground, ccp(0,0.5));
	AddLabelAtPosition(ccp(visibleSize.width - LeftGap, visibleSize.height / 2 + ButtonToBottom), _effectPlus, kZindexBackground, ccp(1,0.5));
	AddLabelAtPosition(ccp(_effectPlus->boundingBox().origin.x - GapToAdjust, visibleSize.height / 2 + ButtonToBottom), _effectValue, kZindexBackground, ccp(0.5,0.5));
	AddLabelAtPosition(ccp(_effectValue->boundingBox().origin.x - GapToAdjust, visibleSize.height / 2 + ButtonToBottom), _effectMinus, kZindexBackground, ccp(0.5,0.5));
	
	float EffectBottomY = _effectValue->boundingBox().origin.y;
	
	AddLabelAtPosition(ccp(LeftGap, EffectBottomY - ButtonToBottom * 2), mus, kZindexBackground, ccp(0,1));
	AddLabelAtPosition(ccp(visibleSize.width - LeftGap, EffectBottomY - ButtonToBottom * 2), _musicPlus, kZindexBackground, ccp(0.5,1));
	AddLabelAtPosition(ccp(_effectPlus->boundingBox().origin.x - GapToAdjust, EffectBottomY - ButtonToBottom * 2), _musicValue, kZindexBackground, ccp(0.5,1));
	AddLabelAtPosition(ccp(_effectValue->boundingBox().origin.x - GapToAdjust, EffectBottomY - ButtonToBottom * 2), _musicMinus, kZindexBackground, ccp(0.5,1));
	
	CCSize adjusterSize = _effectPlus->boundingBox().size;
	float adjusterY = adjusterSize.height / 2;
	
	_effectPlusBox = CCRect(_effectPlus->boundingBox().origin.x - adjusterY,
							_effectPlus->boundingBox().origin.y - adjusterY,
							adjusterSize.height * 2, adjusterSize.height * 2);
	_effectMinusBox = CCRect(_effectMinus->boundingBox().origin.x - adjusterY,
							 _effectMinus->boundingBox().origin.y - adjusterY,
							 adjusterSize.height * 2, adjusterSize.height * 2);
	_musicMinusBox = CCRect(_musicMinus->boundingBox().origin.x - adjusterY,
							_musicMinus->boundingBox().origin.y - adjusterY,
							adjusterSize.height * 2, adjusterSize.height * 2);
	_musicPlusBox = CCRect(_musicPlus->boundingBox().origin.x - adjusterY,
						   _musicPlus->boundingBox().origin.y - adjusterY,
						   adjusterSize.height * 2, adjusterSize.height * 2);
	
	SetLabelValues();
	
	this->setTouchEnabled(true);
	
	return true;
}
