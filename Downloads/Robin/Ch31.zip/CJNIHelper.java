package com.bluefever.simplefloppyrobin;

import android.content.SharedPreferences;
import android.util.Log;

public class CJNIHelper {
	private final static String TAG = "cocos2d-x debug info JAVA";
	
	public final static String SETTING_SET_NAME = "OurSettings";
	private final static String KEYHIGHSCORE = "KEYHIGHSCORE";
	private final static String KEYMUSICVOL = "KEYMUSICVOL";
	private final static String KEYEFFECTSVOL = "KEYEFFECTSVOL";	
	private final static String KEYGAMETIME = "KEYGAMETIME";
	
	private final static int EFFECTS_VOL_DEFAULT = 5;
	private final static int MUSIC_VOL_DEFAULT = 5;
	private final static int ZERO_DEFAULT = 0;
	
	
	private static SharedPreferences prefs;
	private static SimpleFloppyRobin mainRef;
	
	public static void SetUp(SharedPreferences p, SimpleFloppyRobin m) {
		prefs = p;
		mainRef = m;
		SetKeyIfNotExits(KEYGAMETIME, ZERO_DEFAULT);
		SetKeyIfNotExits(KEYMUSICVOL, MUSIC_VOL_DEFAULT);
		SetKeyIfNotExits(KEYEFFECTSVOL, EFFECTS_VOL_DEFAULT);
		SetKeyIfNotExits(KEYHIGHSCORE, ZERO_DEFAULT);
	}
	
	private static void SetKeyIfNotExits(String keyName, int value) {
		SharedPreferences.Editor edit = prefs.edit();
		if(prefs.contains(keyName) == false) {
			Log.d(TAG, "Adding New Key:" + keyName + " val:" + value);
			edit.putInt(keyName, value);
			edit.commit();
		}
	}
	
	public static void CallMyJavaSideJNI(int num) {
		Log.d(TAG,"CallMyJavaSideJNI() Called In Java With " + num);
	}
	
	public static native void CallCPPLayer();
	
}
