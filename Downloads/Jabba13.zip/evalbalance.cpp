#include <iostream>

#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "board.h"
#include "evalparam.h"

//from material analyses using Stats, using regression for influence of majors and pawns

//BPair

//Bpair = -7.6*Maj-8*P+155 from material database
/*
const int bpair[17] = {84,93,97,96,92,84,74,63,51,40,38,36,34,32,30,28,26};

//Exchange

//rook vs knight start adv = vR-vN, we take away +(vN-vR) and add bonus
const int m = (vN-vR);
const int n = (vB-vR);
const int exchBR[7] = {200+m,200+m,175+m,150+m,120+m,100+m,80+m};
const int exchNR[7]  = {220+n,220+n,190+n,170+n,150+n,125+n,104+n};

//2NvsB
const int NNvsB = 2*PAWNBASE-vN; //table said total adv = 2P

//endings
const int BPppp = (2*PAWNBASE - vB + 118);
const int BPPpppp = (2*PAWNBASE - vB + 160);
const int NPppp = (2*PAWNBASE - vN + 51);
const int NPPpppp = (2*PAWNBASE - vN + 118);

//NvsB pawns on the board
const int NvsB[17]={-24,-24,-24,-21,-18,-15,-12,-9,-6,-3,0,3,6,9,12,12};

//won ending scored by rank (encourage pawn to promote)
const int wonending[2][8] = {
	{0,300,400,500,600,700,800,900},
    {900,800,700,600,500,400,300,0}
};
*/
void balance()
{
    if((scorer->wp+scorer->bp)==0)
    {
        if(is_draw())
        {
            scorer->drawflag = true;
            return;
        }
    }

	//return;

    uint bmaj = scorer->bq+scorer->br;
    uint wmaj = scorer->wq+scorer->wr;
    uint wmin = scorer->wb+scorer->wn;
    uint bmin = scorer->bn+scorer->bb;


    //force a max majors
    if(bmaj>3) bmaj=3;
    if(wmaj>3) wmaj=3;

    int tempb=0,tempw=0;

    ASS(bmaj+wmaj>=0 && bmaj+wmaj<=6);
    ASS(scorer->wp<9 && scorer->bp<9);
    ASS(scorer->wp>=0 && scorer->bp>=0);

    //Bishop Pair**************************
    ASS(scorer->wp+scorer->bp<=16 && scorer->wp+scorer->bp>=0);

    if(scorer->wb >= 2 && scorer->bb < 2)
    {
        tempw += BPair;
    }
    else if(scorer->bb >= 2 && scorer->wb < 2)
    {
        tempb += BPair;
    }
    /*

    //Exchange*****************************
    ASS(bmaj+wmaj<=6 && bmaj+wmaj>=0);
    //RforN
    if(scorer->wr-scorer->br==1 && bmin-wmin==1 && scorer->bn>scorer->wn) tempw += exchNR[bmaj+wmaj];
    if(scorer->br-scorer->wr==1 && wmin-bmin==1 && scorer->wn>scorer->bn) tempb += exchNR[bmaj+wmaj];
    //RforB
    if(scorer->wr-scorer->br==1 && bmin-wmin==1 && scorer->bb>scorer->wb) tempw += exchBR[bmaj+wmaj];
    if(scorer->br-scorer->wr==1 && wmin-bmin==1 && scorer->wb>scorer->bb) tempb += exchBR[bmaj+wmaj];
*/
/*
    //NN vs B************************************
    if(wmaj==bmaj && wmin-bmin==1 && wn-bn==2) tempw += NNvsB;
    if(wmaj==bmaj && bmin-wmin==1 && bn-wn==2) tempb += NNvsB;

    //NvsB
    if(wmaj==bmaj && wmin==bmin)
    {
        if(wn-bn==1) tempw += NvsB[wp+bp];
        else if(bn-wn==1) tempb += NvsB[wp+bp];
    }
*/
    scorer->bal[cW][OPE]+= tempw;
    scorer->bal[cW][END]+= tempw;

    scorer->bal[cB][OPE]+= tempb;
    scorer->bal[cB][END]+= tempb;

    /*
	endings - simple methods and material ajustments when one side has no pawns, no majors,
	and the other has pawns
	*/
	if(wmaj+bmaj==0)
	{
	   if(wmin+bmin==0)
	   {
		if(scorer->wp==1 && scorer->bp==0) KP_v_K();
		else if (scorer->wp==0 && scorer->bp==1) K_v_KP();
	   }
	   if(wmin<=2 && bmin==0 && scorer->wp == 0)
	   {
		   if(wmin==1)
		   {
			   if(scorer->wb==1 && scorer->bp==1) KB_v_KP();
			   else if(scorer->wn==1 && scorer->bp==1) KN_v_KP();
			   else if(scorer->bp==2) scorer->bal[cW][END] -= (vB+vP);//Minor vs 2P is bad
			   else scorer->bal[cW][END] -= (vB+vP+vP);//Minor vs 3P very bad, most likely losing
		   }
		   else
		   {
			   if(scorer->wn==2)
			   {
				   //cout<<"\n adjusting balance from "<<scorer->bal[cW][END]<<" to ";
				   scorer->bal[cW][END] -= (vN+vN+vP);//draw with 2N vs Pawns
				   //cout<<scorer->bal[cW][END];
			   }
		   }
	   }
	   else if(bmin<=2 && wmin==0 && scorer->bp == 0)
	   {
		   if(bmin==1)
		   {
			   if(scorer->bb==1 && scorer->wp==1) KP_v_KB();
			   else if(scorer->bn==1 && scorer->wp==1) KP_v_KN();
			   else if(scorer->wp==2) scorer->bal[cB][END] -= (vB+vP);//Minor vs 2P is bad
			   else scorer->bal[cB][END] -= (vB+vP+vP);//Minor vs 3P very bad, most likely losing
		   }
		   else
		   {
			   if(scorer->bn==2)
			   {
				   scorer->bal[cB][END] -= (vN+vN+vP);//drawing 2N vs pawns
			   }
		   }
	   }
	}
}

bool is_draw()
{
    if (!scorer->wr && !scorer->br && !scorer->wq && !scorer->bq)
	{
	  if (!scorer->bb && !scorer->wb)
	  {
	      if (scorer->wn < 3 && scorer->bn < 3) {  return true; }
	   }
	  else if (!scorer->wn && !scorer->bn)
	  {
	     if (abs(scorer->wb - scorer->bb) < 2) { return true; }
	  }
	  else if ((scorer->wn < 3 && !scorer->wb) || (scorer->wb == 1 && !scorer->wn))
	  {
	    if ((scorer->bn < 3 && !scorer->bb) || (scorer->bb == 1 && !scorer->bn))  { return true; }
	  }
	}
   else if (!scorer->wq && !scorer->bq)
   {
	if (scorer->wr == 1 && scorer->br == 1)
	{
	  if ((scorer->wn + scorer->wb) < 2 && (scorer->bn + scorer->bb) < 2)	{ return true; }
	}
	else if (scorer->wr == 1 && !scorer->br)
	{
	 if ((scorer->wn + scorer->wb == 0) && (((scorer->bn + scorer->bb) == 1) || ((scorer->bn + scorer->bb) == 2))) { return true; }
    }
	else if (scorer->br == 1 && !scorer->wr)
	{
	 if ((scorer->bn + scorer->bb == 0) && (((scorer->wn + scorer->wb) == 1) || ((scorer->wn + scorer->wb) == 2))) { return true; }
     }

    }
  return false;
}
