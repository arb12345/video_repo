#include "squares.h"
#include "piecedefs.h"
#include "defs.h"


const bool debug = true;
const string piecechars = ".PpNnBbRrQqKk";
const string colourchars = "wb";
                            //        E P p N n B b R r Q q K k
const uint ismajor[numpieces]    = {  0,0,0,0,0,0,0,1,1,1,1,0,0 };
const uint isminor[numpieces]    = {  0,0,0,1,1,1,1,0,0,0,0,0,0 };
const uint isbigpiece[numpieces] = {  0,0,0,1,1,1,1,1,1,1,1,0,0 };
const uint iswhite[numpieces]    = {  0,1,0,1,0,1,0,1,0,1,0,1,0 };
const uint isblack[numpieces]    = {  0,0,1,0,1,0,1,0,1,0,1,0,1 };
const uint isslide[numpieces]    = {  0,0,0,0,0,1,1,1,1,1,1,0,0 };
const uint iscolour[numpieces]   = {  cN,cW,cB,cW,cB,cW,cB,cW,cB,cW,cB,cW,cB };
const uint ispawn[numpieces]    = {   0,1,1,0,0,0,0,0,0,0,0,0,0 };


const uint sliders[numcolours][3] =
{
     {pwB,pwR,pwQ},
     {pbB,pbR,pbQ}
};


const uint nonsliders[numcolours][2] =
{
     {pwK,pwN},
     {pbK,pbN}
};

const uint pawns[numcolours] =
{
      pwP, pbP
};

const uint queens[numcolours] =
{
      pwQ, pbQ
};

const uint rooks[numcolours] =
{
      pwR, pbR
};

const uint bishops[numcolours] =
{
      pwB, pbB
};

const uint knights[numcolours] =
{
      pwN, pbN
};



const uint kings[numcolours] =
{
      pwK, pbK
};

const uint startrank[numcolours] =
{
      RANK2, RANK7
};

int	const dirN[] = { NNW, NNE, NWW, NEE, SSW, SSE, SEE, SWW, 0 };
int	const dirB[] = { NW, NE, SW, SE, 0 };
int	const dirR[] = { W, E, N, S, 0 };
int	const dirQ[] = { W, E, N, S, NW, NE, SW, SE, 0 };

int const *dirPieces[] = {
	0,
	0,
	0,
	dirN,dirN,
	dirB,dirB,
	dirR,dirR,
    dirQ,dirQ,
    dirQ,dirQ
};

int	const dirwP[] = { NW, NE, N, 0};
int	const dirbP[] = { SW, SE, S, 0};

int const *dirPawn[] = {
    0,
	dirwP,
	dirbP,
};

uint const epdelta[2] = {
    S,N
};


