#include "sts.h"
#include "utils.h"
#include "fen.h"
#include "log.h"
#include "searcher.h"
#include "clock.h"
#include "eval.h"
#include "utils.h"
#include "defs.h"
#include "move.h"

using namespace std;



cSTStuner::cSTStuner()
{
    ;
}

void cSTStuner::STStest()
{

    cout<<"\n called sts tester ";
    string line;
	uint i,j;

	tree->param->tuning = true; //stops output in search.

	STSfilepositions.clear();

    //read in the epd filename list into a vector
    vector<string> stsFileNames;
    ifile.open(IniFileName.c_str());
    if(!(ifile.is_open())) {cout<<"\n ini file not found"; return;}
    while (!ifile.eof() )
    {
      getline (ifile,line);
	  line += ".epd";
      stsFileNames.push_back(line);
	  line.clear();
    }
    ifile.close();
    
	//** vector stsFileNames is now holding the list of sts files to test **//

	stsfiles = stsFileNames.size();
	cout<<"\n Total of "<<stsfiles<<" read into store "<<endl;
    for(i=0; i < stsfiles; ++i)
	{
		cout<<" File "<<i+1<<" : "<<stsFileNames[i]<<endl;
	}
	cout<<endl;

	//** now process the files to extract positions and move storing them in the STSfilepositions vector **//
	for(i=0; i < stsfiles; ++i) processfile(stsFileNames[i]);

	//** now solve each position **//
	for(i=0; i < STSfilepositions.size(); ++i) 
	{
		score_position(STSfilepositions[i]);
		cout<<"\nFile "<<STSfilepositions[i].file_id<<" "<< STSfilepositions[i].fen<<" SCORE: "<<STSfilepositions[i].result;
	}

	system("PAUSE");

}

void cSTStuner::processfile(string name)
{
	cout<<"\n processing "<<name<<endl;
    string line;
	uint i,j;
	ifstream filein;
    
	//read in the epd lines into a vector
    vector<string> stsFileLines;
    filein.open(name.c_str());
    if(!(filein.is_open())) {cout<<"\n file not found"; return;}
    while (!filein.eof() )
    {
      getline (filein,line);
	 // cout<<"\n Live reading : "<<line;
	  if(line.length() < 30) break;
      stsFileLines.push_back(line);
	  line.clear();
    }
    filein.close();

	//1kr5/3n4/q3p2p/p2n2p1/PppB1P2/5BP1/1P2Q2P/3R2K1 w - - bm f5; id "Undermine.001"; c0 "f5=10, Be5+=2, Bf2=3, Bg4=2";
	
	//** for each line, extract the fen and the best moves with scores **//
	size_t finder;
	string fen,temp,sub,move,score;
	int tpos = 0,tsc;
	sPosition entry;
	sMoveScore holder;
	vector<string> substore;

    
	for(i=0; i < stsFileLines.size(); ++i)
	{
		//clear entry data
		entry.fen.clear();
		entry.bestmoves.clear();

		entry.file_id = name;

		//clear temporary store
		substore.clear();
		
		fen = stsFileLines[i];
		temp = fen;
		finder = fen.find(" bm");
		fen.erase(finder);

		entry.fen = fen; //fen now stored       
		
		finder = temp.find(" c0 \"");
		temp.erase(0,finder+5);
		finder = temp.find_first_of("\";");
		temp.erase(finder);

		//temp now reads as : f5=10, Be5+=2, Bf2=3, Bg4=2
		//next step is to remove the commas
		finder = temp.find_first_of(", ");
		while(finder!=string::npos)
		{
		 sub = temp.substr(0,finder);
		 temp.erase(0,finder+2);
		 substore.push_back(sub);
		 sub.clear();		 
	 	 finder = temp.find_first_of(", ");
		 if(finder==string::npos) substore.push_back(temp); //last move
		}

		//now run through the lines of removes commas, and extract move + score
		for(j = 0; j < substore.size(); ++j) 
		{
			move.clear();
			score.clear();
			holder.move.clear();
			holder.score = 0;

			temp = substore[j];
			finder = temp.find("=");
			move = temp.substr(0,finder);
			temp.erase(0,finder+1);
			score = temp;
			tsc = strtoint(score,tpos);

			holder.move = move;
			holder.score = tsc;

			entry.bestmoves.push_back(holder);
		}

		STSfilepositions.push_back(entry); //** add entry **//

		temp.clear();
		fen.clear();
	}

	cout<<"\n stored total of "<<STSfilepositions.size()<<" positions ";
}

void cSTStuner::score_position(sPosition &entry)
{
	string fen;
	string ourbest;
	int ourscore;
	fen = entry.fen;
	uint i;

	//set up depth limited testing	
    resettimeparam(cW);
    resettimeparam(cB);
    setdepth(1);
    setmodetpm(false);
    setmodemtg(false);
    setdepthlimit(true);

	setepdposition(fen.c_str());
	reset_tables();
    compute();
	ourbest = movetosan(getbestmove());
	ourscore = 0;

	//find our move in the list of bestmoves
	for(i = 0; i < entry.bestmoves.size(); ++i)
	{
		if(ourbest==entry.bestmoves[i].move) { ourscore = entry.bestmoves[i].score; break; }
	}

	entry.result = ourscore;
}


