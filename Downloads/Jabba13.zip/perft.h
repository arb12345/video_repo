#ifndef PERFT_H
#define PERFT_H

extern void perftsingle(uint depth);
extern void perftfile();

#endif
