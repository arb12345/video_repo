#ifndef MOVELIST_H
#define MOVELIST_H

#include "defs.h"
#include "piecedefs.h"
#include "squares.h"
#include "board.h"


struct sHistab {
    uint max;
    uint value[numpieces][BRDSQ]; //piece type and tosq
};

struct sKillers {
    uint k1[maxply];
    uint k2[maxply];
    uint mk[maxply];
};

struct sScoreOpt {
    bool histab;
    bool mvvlva;
    bool killer;
    bool hashmove;
    bool matekiller;
};

struct sOrderstats {
    uint killer1;
    uint killer2;
    uint histab;
    uint matekiller;
    uint capture;
    uint badcapture;
    uint hashmove;
    uint qprom;
    uint qpromcap;
    uint minorprom;
    uint epcapture;
    uint castle;
};

struct sMovelist {

        uint movelist[maxply][maxmoves];
        uint movecount[maxply];
        int movescores[maxply][maxmoves];
        sHistab histab;
        sKillers killers;
        uint pvmove;
        sOrderstats stats;
        sScoreOpt opt;
        const int *tab;

};

extern sMovelist mlist[1];

extern void mlist_init_opt();
extern void sortmoves(const uint &ply);
extern void printmovelist(uint &ply);//prints movelist for the current ply
extern void scoremove(uint &move, const uint &depth, const uint &pce);
extern void failowmove(uint &move, const uint &depth, const uint &pce);
extern void score_killer(uint &move, const int score, uint &ply);
extern void resethistab();
extern void resetkillers();
extern void resetmliststats();
extern void mlistsays_stats();

#define RESETCOUNT(p) (mlist->movecount[(p)]=0)
#define SETPVMOVE(p) (mlist->pvmove=(p))

#define MOVECOUNT(p) (mlist->movecount[(p)])
#define MOVE(p,i) (mlist->movelist[(p)][(i)])
#define MOVESCORE(p,i) (mlist->movescores[(p)][(i)])

#define SETMOVESCORE(p,i,s) (mlist->movescores[(p)][(i)]=(s))
#define SETMOVE(p,i,m) (mlist->movelist[(p)][(i)]=(m))
#define SETMOVECOUNT(p,s) (mlist->movecount[(p)]=(s))

#define INCRHISTAB(p,t,d) (mlist->histab.value[(p)][(t)] += (d))
#define HISTABVAL(p,t) (mlist->histab.value[(p)][(t)])

void ordermove(uint &move, uint &cap, const uint &flag, const uint &prom, uint &ply, uint pce,int *score);

inline void addmove(uint &from, uint &to, uint &cap, const uint &flag, const uint &prom, uint &ply, uint pce)
{
     ASS(ply<maxply);
     ASS(pce>=pwP&&pce<=pbK);
     ASS(cap>=pE&&cap<=pbK);
     ASS(prom>=pE&&prom<=pbK);
     ASS(onbrd(from));
     ASS(onbrd(to));
	 ASS(BRDPCE(from)>=pwP && BRDPCE(to)<=pbK);


     uint count = MOVECOUNT(ply);
     uint move = (from | (to<<7) | (cap<<16) | (prom<<20) | flag);
     mlist->movelist[ply][count] = move;

     mlist->movescores[ply][count] = -200;
     ordermove(move, cap, flag, prom, ply, pce, &mlist->movescores[ply][count]);
     ASS(mlist->movescores[ply][count]<=2600000 && mlist->movescores[ply][count]>=-100 && mlist->movescores[ply][count]!=-200);
     mlist->movecount[ply]++;
}

inline void addpawnmove(uint &from, uint &to, uint &cap, uint side, uint &ply, uint pce)
{
     ASS(onbrd(from));
     ASS(onbrd(to));
     ASS(colourgood(side));
     ASS(piecegood(cap)||cap==pE);
     ASS(ply<maxply);
     ASS(pce==pwP||pce==pbP);

     if(side==cW)
     {
         if(RANK(from)==RANK7)
         {
             ASS(RANK(to)==RANK8);
             addmove(from,to,cap,FlagE,pwQ,ply,pce);
             addmove(from,to,cap,FlagE,pwN,ply,pce);
             addmove(from,to,cap,FlagE,pwR,ply,pce);
             addmove(from,to,cap,FlagE,pwB,ply,pce);
         }
         else
         {
             addmove(from,to,cap,FlagE,FlagE,ply,pce);
         }

     }
     else
     {
         ASS(side==cB);
         if(RANK(from)==RANK2)
         {
             ASS(RANK(to)==RANK1);
             addmove(from,to,cap,FlagE,pbQ,ply,pce);
             addmove(from,to,cap,FlagE,pbN,ply,pce);
             addmove(from,to,cap,FlagE,pbR,ply,pce);
             addmove(from,to,cap,FlagE,pbB,ply,pce);
         }
         else
         {
             addmove(from,to,cap,FlagE,FlagE,ply,pce);
         }
     }
}

inline bool movehisbad1(uint move)
{
	uint to = TO(move);
	uint pce = BRDPCE(to);
    ASS(onbrd(to));
    ASS(piecegood(pce));

    if(HISTABVAL(pce,to)  < mlist->histab.max*60/100) return true;
	else return false;
}


inline bool movehisbad2(uint move)
{
	uint to = TO(move);
	uint pce = BRDPCE(to);
    ASS(onbrd(to));
    ASS(piecegood(pce));

    if(HISTABVAL(pce,to)  < mlist->histab.max*30/100) return true;
	else return false;
}

#endif

