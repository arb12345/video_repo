#ifndef MOVEGEN_H
#define MOVEGEN_H

#include "board.h"
#include "material.h"
#include "movelist.h"
#include "piecedefs.h"

extern void gen_all_moves(uint hashmove);
extern void gen_all_captures();
#endif

