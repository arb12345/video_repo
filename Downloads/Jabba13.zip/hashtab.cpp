#include <iostream>
#include <iomanip>
#include <malloc.h>
#include "hashtab.h"
#include "utils.h"
#include "squares.h"
#include "defs.h"
#include "log.h"


using namespace std;

const uint MB = 1000000;

sHashtable ttable[1];

void delete_tables()
{
   free(ttable->table);
   ttable->table = NULL;
}

void makenewtable(const uint elem)
{
     delete_tables();
     ttable->elements = elem;
     init_table_memory();
     reset_tables();
}

void init_table_memory()
{
  //get the size of a hash element
  uint tablesize = sizeof(sHashelem);
#ifdef DEBUG
  cout<<"\n";
  cout<<"Table elem size = "<<tablesize<<endl;
#endif

  if(ttable->elements<1) {cout<<"\n no hash memory defined for main table, exiting";exit(1);}

  // mulptiply for MB
  ttable->elements   *= MB;

  //divide numelem by the elemsize to get the number of ttable->elements
  ttable->elements /= tablesize;
#ifdef DEBUG
  cout<<"\n";
  cout<<"Num table ttable->elements = "<<ttable->elements;
#endif

  ttable->table = new sHashelem[ttable->elements];
  if (ttable->table == NULL){cout<<"\n error assigning table";exit(1);}

#ifdef DEBUG
  cout<<"\nTable memory occupation :";
  cout<<" = "<<(_msize(ttable->table))/1000<<" kB"<<endl;
#endif

  //reduce element numbers by four to prevent overwriting of the table array
  ttable->elements -= 2;

  reset_tables();
}

void reset_tables()
{
   uint i;
   resetcounters();
   for(i = 0; i < ttable->elements; ++i)
   {
           ttable->table[i].key = 0;
           ttable->table[i].move = NULLMOVE;
		   ttable->table[i].flag = 0;
           ttable->table[i].depth = 0;
           ttable->table[i].score = belowmate;
   }
}


void ttablesays_stats()
{
#ifdef DEBUG
    cout<<"\n Hash table: ";
    cout<<" write: "<<ttable->write<<" probe: "<<ttable->probe<<" hit: "<<ttable->hit;
    cout<<"\nhit success "<<percent(ttable->hit,ttable->hit+ttable->probe)<<"%";
    cout<<"\n% ttable->elements written from total = ";
    cout<<percent(ttable->write,ttable->elements)<<"%";
#endif
    if(islog())
    {
      logger.file<<"\n Hash table: ";
      logger.file<<" write: "<<ttable->write<<" probe: "<<ttable->probe<<" hit: "<<ttable->hit;
    logger.file<<"\nhit success "<<percent(ttable->hit,ttable->hit+ttable->probe)<<"%";
    logger.file<<"\n% ttable->elements written from total = ";
    logger.file<<percent(ttable->write,ttable->elements)<<"%\n";
    }
}


void store_hashentry(const int score, const uint flag, const uint move, const int depth, const u64 &key)
{
     ASS(score>=-matescore&&score<=matescore);
     ASS(depth<int(maxply)&&depth>0);
     ASS(flag==tFlagUPPER||flag==tFlagLOWER||flag==tFlagEXACT);
#ifdef DEBUG
uint sparemove = move;
     ASS( (onbrd(FROM(sparemove))&&onbrd(TO(sparemove))) || move==NULLMOVE );
#endif

     //make a pointer to assign to point at a table element
     sHashelem *pElem;
     pElem = ttable->table + (key % ttable->elements);

	 if(pElem->depth <= depth)
	 {
	   if(pElem->depth==0) ttable->write++;
       pElem->key = key;
       pElem->depth = depth;
	   pElem->flag = flag;
       pElem->move = move;
	   pElem->score = score;
	 }
}


uint probe_hashentry(int &score, const int depth, uint &move, const int &beta, bool &cannull, const u64 &key, const uint ply)
{
     ASS(depth<int(maxply)&&depth>0);
     ASS(ply>0&&ply<maxply);

     sHashelem *pElem;
     pElem = ttable->table + (key % ttable->elements);

     ttable->probe++;

     uint flag = tFlagNOTSET;

     if( pElem->key == key)
     {
      ttable->hit++;
      move = pElem->move;
      if(pElem->flag == tFlagUPPER && pElem->score < beta)
      cannull = false;
	  if(pElem->depth >= depth)
	  {
	   score = pElem->score;
	   flag = pElem->flag;
       ASS(score>=-matescore&&score<=matescore);
       ASS(flag!=tFlagNOTSET && (flag&(tFlagUPPER|tFlagLOWER|tFlagEXACT)));
       if (abs(score) > (matescore-200))
       {
	        if (score > 0)
	        score -= ply;
	        else
	        score += ply;
       }
      }
#ifdef DEBUG
        if(flag==tFlagLOWER||flag==tFlagEXACT) ASS(onbrd(FROM(move))&&onbrd(TO(move)));
        else if(flag==tFlagUPPER) ASS(move==NULLMOVE);
        else ASS( onbrd(FROM(move))&&onbrd(TO(move)) || move==NULLMOVE);
#endif
    }

    return flag;

}


