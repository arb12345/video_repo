#include <iostream>
#include <iomanip>
#include <string>

#include "defs.h"
#include "log.h"
#include "history.h"
#include "material.h"
#include "board.h"

using namespace std;

int cfr;


// taken from "C++ Promgramming In Easy Steps"
void inline_assert(const char *expr, bool result, const char *file, int line)
{
   if (!result)
   {
       if(islog())
       {
        logger.file<<" assertion *: "<< expr << " :* fails!! " << endl
       << "File: " << file << " line: " << line << endl
       << " ......aborting..... " << endl;
		logboard();
		logBB();
		if(GAMEMOVES) logallhistory();
       }
       cout<<" assertion *: "<< expr << " :* fails!! " << endl
       << "File: " << file << " line: " << line << endl
       << " ......aborting..... " << endl;
	   cout<<"cfr = "<<cfr;
       getchar();
       abort();
   }
}
