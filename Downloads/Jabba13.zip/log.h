#ifndef LOG_H
#define LOG_H

#include <fstream>

using namespace std;


struct sLog {

ofstream file;
bool logging;

};

extern sLog logger;

extern void loginit();
extern void logclose();
inline bool islog() { return logger.logging;}
inline void setlog(bool set) { logger.logging=set;  }
inline void logstart() { logger.logging = true; loginit(); }

#endif
