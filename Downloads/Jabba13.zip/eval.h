#ifndef EVAL_H
#define EVAL_H

#include "board.h"
#include "material.h"

const int tropQbit = 8;
const int tropRbit = 4;
const int tropBbit = 2;
const int tropNbit = 1;

struct sEvOpt {
	bool pawns;
	bool bishops;
	bool knights;
	bool rooks;
	bool queens;
	bool psqt;
	bool blocked;
	bool development;
	bool balance;
};

struct sEval {

 uint pawnfiles[numcolours];
 int pawns[2][2];
 int mob[2][2];
 int dev[2][2];
 int blo[2][2];
 int pos[2][2];
 int bal[2][2];
 int psq[2][2];
 int passer[2][2];
 int mat[2][2];
 int safe[2];
 int distance[BRDSQ][BRDSQ];

 bool hashhit;
 bool drawflag;
 bool useWsafety;
 bool useBsafety;

 int wp;
 int wn;
 int wb;
 int wr;
 int wq;
 int bp;
 int bn;
 int bb;
 int br;
 int bq;

 u64 wkcircle;
 u64 bkcircle;

 double counter;

 int wkatt; //white king under attack - first 3 bits the attnum, next bits the piece combination
 int wkdef; //white kings' defence
 int bkatt;
 int bkdef;

 sEvOpt opt[1];

};

 void init_distance();
 void safety_table_init();

 extern int kp_vs_k();
 extern void score_pawn();
 extern void score_bishops();
 extern void score_knights();
 extern void score_queens();
 extern void score_rooks();
 extern void score_kings();
 extern bool whitecandidate(const u64 &wocc, const u64 &bocc, const uint &sq, const uint &sq64);
 extern bool blackcandidate(const u64 &wocc, const u64 &bocc, const uint &sq, const uint &sq64);
 extern void balance();
 extern bool is_draw();

extern void KP_v_K();
extern void K_v_KP();
extern void KBP_v_K();
extern void K_v_KBP();
extern void KB_v_KP();
extern void KP_v_KB();
extern void KN_v_KP();
extern void KP_v_KN();

extern int eval_light_king(const uint &sq, const u64 &bocc, const u64 & wocc, const uint &file, const uint &rank);
extern int eval_lkp(const uint &sq, const u64 &bocc, const uint &file);
extern int eval_dark_king(const uint &sq, const u64 &bocc, const u64 & wocc, const uint &file, const uint &rank);
extern int eval_dkp(const uint &sq, const u64 &bocc, const uint &file);
extern int eval();
extern int lazyeval();
extern void eval_init_opt();
extern void logeval();
extern void eval_init();

extern sEval scorer[1];
extern int safety_table[15];






#endif

