#ifndef EVALPARAM_H
#define EVALPARAM_H

using namespace std;


struct sEvalParam {
    bool test;
    string name;
    int min;
    int max;
    int value;
};

extern int BPair;
extern int BmobminO;
extern int BmobminE;
extern int BmobsqO;
extern int BmobsqE;
extern int QmobminO;
extern int QmobminE;
extern int QmobsqO;
extern int QmobsqE;
extern int RmobminO;
extern int RmobminE;
extern int RmobsqO;
extern int RmobsqE;
extern int NmobminO;
extern int NmobminE;
extern int NmobsqO;
extern int NmobsqE;
extern int KingMid;
extern int KingP1;
extern int KingP2;
extern int KingP3;
extern int NSupp1;
extern int NSupp2;
extern int NSupp3;
extern int PDouOpe;
extern int PDouEnd;
extern int PIsoOpe;
extern int PIsoEnd;
extern int POpeOpe;
extern int POpeEnd;
extern int PBacOpe;
extern int PBacEnd;
extern int PPasOpe;
extern int PPasEnd;
extern int PPasConOpe;
extern int PPasConEnd;
extern int PPasRookEnd;
extern int PCanOpe;
extern int PCanEnd;
extern int QAttSide;
extern int QAttDir;
extern int QSevOpe;
extern int QSevEnd;
extern int RAttSide;
extern int RAttDir;
extern int RSevOpe;
extern int RSevEnd;
extern int RSemFile;
extern int ROpeFile;
extern int trR;
extern int trP;
extern int trB;
extern int minordev;
extern int majorsoon;
extern int psqPo;
extern int psqPe;
extern int psqPra;
extern int psqNo;
extern int psqBo;
extern int psqRo;
extern int psqQo;
extern int psqNe;
extern int psqBe;
extern int psqQe;
extern int psqKo;
extern int psqKe;
extern int PDouOpeWk;
extern int PDouEndWk;
extern int PIsoOpeWk;
extern int PIsoEndWk;
extern int tropNBRQ;
extern int tropBRQ;
extern int tropNRQ;
extern int tropRQ;
extern int tropNBQ;
extern int tropBQ;
extern int tropNQ;
extern int tropQ;
extern int tropNBR;
extern int tropBR;
extern int tropNR;
extern int tropR;
extern int tropNB;
extern int tropB;
extern int tropN;
extern int Qmato;
extern int Qmate;



extern sEvalParam  paramlist[];

extern void printevalparam();
extern void init_eval_param();
extern void set_param_value(int value, string name);
extern bool debugparam();

#endif
