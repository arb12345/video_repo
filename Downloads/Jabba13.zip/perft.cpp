#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <time.h>
#include <vector>

#include "movegen.h"
#include "make.h"
#include "move.h"
#include "fen.h"
#include "log.h"
#include "utils.h"
#include "defs.h"

using namespace std;

long long leafnodes;
long long allnodes;

void  go(uint depth)
{
   ASS(position_check());

    if (depth == 0){ leafnodes++; return; }

  //  cout<<"\n in go "<<depth;
  //  printboard();

  // cout<<"\nfail5";

    gen_all_moves(NULLMOVE);

   // cout<<"\nfail6";

   // printboard();
   // cout<<"\n printing movelist ";


  //  printmovelist(PLYNOW);

    for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
    {
   //  cout<<"\nfail8";
      //  cout<<"\n\tmove "<<i<<" "<<printmove(MOVE(PLYNOW,i));
   //     printboard();
     //   printmaterial();

     if (makemove(MOVE(PLYNOW,i)))
     {
       takemove();
       continue;
     }
    //    cout<<"\nfail9";

     go(depth-1);
     takemove();
    //   cout<<"\n back to go "<<depth;
    // printboard();
    // printmaterial();
    }

    return;
}


void   goroot(uint depth)
{
   if (depth == 0)  return;

   leafnodes = 0;

   u64 oldnodes = 0;
   u64 cumnodes = 0;

   gen_all_moves(NULLMOVE);
   int moves = 0;
   for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
   {
     //if(i!=28) continue;
    // if(FROM(MOVE(PLYNOW,i))!=B7 || TO(MOVE(PLYNOW,i))!=B2) continue;
     if (makemove(MOVE(PLYNOW,i)))
     {
        takemove();
        continue;
     }
     moves++;
   //  cout<<"\nfail4";
     cout<<"\nmove "<<moves<<" "<<printmove(MOVE(PLYNOW-1,i));

   //  printboard();
    // printmaterial();
   //  cout<<"\nfail3";
     cumnodes = leafnodes;
     go(depth-1);
   //  cout<<"\nfail1";
     takemove();
   //  printboard();
   //  cout<<endl;
  //   cout<<"\nfail2";
     oldnodes = leafnodes-cumnodes;
     cout<<" "<<oldnodes;
   }
   return;
}

void perftsingle(uint depth)
{
     double started = double(myclock());
     cout<<"\n perft with depth "<<depth;
     goroot(depth);
     double stopped = double(myclock());
     cout<<"\n leafnodes = "<<leafnodes;
     cout<<"\n time = "<<(stopped-started)/1000<<"s";
     if((stopped-started) < 1)
	 cout<<"\n NPS "<<((leafnodes)/1)/1000<<"kns";
	 else
	 cout<<"\n NPS "<<((leafnodes)/(stopped-started))/1000<<"kns";
}


void perftfile()
{
    string position;
    string temp;
    string marker;
    string textnodes;
    uint targetnodes = 0;
    vector<int> results;
    vector<string> p;

    if(islog())logger.file << "entered perftfile\n";


    ifstream file ("perftsuite.epd");

    uint depth = 0;
    cout<<"\n Enter depth >> ";
    cin>>depth;
    cout<<"\n";

    if(islog())logger.file << "depth "<<depth;

    switch(depth)
    {
        case 1: marker = "D1"; break;
        case 2: marker = "D2"; break;
        case 3: marker = "D3"; break;
        case 4: marker = "D4"; break;
        case 5: marker = "D5"; break;
        case 6: marker = "D6"; break;
        default: marker = "D4";break;
    }


    int pos = 0;
    int mark;
    string::iterator pline = temp.begin();

    if (file.is_open())
    {
      while (! file.eof() )
      {
       getline (file,position);
       if(position.length() < 2) break;
       temp = position;
       mark = temp.find(marker);
       temp.erase(0, mark+3);
       textnodes.clear();
       pline = temp.begin();
       while ( pline != temp.end() && *pline != ' ' )
       {
           textnodes+=*pline;
           *pline++;
       }

       targetnodes = strtouint(textnodes,0);

       temp = position;
       mark = temp.find(";");
       temp.erase(mark-1);

       pos++;

       cout<<"\n Testing Position "<<pos;
       cout<<temp;
       setepdposition(temp.c_str());
       p.push_back(temp);

       if(islog())logger.file << "testing position "<<pos<<"n";

       //game.printboard();
       perftsingle(depth);
       cout<<"\n\n Target nodes = "<<targetnodes;
       if(targetnodes != leafnodes)
       {
           cout<<"\n   FAIL\n";
           results.push_back(0);
           if(islog())logger.file << "FAIL\n";
       }
       else
       {
           results.push_back(1);
           if(islog())logger.file << "PASS\n";
       }
      }
    file.close();
    }
    else
    cout<<"\n file 'perftsuite.epd' not found!";
    if(islog())logger.file<<" file 'perftsuite.epd' not found!\n";

    cout<<"\n "<<pos<<" positions in total";
    for(uint i = 0; i < results.size(); ++i)
    {
        cout<<"\n position "<<i+1;

        if(results[i] == 0)
        {
            cout<<" FAILED ";
            cout<<p[i];
        }
        else
        {
            cout<<" PASSED";
        }
    }

    cout<<endl;

    return;
}

