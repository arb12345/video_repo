#ifndef TUNER_H
#define TUNER_H

#include <fstream>
#include <string.h>

#include "defs.h"
#include "searcher.h"

using namespace std;


struct fenstore {
    string fen;
    u64 key;
};

struct resultstore {
    string fen;
    int score;
};

class cTuner {

    private:
      cTuner( const cTuner & );
         cTuner &operator = ( const cTuner & );

    ifstream FileIn;
    ofstream FileOut;

    uint slow;
    uint slownotok;

    string FileInName;
    string FileOutName;

    uint maxperfile; //max positions per epd file
    int movesincecapture;
    int minpieces;
    int materialbalance;
    int ply;
    int samples;


    vector<fenstore> fenlines;
    vector<resultstore> resultlines;

    bool makesan(const string make);
    void readpgn(); //read pgn file, make epd file(s)
    bool materialequal();
    void sortfenlines();
    bool verifyindex(uint index);
    uint getmatindex();
    void makeepd();
    double runpositions();
    void tune();

    public:

    cTuner();

    void SetFileInName(string name) { FileInName = name; }
    void SetFileOutName(string name) { FileOutName = name; }
    void SetPly(int d) { ply = d; }
    void start(int what);

};

#endif


