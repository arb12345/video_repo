#include <iostream>
#include <string>

#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "board.h"
#include "evalparam.h"

const int knightsupp[64] = {
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0	,
0	,	0	,	1	,	2	,	2	,	1	,	0	,	0	,
0	,	1	,	2	,	3	,	3	,	2	,	1	,	0	,
0	,	1	,	3	,	4	,	4	,	3	,	1	,	0	,
0	,	0	,	1	,	2	,	1	,	1	,	0	,	0	,
0	,	0	,	0	,	0	,	0	,	0	,	0	,	0
};


void score_knights()
{
    uint piece;
	uint sq;
	uint enemy;

	int bonus = 0;

	piece = pwN;
	enemy = cB;

	int sqrs = 0;
    int mobop = 0;
    int mobend = 0;

    u64 pieceBB = GET_BB(piece);
    u64 moves;

    uint sq64;
    uint revsq;
    uint revsq64;

    while(pieceBB)
    {
      sq = POP64(pieceBB);
      sq64 = SQTO64(sq);
      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);
	  bonus=0;

	  //mobility
	  moves = knight_moves[sq64];
      moves &= (~mat->colBB[cW]);
      mobop = NmobminO;
      mobend = NmobminE;
      sqrs = popCount(moves);
      mobop += sqrs*NmobsqO;
      mobend += sqrs*NmobsqE;
      scorer->mob[cW][OPE] += mobop;
      scorer->mob[cW][END] += mobend;
      mobop = 0;
      mobend = 0;

      //king tropisim
      if(moves & scorer->bkcircle)
      {
          scorer->bkatt |= tropNbit;
      }

      if( (BRDPCE(sq+SE)==pwP || BRDPCE(sq+SW)==pwP) && knightsupp[sq64]!=0)
      {
		  bonus = knightsupp[sq64]*NSupp1;

		  if(! (P_BB(cB) & wknightsup[sq64]) )
		  {
			  bonus += knightsupp[sq64]*NSupp2;
		  }
		  if(scorer->bn==0)
		  {
			  if(scorer->bb==0) bonus += knightsupp[sq64]*NSupp3;
			  else if(scorer->bb==1 && sqcolour[LSB64(B_BB(cB))] != sqcolour[sq])
			  {
				  bonus += knightsupp[sq64]*NSupp3;
			  }
		  }
      }
	  scorer->pos[cW][OPE] += bonus;
    }


    piece = pbN;
    enemy = cW;
    pieceBB = GET_BB(piece);

    while(pieceBB)
    {
      sq = POP64(pieceBB);
      sq64 = SQTO64(sq);
      revsq = SQREV(sq);
      revsq64 = SQTO64(revsq);
      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);
	  bonus=0;

      //mobility
	  moves = knight_moves[sq64];
      moves &= (~mat->colBB[cB]);
      mobop = NmobminO;
      mobend = NmobminE;
      sqrs = popCount(moves);
      mobop += sqrs*NmobsqO;
      mobend += sqrs*NmobsqE;
      scorer->mob[cB][OPE] += mobop;
      scorer->mob[cB][END] += mobend;
      mobop = 0;
      mobend = 0;

      //king tropisim
      if(moves & scorer->wkcircle)
      {
          scorer->wkatt |= tropNbit;
      }


     if( (BRDPCE(sq+NE)==pbP || BRDPCE(sq+NW)==pbP) && knightsupp[revsq64]!=0)
     {
          bonus = knightsupp[revsq64]*NSupp1;

		  if(! (P_BB(cW) & bknightsup[sq64]) )
		  {
			  bonus += knightsupp[revsq64]*NSupp2;
		  }
		  if(scorer->wn==0)
		  {
			  if(scorer->wb==0) bonus += knightsupp[revsq64]*NSupp3;
			  else if(scorer->wb==1 && sqcolour[LSB64(B_BB(cW))] != sqcolour[sq])
			  {
				  bonus += knightsupp[revsq64]*NSupp3;
			  }
		  }
     }
	  scorer->pos[cB][OPE] += bonus;
    }
}
