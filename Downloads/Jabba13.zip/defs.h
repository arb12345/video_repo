#ifndef DEFS_H
#define DEFS_H

#include <iostream>
#include "log.h"
#include <string>

using namespace std;


typedef unsigned int uint;
typedef unsigned long long u64;

using namespace std;

//#define DEBUG

const string version = "Jabba 1.3";

//eval items
const uint OPE = 0;//phase
const uint END = 1;

const int belowmate = -32768;
const int matescore = 32768;

const int NOSET = 9999; //for the time controller


const int N = 16;
const int NW = 15;
const int NE = 17;
const int E = 1;
const int W = -1;
const int S = -16;
const int SE = -15;
const int SW = -17;

//knight directions
const int NNW = N+N+W;
const int NNE = N+N+E;
const int NEE = N+E+E;
const int NWW = N+W+W;
const int SSW = S+S+W;
const int SSE = S+S+E;
const int SEE = S+E+E;
const int SWW = S+W+W;

/*
from and to, seven bits each
cap piece, prom piece 4 bits each
flag ep,castle = 2bits

Total 24 bits

0000 0000 0000 0000 0111 1111 from
0000 0000 0011 1111 1000 0000 to
0000 0000 0100 0000 0000 0000 ep
0000 0000 1000 0000 0000 0000 ca
0000 1111 0000 0000 0000 0000 cappiece
1111 0000 0000 0000 0000 0000 prompiece
*/
//move inlines for to from sq, capture piece and prom piece and flag
const uint FlagEP = 0x4000;
const uint FlagCA = 0x8000;
const uint FlagE = 0x00;
const uint FlagCAPEP = (FlagEP | 0xf0000);

const uint NULLMOVE = 0xffff;

const uint maxply = 48;
const uint nomove = 0;
const uint maxmoves = 512; // max number of moves in a position
const uint maxgamelength = 1024;

inline uint FROM(uint &sq) { return (sq & 0x7f); }
inline uint TO(uint &sq) { return ((sq & 0x3f80)>>7); }
inline uint FLAG(uint &sq) { return (sq & 0xc000); }
inline uint CAP(uint &sq) { return ((sq & 0xf0000)>>16); }
inline uint PROM(uint &sq) { return ((sq & 0xf00000)>>20); }


const uint tFlagUPPER = 4;
const uint tFlagLOWER = 2;
const uint tFlagEXACT = 1;
const uint tFlagNOTSET = 8;

const uint FRCWK = 0;
const uint FRCWKR = 1;
const uint FRCWQR = 2;
const uint FRCBK = 3;
const uint FRCBKR = 4;
const uint FRCBQR = 5;

extern int cfr;


// taken from "C++ Promgramming In Easy Steps"
extern void inline_assert(const char *expr, bool result, const char *file, int line);

#ifdef DEBUG
#define ASS(expr) inline_assert(#expr, (expr), __FILE__, __LINE__)
#else
#define  ASS(exp)
#endif

//version notes
/*
version 1.3 following param in eval (tuned to 65k test pos)

{  true, "BPair",	0,	100,	42 },
{  true, "BmobminO",	-50,	50,	-13 },
{  true, "BmobminE",	-50,	50,	-16 },
{  true, "BmobsqO",	0,	50,	1 },
{  true, "BmobsqE",	0,	50,	2 },
{  true, "QmobminO",	-50,	50,	-40 },
{  true, "QmobminE",	-50,	50,	-47 },
{  true, "QmobsqO",	0,	50,	1 },
{  true, "QmobsqE",	0,	50,	0 },
{  true, "RmobminO",	-50,	50,	-35 },
{  true, "RmobminE",	-50,	50,	-35 },
{  true, "RmobsqO",	0,	50,	2 },
{  true, "RmobsqE",	0,	50,	0 },
{  true, "NmobminO",	-50,	50,	-12 },
{  true, "NmobminE",	-50,	50,	-18 },
{  true, "NmobsqO",	0,	50,	0 },
{  true, "NmobsqE",	0,	50,	0 },
{  true, "KingMid",	0,	100,	2 },
{  true, "KingP1",	0,	100,	0 },
{  true, "KingP2",	0,	100,	10 },
{  true, "KingP3",	0,	100,	7 },
{  true, "NSupp1",	0,	100,	0 },
{  true, "NSupp2",	0,	100,	5 },
{  true, "NSupp3",	0,	100,	10 },
{  true, "PDouOpe",	0,	100,	14 },
{  true, "PDouEnd",	0,	100,	5 },
{  true, "PIsoOpe",	0,	100,	5 },
{  true, "PIsoEnd",	0,	100,	8 },
{  false, "POpeOpe",	0,	100,	10 },
{  false, "POpeEnd",	0,	100,	10 },
{  true, "PBacOpe",	0,	100,	3 },
{  true, "PBacEnd",	0,	100,	2 },
{  true, "PPasOpe",	0,	100,	4 },
{  true, "PPasEnd",	0,	100,	7 },
{  true, "PPasConOpe",	0,	100,	1 },
{  true, "PPasConEnd",	0,	100,	0 },
{  true, "PPasRookEnd",	0,	100,	1 },
{  true, "PCanOpe",	0,	100,	0 },
{  true, "PCanEnd",	0,	100,	1 },
{  true, "QAttSide",	0,	100,	0 },
{  true, "QAttDir",	0,	100,	12 },
{  true, "QSevOpe",	0,	100,	2 },
{  true, "QSevEnd",	0,	100,	9 },
{  true, "RAttSide",	0,	100,	0 },
{  true, "RAttDir",	0,	100,	4 },
{  true, "RSevOpe",	0,	100,	9 },
{  true, "RSevEnd",	0,	100,	16 },
{  true, "RSemFile",	0,	100,	6 },
{  true, "ROpeFile",	0,	100,	4 },
{  false, "trR",	0,	500,	100 },
{  false, "trP",	0,	200,	50 },
{  false, "trB",	0,	400,	100 },
{  true, "minordev",	0,	50,	0 },
{  true, "majorsoon",	0,	50,	4 },
{  true, "psqPo",	-50,	50,	-21 },
{  true, "psqPe",	-50,	50,	-17 },
{  true, "psqPra",	-50,	50,	2 },
{  true, "psqNo",	-50,	50,	7 },
{  true, "psqNe",	-50,	50,	-9 },
{  true, "psqBo",	-50,	50,	-9 },
{  true, "psqBe",	-50,	50,	-10 },
{  true, "psqRo",	-50,	50,	-17 },
{  true, "psqQo",	-50,	50,	-32 },
{  true, "psqQe",	-50,	50,	-30 },
{  true, "psqKo",	-50,	50,	0 },
{  true, "psqKe",	-50,	50,	0 },
{  true, "PDouOpeWk",	0,	100,	17 },
{  true, "PDouEndWk",	0,	100,	15 },
{  true, "PIsoOpeWk",	0,	100,	14 },
{  true, "PIsoEndWk",	0,	100,	18 },
{  true, "tropNBRQ",	0,	100,	0 },
{  true, "tropBRQ",	0,	100,	10 },
{  true, "tropNRQ",	0,	100,	10 },
{  true, "tropRQ",	0,	100,	12 },
{  true, "tropNBQ",	0,	100,	11 },
{  true, "tropBQ",	0,	100,	26 },
{  true, "tropNQ",	0,	100,	14 },
{  true, "tropQ",	0,	100,	3 },
{  true, "tropNBR",	0,	100,	18 },
{  true, "tropBR",	0,	100,	18 },
{  true, "tropNR",	0,	100,	34 },
{  true, "tropR",	0,	100,	12 },
{  true, "tropNB",	0,	100,	24 },
{  true, "tropB",	0,	100,	18 },
{  true, "tropN",	0,	100,	3 },

version 1.3a: (tuned to the 90k test positions)
{  true, "BPair",	0,	100,	15 },
{  true, "BmobminO",	-50,	50,	-18 },
{  true, "BmobminE",	-50,	50,	-16 },
{  true, "BmobsqO",	0,	50,	1 },
{  true, "BmobsqE",	0,	50,	2 },
{  true, "QmobminO",	-50,	50,	-50 },
{  true, "QmobminE",	-50,	50,	-50 },
{  true, "QmobsqO",	0,	50,	0 },
{  true, "QmobsqE",	0,	50,	0 },
{  true, "RmobminO",	-50,	50,	-50 },
{  true, "RmobminE",	-50,	50,	-50 },
{  true, "RmobsqO",	0,	50,	1 },
{  true, "RmobsqE",	0,	50,	0 },
{  true, "NmobminO",	-50,	50,	-44 },
{  true, "NmobminE",	-50,	50,	-28 },
{  true, "NmobsqO",	0,	50,	0 },
{  true, "NmobsqE",	0,	50,	0 },
{  true, "KingMid",	0,	100,	2 },
{  true, "KingP1",	0,	100,	0 },
{  true, "KingP2",	0,	100,	10 },
{  true, "KingP3",	0,	100,	6 },
{  true, "NSupp1",	0,	100,	0 },
{  true, "NSupp2",	0,	100,	3 },
{  true, "NSupp3",	0,	100,	10 },
{  true, "PDouOpe",	0,	100,	8 },
{  true, "PDouEnd",	0,	100,	4 },
{  true, "PIsoOpe",	0,	100,	5 },
{  true, "PIsoEnd",	0,	100,	7 },
{  false, "POpeOpe",	0,	100,	10 },
{  false, "POpeEnd",	0,	100,	10 },
{  true, "PBacOpe",	0,	100,	2 },
{  true, "PBacEnd",	0,	100,	3 },
{  true, "PPasOpe",	0,	100,	6 },
{  true, "PPasEnd",	0,	100,	6 },
{  true, "PPasConOpe",	0,	100,	0 },
{  true, "PPasConEnd",	0,	100,	0 },
{  true, "PPasRookEnd",	0,	100,	0 },
{  true, "PCanOpe",	0,	100,	0 },
{  true, "PCanEnd",	0,	100,	2 },
{  true, "QAttSide",	0,	100,	0 },
{  true, "QAttDir",	0,	100,	8 },
{  true, "QSevOpe",	0,	100,	0 },
{  true, "QSevEnd",	0,	100,	4 },
{  true, "RAttSide",	0,	100,	0 },
{  true, "RAttDir",	0,	100,	1 },
{  true, "RSevOpe",	0,	100,	15 },
{  true, "RSevEnd",	0,	100,	6 },
{  true, "RSemFile",	0,	100,	4 },
{  true, "ROpeFile",	0,	100,	4 },
{  false, "trR",	0,	500,	100 },
{  false, "trP",	0,	200,	50 },
{  false, "trB",	0,	400,	100 },
{  true, "minordev",	0,	50,	0 },
{  true, "majorsoon",	0,	50,	0 },
{  true, "psqPo",	-50,	50,	-33 },
{  true, "psqPe",	-50,	50,	-21 },
{  true, "psqPra",	-50,	50,	1 },
{  true, "psqNo",	-50,	50,	-9 },
{  true, "psqNe",	-50,	50,	-9 },
{  true, "psqBo",	-50,	50,	-36 },
{  true, "psqBe",	-50,	50,	-20 },
{  true, "psqRo",	-50,	50,	-50 },
{  true, "psqQo",	-50,	50,	-50 },
{  true, "psqQe",	-50,	50,	-50 },
{  true, "psqKo",	-50,	50,	0 },
{  true, "psqKe",	-50,	50,	0 },
{  true, "PDouOpeWk",	0,	100,	14 },
{  true, "PDouEndWk",	0,	100,	13 },
{  true, "PIsoOpeWk",	0,	100,	12 },
{  true, "PIsoEndWk",	0,	100,	14 },
{  true, "tropNBRQ",	0,	100,	0 },
{  true, "tropBRQ",	0,	100,	5 },
{  true, "tropNRQ",	0,	100,	0 },
{  true, "tropRQ",	0,	100,	5 },
{  true, "tropNBQ",	0,	100,	14 },
{  true, "tropBQ",	0,	100,	28 },
{  true, "tropNQ",	0,	100,	3 },
{  true, "tropQ",	0,	100,	1 },
{  true, "tropNBR",	0,	100,	11 },
{  true, "tropBR",	0,	100,	13 },
{  true, "tropNR",	0,	100,	34 },
{  true, "tropR",	0,	100,	24 },
{  true, "tropNB",	0,	100,	23 },
{  true, "tropB",	0,	100,	34 },
{  true, "tropN",	0,	100,	8 },

*/

#endif

