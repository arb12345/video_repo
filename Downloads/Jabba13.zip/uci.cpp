#include <iostream>
#include <iomanip>
#include <string>
#include "engine.h"
#include "board.h"
#include "squares.h"
#include "piecedefs.h"
#include "log.h"
#include "fen.h"
#include "make.h"
#include "movegen.h"
#include "attack.h"
#include "searcher.h"
#include "utils.h"
#include "clock.h"
#include "eval.h"
#include "defs.h"
#include "book.h"


using namespace std;

void uciposition(string line);
void init_go();
void uci_go(string command);
void sayucioptions();
void setucioptions(string input);

SEngineOpt engopt;

void initucioptions()
{
    engopt.ponder  = false;
}

void sayversion()
{
    cout<<"id name "<<version<<endl;
    cout<<"id author Richard Allbert\n"<<endl;
    tree->uci = true;
    tree->xb = false;
    fflush(stdout);
}

void process_uci()
{
    setbuf(stdout, NULL);
    setbuf(stdout, NULL);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);

	string input;

	initucioptions();
        sayversion();
	sayucioptions();
	cout<<"uciok\n";

	int pos;
	while(getline(cin, input))
	{
	  fflush(stdout);
	  if(islog()) logger.file<<"\nUCI COMMAND IN : "<<input<<endl;

	 if(findsubstr("uci", input, pos))
	 {
	  sayversion();
	  sayucioptions();
	  cout<<"uciok\n";
	  continue;
	 }
	 else if(findsubstr("isready", input, pos))
	 {
	  cout<<"readyok\n";
	  continue;
	 }
	 else if(findsubstr("quit", input, pos))
	 {
	 	return;
	 }
	 else if(findsubstr("ucinewgame", input, pos))
	 {
	 	continue;
	 }
	 else if(findsubstr("position", input, pos))
	 {
	 	uciposition(input);
		continue;
	 }
	 else if(findsubstr("setoption", input, pos))
	 {
                setucioptions(input);
                continue;
	 }
	 else if(findsubstr("go", input, pos))
	 {
		 uci_go(input);
		 continue;
	 }
	 else if(findsubstr("eval", input, pos))
	 {
		 cout<<"\n eval score: "<<eval();
		 cout<<endl;
		 continue;
	 }
	 else if(findsubstr("print", input, pos))
	 {
		 printboard();
		 cout<<endl;
		 continue;
	 }
	 else
	 {
	  cout<<"unknown command "<<input<<endl;
	  continue;
	 }
	}
}

void uciposition(string line)
{

	int start = line.find("startpos");
	int fen = line.find("fen ");
	if (start!=-1) //we have a startpos command
	{
        setepdposition(startfen);
	}
	else if(fen!=-1)
	{
		//erase the "position fen " part to send the position string
		line.erase(0, fen+4);
		setepdposition(line);
	}
	else
	{
		cout<<"\n error - not starting position defined \n";
		return;
	}

	if(line.find("moves ")==string::npos) return; // no moves
    line.erase(0, line.find("moves ")+6);
	string move;
	string::iterator pline = line.begin();

    while ( pline != line.end() )
    {
    	if ( *pline == ' ' )
		{
			if(!parse_move(move)) {cout<<" ERROR parsing "<<move;return;}
			move.clear();
			*pline++;
			continue;
		}
		move+=*pline;
		*pline++;
    }

	if(!parse_move(move)) {cout<<" ERROR parsing "<<move;return;}

	//tree.game.printboard();
	//cout<<endl;

	return;
}



void init_go()
{
          resettimeparam(cW);
	      resettimeparam(cB);
}


void uci_go(string command)
{
	init_go();

	string input;
	int pos;

	 if(findsubstr("depth", command, pos))
	 {
		  setdepth(strtouint(command, pos+6));
          setmodetpm(false);
          setmodemtg(false);
          setdepthlimit(true);
          #ifdef DEBUG
		  cout<<" set depth to "<<GETDEPTH<<endl;
		  #endif
	 }
	 if(findsubstr("movetime", command, pos))
	 {
		  settimepermove(strtouint(command, pos+9));
          setmodetpm(true);
          setmodemtg(false);
          setdepthlimit(false);
          setdepth(maxply);
	 }
	 if(findsubstr("infinite", command, pos))
	 {
	     setmode(smINFINITE);
	 }
	 if(findsubstr("wtime", command, pos))
	 {
	     setmovetime(strtoint(command, pos+6), cW);
	     setmodetpm(false);
         setdepth(maxply);
	 }
	 if(findsubstr("btime", command, pos))
	 {
	     setmovetime(strtoint(command, pos+6), cB);
	     setmodetpm(false);
         setdepth(maxply);
	 }
	 if(findsubstr("winc", command, pos))
	 {
	     setinc(strtoint(command, pos+5),cW);
	 }
	 if(findsubstr("binc", command, pos))
	 {
	     setinc(strtoint(command, pos+5),cW);
	 }
	 if(findsubstr("ponder", command, pos))
	 {
	     setmode(smPONDER);
	 }
	 if(findsubstr("movestogo", command, pos))
	 {
	    setmovestogo(strtoint(command, pos+10),SIDENOW);
        setmodemps(strtoint(command, pos+10));
	 }

	 if(islog())
     {
	   logger.file <<"Jabba entering think \nmovestogo "<<GETMTG(cW)<<"(w) "<<GETMTG(cB)<<"(b)";
	   logger.file <<"\ndepth "<<GETDEPTH;
	   logger.file <<"\nwtime "<<GETMOVETIME(cW);
	   logger.file <<"\nbtime "<<GETMOVETIME(cB);
	   logger.file <<"\nmovetime "<<GETTPM<<"\n";
     }

	  compute();
	  uint best = getbestmove();
      setmode(smNONE);
#ifdef DEBUG
	  logboard();
#endif
      if(islog())
      {
          logger.file <<"out of compute, bestmove "<<printmove(best);
          logger.file <<" ponder "<<printmove(getpondermove())<<endl;
      }
	  fflush(stdout);
	  cout<<"\nbestmove "<<printmove(getbestmove());
	  if(engopt.ponder)
	  {
	   cout<<" ponder "<<printmove(getpondermove());
	   setmode(smNONE);
	  }
	  cout<<endl;
	  fflush(stdout);
	  if(islog())
	  logger.file.flush();
}


void sayucioptions()
{
    cout<<"option name Hash type spin default 32 min 16 max 1024\n";
    cout<<"option name Ponder type check default false\n";
	cout<<"option name OwnBook type check default false\n";
	cout<<"option name UCI_Chess960 type check default false\n";
	cout<<"option name ClearHash type button\n";
	cout<<"option name UseFutility1 type check default true\n";
	cout<<"option name UseFutility2 type check default true\n";
	cout<<"option name Fultility1Margin type spin default 50 min 0 max 500\n";
	cout<<"option name Fultility2Margin type spin default 500 min 0 max 20000\n";
    cout<<"option name SearchNullmove type check default true\n";
    cout<<"option name SearchIID type check default true\n";
    cout<<"option name HashTableCuts type check default true\n";
}

void setucioptions(string input)
{
    int pos;
    string sub;
    uint temp;
    if(findsubstr("setoption name Hash value ", input, pos))
    {
        sub =  "setoption name Hash value ";
        temp = strtoint(input,sub.length());
        if(temp> 1024) temp = 1024;
        if(temp < 16) temp = 16;
        delete_tables();
        makenewtable((int)temp);
    }
    else if(findsubstr("setoption name Ponder value ", input, pos))
    {
        if(findsubstr("true", input, pos)) engopt.ponder = true;
        else if(findsubstr("false", input, pos)) engopt.ponder = false;
    }
    else if(findsubstr("setoption name UCI_Chess960 value ", input, pos))
    {
        if(findsubstr("true", input, pos)) engopt.variant = 2;
        else if(findsubstr("false", input, pos)) engopt.variant = 1;
    }
	else if(findsubstr("setoption name OwnBook value ", input, pos))
    {
        if(findsubstr("true", input, pos)) bookread.setbookuse(true);
        else if(findsubstr("false", input, pos)) bookread.setbookuse(false);
    }
	else if(findsubstr("setoption name UseFutility1 value ", input, pos))
    {
        if(findsubstr("true", input, pos)) tree->opt->futility1 = true;
        else if(findsubstr("false", input, pos)) tree->opt->futility1 = false;
    }
	else if(findsubstr("setoption name UseFutility2 value ", input, pos))
    {
        if(findsubstr("true", input, pos)) tree->opt->futility2 = true;
        else if(findsubstr("false", input, pos)) tree->opt->futility2 = false;
    }
	else if(findsubstr("setoption name SearchNullmove value ", input, pos))
    {
        if(findsubstr("true", input, pos)) tree->opt->donull = true;
        else if(findsubstr("false", input, pos)) tree->opt->donull = false;
    }
	else if(findsubstr("setoption name SearchIID value ", input, pos))
    {
        if(findsubstr("true", input, pos)) tree->opt->iid = true;
        else if(findsubstr("false", input, pos)) tree->opt->iid = false;
    }
	else if(findsubstr("setoption name HashTableCuts value ", input, pos))
    {
        if(findsubstr("true", input, pos)) tree->opt->usehash = true;
        else if(findsubstr("false", input, pos)) tree->opt->usehash = false;
    }
    else if(findsubstr("setoption name ClearHash", input, pos))
	{
		reset_tables();
	}
	else if(findsubstr("setoption name Fultility1Margin value ", input, pos))
    {
        sub =  "setoption name Fultility1Margin value ";
        temp = strtoint(input,sub.length());
        if(temp > 500) temp = 500;
        if(temp < 0) temp = 0;
		tree->opt->f1marg = temp;
    }
	else if(findsubstr("setoption name Fultility2Margin value ", input, pos))
    {
        sub =  "setoption name Fultility2Margin value ";
        temp = strtoint(input,sub.length());
        if(temp > 20000) temp = 20000;
        if(temp < 0) temp = 0;
		tree->opt->f2marg = temp;
    }
    fflush(stdout);
}

