#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>
#include <iomanip>

#include "testers.h"
#include "fen.h"
#include "log.h"
#include "searcher.h"
#include "clock.h"
#include "eval.h"
#include "utils.h"
#include "defs.h"
#include "move.h"


using namespace std;

cTester tester;

void tester_init()
{
    tester.inputfilename = "noinputfile.dat";
    tester.outputfilename = "nooutputfile.dat";
    tester.timeperposition = 0;
	tester.depthset = 0;
}
//using mirror.epd, 160k positions
void evalmirror()
{
    string line;
    int quit=0;
    int ev1,ev2;
    int num=0;
    tester.inputfilename = "mirror.epd";
    tester.ifile.open(tester.inputfilename.c_str());
    if(!(tester.ifile.is_open())) {cout<<"\n file not found"; return;}

    while (!tester.ifile.eof() )
    {
      getline (tester.ifile,line);
      if(num%10000==0) cout<<"\n ---> "<<num;
	  //if(num<110) continue;
      //cout<<"\n ---> "<<num;
      setepdposition(line.c_str());
      //tree.game.printboard();
      /*tree.mat.printmaterial();*/
      ev1=eval();
      /*cout<<"\n Mirror...\n";*/
      mirrorboard();
      /*tree.game.printboard();
      tree.mat.printmaterial();*/

      ev2=eval();

	  //ev2=99999;
      if(ev1!=ev2 && num!=115)
      {
          cout << "\n fail !! ev1: "<<ev1<<" ev2: "<<ev2;
          cout<<"\nPosition epd  "<<line<<endl;
          cout<<"\n position number "<<num;
          cout<<"\n Enter 1 to quit, any number to go on... -->";
      cin>>quit;
      if(quit==1) break;
      }
/*
      cin>>quit;
      if(quit==1) break;
*/
      num++;
    }
    tester.ifile.close();

    cout<<"\n Mirror Eval Test Complete ";
    cout<<endl;
    return;
}


void features()
{
    string line;
    int ev1;
    int num=0;;
    ifstream ifile;
    ifile.open("pos.epd");
    if(!(ifile.is_open())) {cout<<"\n file not found"; return;}

    while (!ifile.eof() )
    {
      getline (ifile,line);
      if(num%10000==0) cout<<"\n ---> "<<num;
      setepdposition(line.c_str());
      ev1=eval();
      num++;
    }
    ifile.close();
    cout<<"\n Complete, score  "<<scorer->counter;
    cout<<endl;
    return;
}


struct sBenchres
{
    double nulltry,nullcuts;
    double qnodes,nodes;
    double fh,fhf;
    double time;
};

void cumulate(sBenchres &cum, sBenchres entry)
{
    cum.nulltry += entry.nulltry;
    cum.nullcuts += entry.nullcuts;
    cum.qnodes += entry.qnodes;
    cum.nodes += entry.nodes;
    cum.fh += entry.fh;
    cum.fhf += entry.fhf;
    cum.time += entry.time;
}

void benchmark()
{

    vector<sBenchres> results;
    sBenchres storeme;
    sBenchres cumulative;

    uint start = myclock();

    memset(&cumulative, 0, sizeof(sBenchres));

    if(islog())
    {
        logger.file<<"Benchmark test, inputfile <"<<tester.inputfilename<<">";
        logger.file<<" outputfile <"<<tester.outputfilename<<">";
        if(tester.depthset!=0) logger.file<<" depth set to "<<tester.depthset<<endl;
        else logger.file<<" movetime set to "<<tester.timeperposition<<endl;
    }

    cout<<"Benchmark test, inputfile <"<<tester.inputfilename<<">";
    cout<<" outputfile <"<<tester.outputfilename<<">";
    if(tester.depthset!=0) cout<<" depth set to "<<tester.depthset<<endl;
    else cout<<" movetime set to "<<tester.timeperposition<<endl;

    setmode(smNONE);
    string line;
    int num=0;
    tester.ifile.open(tester.inputfilename.c_str());
    tester.ofile.open(tester.outputfilename.c_str());
    if(!(tester.ifile.is_open())) {cout<<"\n file not found"; return;}

    while (!tester.ifile.eof() )
    {
      getline (tester.ifile,line);
      resettimeparam(cW);
      resettimeparam(cB);
      if(tester.depthset!=0)
      {
          ASS(tester.timeperposition==0);
          setdepth(tester.depthset);
          setmodetpm(false);
          setmodemtg(false);
          setdepthlimit(true);
      }
      else
      {
	   settimepermove(tester.timeperposition);
       setmodetpm(true);
      }
      setepdposition(line.c_str());
	  reset_tables();
      compute();
      cout<<"\n elapsed "<<TIMEELAPSED/1000<<"s\n";
      storeme.fh = tree->stats->fh;
      storeme.fhf = tree->stats->fhf;
      storeme.nulltry = tree->stats->nulltry;
      storeme.nullcuts = tree->stats->nullcuts;
      storeme.nodes = tree->data->nodes;
      storeme.qnodes = tree->data->qnodes;
      storeme.time = TIMEELAPSED;
      results.push_back(storeme);
      cumulate(cumulative,storeme);
      num++;
    }

    tester.ifile.close();

    cout<<"\n num positions = "<<results.size();
    cout<<"\n total time = "<<cumulative.time;
    cout<<"\n total nodes = "<<cumulative.qnodes+cumulative.nodes;
    cout<<"\n nps = "<<((cumulative.qnodes+cumulative.nodes)/((cumulative.time)/1000))<<"nps\n";

	tester.ofile<<"\n num positions = "<<results.size();
    tester.ofile<<"\n total time = "<<cumulative.time;
    tester.ofile<<"\n total nodes = "<<cumulative.qnodes+cumulative.nodes;
    tester.ofile<<"\n nps = "<<((cumulative.qnodes+cumulative.nodes)/((cumulative.time)/1000))<<"nps\n";

    uint i;

    for(i = 0; i < results.size(); ++i)
    {
        tester.ofile<<"\npos,"<<(i+1)<<",fh,"<<results[i].fh<<",fhf,"<<results[i].fhf;
        tester.ofile<<","<<percent(int(results[i].fhf),int(results[i].fh+results[i].fhf))<<",%";
        tester.ofile.flush();
    }
    tester.ofile<<"\nTotal,->,fh,"<<cumulative.fh<<",fhf,"<<cumulative.fhf;
    tester.ofile<<","<<percent(int(cumulative.fhf),int(cumulative.fh+cumulative.fhf))<<",%";

    for(i = 0; i < results.size(); ++i)
    {
        tester.ofile<<"\npos,"<<i+1<<",nodes,"<<results[i].nodes<<",qnodes,"<<results[i].qnodes;
        tester.ofile<<","<<percent(int(results[i].qnodes),int(results[i].nodes+results[i].qnodes))<<",%qnodes";
        tester.ofile.flush();
    }
    tester.ofile<<"\nTotal,->,qnodes,"<<cumulative.qnodes<<",nodes,"<<cumulative.nodes;
    tester.ofile<<","<<percent(int(cumulative.qnodes),int(cumulative.qnodes+cumulative.nodes))<<",%";

    for(i = 0; i < results.size(); ++i)
    {
        tester.ofile<<"\npos,"<<(i+1)<<",nulltry,"<<results[i].nulltry<<",nullcuts,"<<results[i].nullcuts;
        tester.ofile<<","<<percent(int(results[i].nullcuts),int(results[i].nulltry+results[i].nullcuts))<<",%";
        tester.ofile.flush();
    }
    tester.ofile<<"\nTotal,->,nulltry,"<<cumulative.nulltry<<",nullcuts,"<<cumulative.nullcuts;
    tester.ofile<<","<<percent(int(cumulative.nullcuts),int(cumulative.nulltry+cumulative.nullcuts))<<",%";
    tester.ofile<<"Total time "<<((myclock()-start)/1000)<<"s"<<endl;
    tester.ofile.close();

    if(islog())
    {
         logger.file<<"Total time "<<((myclock()-start)/1000)<<"s"<<endl;
         logger.file<<"\n\n-----------------> Benchmark Test Complete <-------------------";
         logger.file.flush();
    }

    cout<<"\n Benchmark Test Complete ";
    cout<<endl;

    return;
}

//each epd line is broken down into the fen string and the best moves,
//to be stored in the sEpdline structure

#define TYPEBM 1
#define TYPEAM 2

struct sEpdline {
    string fen;
    vector<string> bestmove;
    int type;
};

struct sTestResults {
    double solved;
    double notsolved;
    vector<bool> success;
    vector<string> ourmove;
    vector<uint> ourintmove;
	u64 totalnodes;
	double totaltime;
};


void epdtest()
{
    cout<<"\n called epdtest";
    string line;

    if(islog()) logger.file<<"EPD TESTING ACTIVE\n";

    //read in the epd file into a vector
    vector<string> positions;
    tester.ifile.open(tester.inputfilename.c_str());
    if(!(tester.ifile.is_open())) {cout<<"\n file not found"; return;}
    while (!tester.ifile.eof() )
    {
      getline (tester.ifile,line);
      if(line.length() < 29)
      {
          cout<<"\n bad position ? <"<<line<<">";
      }
      else
      {
          positions.push_back(line);
      }
    }
    tester.ifile.close();


    vector<string> tokenized;//tokenize epd lines by spaces
    string tempfen;
    sEpdline entry;
    uint index;
    uint index2;
    int type;
    size_t finder;
    vector<sEpdline> testdata;

    bool foundbest=false;
    for(index = 0; index < positions.size(); ++index)
    {
        type=0;
        tokenized.clear();
        tempfen.clear();
        entry.fen.clear();
        entry.bestmove.clear();

        stringsplitter(positions[index], ' ', tokenized);
        index2 = 0;

        foundbest=false;
        while(tokenized[index2]!="bm" && tokenized[index2]!="am")
        {
           tempfen+=tokenized[index2];
           tempfen+=' ';
           index2++;
        }
        entry.fen = tempfen;

        ASS(tokenized[index2]=="bm" || tokenized[index2]=="am");
        foundbest=true;

        if(tokenized[index2]=="bm") type = TYPEBM;
        else if(tokenized[index2]=="am") type = TYPEAM;

        if(!type) cout<<"\n bestmove not found -> "<<positions[index];

        entry.type = type;


        index2++;
        while((finder = tokenized[index2].find(';')) == string::npos)
        {
            entry.bestmove.push_back(tokenized[index2]);
            index2++;
            finder = tokenized[index2].find(';');
        }

        tokenized[index2].erase(tokenized[index2].length()-1);//take off ';'
        entry.bestmove.push_back(tokenized[index2]);

        testdata.push_back(entry);

    }

    if(islog()) logger.file<<"EPD file read in : <"<<tester.inputfilename<<">\n";

    tokenized.clear();
    positions.clear();

    cout<<"***************EPD LOADED************";
    cout<<"\n "<<testdata.size()<<" test positions in total ";
    if(islog()) logger.file<<"testing "<<testdata.size()<<" test positions in total ";

	tree->status->mode=smNONE;
	tree->param->epd = true;

    string ourbest;
    sTestResults results;
    results.solved = 0;
    results.notsolved = 0;
    results.success.clear();
	results.totalnodes = 0;
	results.totaltime = 0;
    bool success = false;
    for(index = 0; index < testdata.size(); ++index)
    {
      success=false;
      line.clear();
      ourbest.clear();
      line = testdata[index].fen;
      resettimeparam(cW);
      resettimeparam(cB);
      if(tester.depthset!=0)
      {
          ASS(tester.timeperposition==0);
          setdepth(tester.depthset);
          setmodetpm(false);
          setmodemtg(false);
          setdepthlimit(true);
      }
      else
      {
	   settimepermove(tester.timeperposition);
       setmodetpm(true);
      }
      setepdposition(line.c_str());
	  reset_tables();
      cout<<"\n"<<tester.outputfilename<<" position "<<index<<"\nfen: "<<line;
	  cout<<endl;
	  //printboard();
	  //cout<<endl;
      compute();
	  //printboard();
      cout<<"\n Elapsed "<<TIMEELAPSED/1000<<"s\n";
	  results.totaltime+=TIMEELAPSED;
	  results.totalnodes+=(tree->data->nodes+tree->data->qnodes);
      ourbest = movetosan(getbestmove());
      type = testdata[index].type;
       for(index2 = 0; index2 < testdata[index].bestmove.size(); ++index2)
       {
            if(type==TYPEBM && ourbest==testdata[index].bestmove[index2])success = true;
            else if(type==TYPEAM && ourbest!=testdata[index].bestmove[index2])success = true;
       }

       if(islog()) logger.file<<" "<<tester.outputfilename<<" position "<<index;
       if(success)
       {
           cout<<"\n SOLVED :)";
           if(islog()) logger.file<<" SOLVED :) \n";
           results.solved++;
       }
       else
       {
           cout<<"\n NOT SOLVED :(";
           if(islog()) logger.file<<" NOT SOLVED :( \n";
           results.notsolved++;
       }
       results.success.push_back(success);
       results.ourmove.push_back(ourbest);
       results.ourintmove.push_back(getbestmove());
       cout<<"\n\n So Far: "<<results.solved<<" solved from "<<results.success.size();
       cout<<" "<<percent((int)results.solved, (int)results.success.size())<<"%";

       if(islog())
       {
           logger.file<<"So Far: "<<results.solved<<" solved from "<<results.success.size();
           logger.file<<" "<<percent((int)results.solved, (int)results.success.size())<<"%\n";
           logger.file.flush();
       }

    }


    if(islog()) logger.file<<"EPD testing over, writing result file ";
    tester.ofile.open(tester.outputfilename.c_str());

    ASS(testdata.size()==results.success.size());
    tester.ofile<<"EPD file : <"<<tester.inputfilename<<">\n";

    for(index = 0; index < results.success.size(); ++index)
    {
        cout<<"\nPosition "<<index<<" ";
        if(results.success[index]) cout<<" PASS ";
        else
        {
            cout<<" FAIL ";
            if(testdata[index].type==TYPEBM) cout<<" bm ";
            else if(testdata[index].type==TYPEAM) cout<<" am ";
            for(index2 = 0; index2 < testdata[index].bestmove.size(); ++index2)
            {
             cout<<testdata[index].bestmove[index2]<<" ";
            }
            cout<<" ourmove "<<results.ourmove[index];
            cout<<" ("<<printmove(results.ourintmove[index])<<") ";
        }
        cout<<testdata[index].fen<<" ";
    }

    cout<<"\n Total "<<results.solved<<" solved from "<<results.notsolved+results.solved;
    cout<<" "<<percent((int)results.solved, (int)results.success.size())<<"%";

	tester.ofile<<"\n Total "<<results.solved<<" solved from "<<results.notsolved+results.solved;
    tester.ofile<<" "<<percent((int)results.solved, (int)results.success.size())<<"%";
	tester.ofile<<"\n Time "<<(results.totaltime/1000)<<"s, Nodes "<<results.totalnodes;

    for(index = 0; index < results.success.size(); ++index)
    {
        tester.ofile<<"\nPosition "<<index<<" ";
        if(results.success[index]) tester.ofile<<" PASS ";
        else
        {
            tester.ofile<<" FAIL ";
            if(testdata[index].type==TYPEBM) tester.ofile<<" bm ";
            else if(testdata[index].type==TYPEAM) tester.ofile<<" am ";
            for(index2 = 0; index2 < testdata[index].bestmove.size(); ++index2)
            {
             tester.ofile<<testdata[index].bestmove[index2]<<" ";
            }
            tester.ofile<<" ourmove "<<results.ourmove[index];
            tester.ofile<<" ("<<printmove(results.ourintmove[index])<<") ";
        }
        tester.ofile<<testdata[index].fen<<" ";
    }



    //for excel sheet transfer

    tester.ofile<<"\n EXCEL LIST : \n";
    for(index = 0; index < results.success.size(); ++index)
    {
        if(results.success[index]) tester.ofile<<"PASS\n";
        else tester.ofile<<"FAIL\n";
    }


    tester.ofile.close();

    if(islog())
    {
         logger.file<<"\n\n-----------------> EPD Test Complete <-------------------";
         logger.file.flush();
    }

    cout<<endl;
}


