#ifndef MAKE_H
#define MAKE_H

#include "board.h"
#include "material.h"
#include "movelist.h"
#include "move.h"
#include "history.h"
//#include "searcher.h"

bool makemove(uint &move);
void takemove();
void makenullmove();
void takenullmove();

#endif

