#ifndef BOOK_H
#define BOOK_H

#include <vector>
#include <list>
#include <string>
#include <fstream>

#include "move.h"
#include "defs.h"
#include "board.h"
#include "material.h"
#include "movelist.h"
#include "history.h"
#include "init.h"


#ifdef _MSC_VER
  typedef signed __int64 sint64;
  typedef unsigned __int64 uint64;
#else
  typedef signed long long int sint64;
  typedef unsigned long long int uint64;
#endif


typedef signed char sint8;
typedef unsigned char uint8;

typedef signed short sint16;
typedef unsigned short uint16;

typedef signed int sint32;
typedef unsigned int uint32;

struct entry_t {
  uint64 key;
  uint16 move;
  uint16 count;
  uint16 weight;
  uint16 sum;
};

using namespace std;


class cBookread {

    private:
    string bookname;
    FILE *bookFile;
    bool usebook;
    int booksize;
	vector<entry_t> booklines;

    int read_entry(entry_t &entry, int n);
    int find_key(uint64 key);
	int read_entry_vec(entry_t &entry, int n);
    int find_key_vec(uint64 key);
    uint64 getpolykey();

     cBookread( const cBookread & );
         cBookread &operator = ( const cBookread & );


    public:

    cBookread();
    bool bookmove(uint &move, uint side);
    void setbookuse(bool use) {usebook = use;}
    bool getbookuse() {return usebook;}
    void setbookname(string name) {bookname = name;}
	void read_into_store();

};

extern cBookread bookread;


#endif

