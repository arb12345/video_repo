#ifndef BOARD_H
#define BOARD_H

#include "piecedefs.h"
#include "squares.h"
#include "defs.h"
#include "keys.h"

using namespace std;


const int WCAKS = 8;
const int WCAQS = 4;
const int BCAKS = 2;
const int BCAQS = 1;

struct sBoard {

    uint board[BRDSQ];
    uint side;
    uint fifty;
    uint castleperm;
    uint enpas;
    u64  key;
    u64  pawnkey;
    uint ply;
    uint frccasq[6]; //FRC lookup table for castling [WK,WKR,WQR,BK,BKR,BQR]
};

extern sBoard brd[1];

extern void printboard();
extern void logboard();
extern void clearboard();
extern bool position_check();
extern bool checkkey();
extern u64 genhashkey();
extern u64 genpawnkey();


inline void updatecastle(const uint &bit) { brd->castleperm &= bit; }

#define PLYNOW  (brd->ply)
#define SIDENOW (brd->side)
#define BRDPCE(sq) (brd->board[(sq)])
#define CAPERM (brd->castleperm)
#define BITCASTLE(s) ((brd->castleperm&=(castlebits[(s)])))
#define FIFTY (brd->fifty)
#define BRDKEY (brd->key)
#define ENPAS (brd->enpas)
#define PAWNKEY (brd->pawnkey)
#define CHANGESIDE (((brd->side)^=1))
#define SETPCE(pce,sq) ((brd->board[(sq)]=(pce)))
#define SETSIDE(s) ((brd->side=(s)))
#define SETCASTLE(s) ((brd->castleperm|=(s)))
#define SETENPAS(s) ((brd->enpas=(s)))
#define SETSIDE(s) ((brd->side=(s)))
#define SETFIFTY(s) ((brd->fifty=(s)))
#define SETKEY(s) ((brd->key=(s)))
#define SETPKEY(s) ((brd->pawnkey=(s)))
#define SETPLY(p) (brd->ply=(p))
#define INCRPLY (brd->ply++)
#define DECRPLY (brd->ply--)
inline void hashside() { brd->key ^= side_hash_keys[brd->side]; }
inline void hashenpas() { brd->key ^= enpas_hash_keys[brd->enpas]; }
inline void hashcastle() { brd->key ^= castle_hash_keys[brd->castleperm]; }
inline void hashpiece(const uint &p, const uint &sq) { brd->key ^= piece_hash_keys[p][sq]; }
inline void hashpawn(const uint &p, const uint &sq) { brd->pawnkey ^= piece_hash_keys[p][sq]; }

inline bool sideok(const uint s) {return (s==cW||s==cB);}
inline bool fiftyok(const uint f) {return (f>=0 && f<=100);}
inline bool castleok(const uint c) {return (c>=0 && c<= 15);}
inline bool enpasok(const uint s) {return (onbrd(s)==true || s==NOSQ);}

#endif
