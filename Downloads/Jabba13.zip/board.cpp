#include <iostream>
#include <iomanip>
#include <string>
#include "board.h"
#include "defs.h"
#include "bits.h"
#include "material.h"
#include "piecedefs.h"
#include "keys.h"
#include "log.h"

using namespace std;

sBoard brd[1];

void clearboard()
{
    for(uint i = 0; i < BRDSQ; ++i)
    {
        brd->board[i] = pE;
    }
    brd->side = cN;
    brd->enpas = NOSQ;
    brd->fifty = 0;
    brd->castleperm = 0;
}

void printboard()
{
    uint f = 0;
    int  r = 0;
    uint sq;

    cout<<endl;

    for( r = 7; r>=0; r--)
    {
        for( f = 0; f<=7; ++f)
        {
           sq = fr2sq(f,r);
           ASS(onbrd(sq));
           cout<<setw(3)<<piecechar(brd->board[sq]);
        }
        cout<<endl;
    }
    cout<<endl<<"castle ";

    if(brd->castleperm & WCAKS) cout<<"K"; else cout<<"-";
    if(brd->castleperm & WCAQS) cout<<"Q"; else cout<<"-";
    if(brd->castleperm & BCAKS) cout<<"k"; else cout<<"-";
    if(brd->castleperm & BCAQS) cout<<"q"; else cout<<"-";
    cout<<endl;

    cout<<"\n key "<<brd->key;
    cout<<"\n pawnkey "<<brd->pawnkey;
    cout<<"\n side "<<brd->side;
    cout<<" enpas "<<brd->enpas;
	if(onbrd(brd->enpas)) cout<<"("<<printsquare(brd->enpas)<<")";
    cout<<" fifty "<<brd->fifty;
    cout<<" ply "<<brd->ply;
}


void logboard()
{
    if(islog()==false) return;
    uint f = 0;
    int  r = 0;
    uint sq;

    logger.file<<endl;

    for( r = 7; r>=0; r--)
    {
        for( f = 0; f<=7; ++f)
        {
           sq = fr2sq(f,r);
           ASS(onbrd(sq));
           logger.file<<setw(3)<<piecechar(brd->board[sq]);
        }
        logger.file<<endl;
    }
    logger.file<<endl<<"castle ";

    if(brd->castleperm & WCAKS) logger.file<<"K"; else logger.file<<"-";
    if(brd->castleperm & WCAQS) logger.file<<"Q"; else logger.file<<"-";
    if(brd->castleperm & BCAKS) logger.file<<"k"; else logger.file<<"-";
    if(brd->castleperm & BCAQS) logger.file<<"q"; else logger.file<<"-";
    logger.file<<endl;

    logger.file<<"\n key "<<brd->key;
    logger.file<<"\n pawnkey "<<brd->pawnkey;
    logger.file<<"\n side "<<brd->side;
    logger.file<<" enpas "<<brd->enpas;
	if(ENPAS) logger.file<<"("<<printsquare(brd->enpas)<<")";
    logger.file<<" fifty "<<brd->fifty;
    logger.file<<" ply "<<brd->ply;
    logger.file<<endl;
}



bool position_check()
{
	//hash keys
	if(!checkkey())
	{
		logger.file<<"\n hash key error "; return false;
	}

	//side
	if(SIDENOW != cW && SIDENOW != cB)
	{
		logger.file<<"\n side error "; return false;
	}
/*
	//side not moving in check?
	if(isattacked(p->p2sq[p->side^1][1], p->side))
	{
		cout<<"\n king capture error "; return false;
	}
*/
	//material
	uint sq, index;
	uint pcecol;
	uint pce;
	uint btot = 0, wtot = 0;

	int wm = 0,bm = 0;
	uint num[numpieces] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
	uint wp = 0, bp = 0;
	uint wmaj = 0, bmaj = 0;
	uint wmin = 0, bmin = 0;
	uint wbig = 0, bbig = 0;
	uint wksq = 0;
	uint bksq = 0;

	u64 wPbb = 0;
	u64 bPbb = 0;
    for (index = 0; index < 64; ++index)
    {
         sq = SQFROM64(index);
         ASS(onbrd(sq));
         pce = BRDPCE(sq);

         if(pce == pE) continue;

         pcecol = PCECOL(pce);

         ASS(colourgood(pcecol));
         ASS(piecegood(pce));

         switch(pce)
			 {
			 case pwP:wtot++; wm += PCEVAL(pwP);num[pwP]++;wp++; setbit(sq, wPbb);break;
			 case pwN:wtot++; wm += PCEVAL(pwN);num[pwN]++;wmin++;wbig++;break;
			 case pwB:wtot++; wm += PCEVAL(pwB);num[pwB]++;wmin++;wbig++;break;
			 case pwR:wtot++; wm += PCEVAL(pwR);num[pwR]++;wmaj++;wbig++;break;
			 case pwQ:wtot++; wm += PCEVAL(pwQ);num[pwQ]++;wmaj++;wbig++;break;
			 case pwK:wtot++; num[pwK]++; wksq = sq;break;
			 case pbP:btot++; bm += PCEVAL(pbP);num[pbP]++;bp++;setbit(sq, bPbb);break;
			 case pbN:btot++; bm += PCEVAL(pbN);num[pbN]++;bmin++;bbig++;break;
			 case pbB:btot++; bm += PCEVAL(pbB);num[pbB]++;bmin++;bbig++;break;
			 case pbR:btot++; bm += PCEVAL(pbR);num[pbR]++;bmaj++;bbig++;break;
			 case pbQ:btot++; bm += PCEVAL(pbQ);num[pbQ]++;bmaj++;bbig++;break;
			 case pbK:btot++; num[pbK]++; bksq = sq;break;
			 default: logger.file<<"\n piece not known"; return false; break;
			 };
    }
 	//now check material counts and king position
	if(BRDPCE(wksq) != pwK) {logger.file<<"\n wking false "; return false;}
	if(BRDPCE(bksq) != pbK) {logger.file<<"\n bking false "; return false;}
	if(num[pbK]!=1 || num[pwK]!=1){logger.file<<"\n king count false "; return false;}
	if(MATERIAL(cW) != wm) {logger.file<<"\n wmaterial false "; return false;}
	if(MATERIAL(cB)  != bm){logger.file<<"\n bmaterial false "; return false;}
    if(PCENUM(pwP) != num[pwP]) {logger.file<<"\n wPnum false "; return false;}
	if(PCENUM(pwN)  != num[pwN]) {logger.file<<"\n wNnum false "; return false;}
	if(PCENUM(pwB)  != num[pwB]) {logger.file<<"\n wBnum false "; return false;}
	if(PCENUM(pwR)  != num[pwR]) {logger.file<<"\n wRnum false "; return false;}
	if(PCENUM(pwQ) != num[pwQ]) {logger.file<<"\n wQnum false "; return false;}
	if(PCENUM(pbP) != num[pbP]) {logger.file<<"\n bPnum false "; return false;}
	if(PCENUM(pbN)  != num[pbN]) {logger.file<<"\n bNnum false "; return false;}
	if(PCENUM(pbB) != num[pbB]) {logger.file<<"\n bBnum false "; return false;}
	if(PCENUM(pbR) != num[pbR]) {logger.file<<"\n bRnum false "; return false;}
	if(PCENUM(pbQ) != num[pbQ]) {logger.file<<"\n bQnum false "; return false;}
	if(wPbb != P_BB(cW))
	{logger.file<<"\n wPboard false "; return false;}
	if(bPbb != P_BB(cB))
	{logger.file<<"\n bPboard false "; return false;}

	if(MAJORS(cW) != wmaj) {logger.file<<"\n wmaj false "; return false;}
	if(MAJORS(cB) != bmaj) {logger.file<<"\n bmaj false "; return false;}
	if(MINORS(cW) != wmin) {logger.file<<"\n wmin false "; return false;}
	if(MINORS(cB) != bmin) {logger.file<<"\n bmin false "; return false;}
	if(BIG(cW) != wbig) {logger.file<<"\n wbig false "; return false;}
	if(BIG(cB) != bbig) {logger.file<<"\n bbig false "; return false;}

	//BB check
	u64 pieceBB;
	for(pce=pwP; pce <= pbK; ++pce)
	{
	 pieceBB = GET_BB(pce);
	 if(popCount(pieceBB) != num[pce])  {logger.file<<piecechars[pce]<<" bitboard piece num error "; return false;}

	 while(pieceBB)
	 {
	     sq = POP64(pieceBB); ASS(onbrd(sq));
	  if(BRDPCE(sq)!=pce)
	  {
	      logger.file<<"\n sq "<<printsquare(sq);
	      logger.file<<" piece "<<pce<<" board false "; return false;
      }
     }


	pieceBB = ALL_BB;
	while(pieceBB)
	{ sq = POP64(pieceBB); ASS(onbrd(sq)); if(BRDPCE(sq)==pE) {logger.file<<" ALLBoradboard false "; return false;}	}
	}


   return true;
}

u64 genhashkey()
{
    u64 newkey = 0;
    uint i;
    uint sq;
    uint piece;

    for(i = 0; i < 64; ++i)
    {
        sq=SQFROM64(i);
        piece = BRDPCE(sq);
        ASS(piecegood(piece)||piece==pE);
        ASS(onbrd(sq));
        if(piece != pE) newkey ^= piece_hash_keys[piece][sq];
    }

    ASS(castleok(CAPERM));
    ASS(sideok(SIDENOW));
    ASS(enpasok(ENPAS));

    newkey ^= castle_hash_keys[CAPERM];
    newkey ^= side_hash_keys[SIDENOW];
    newkey ^= enpas_hash_keys[ENPAS];

    return newkey;
}

bool checkkey()
{
    u64 check = genhashkey();
    if(check!=BRDKEY)
    {
        cout<<"\n real key = "<<check;
        cout<<" key fail !!";
        return false;
    }
    check = genpawnkey();
    if(check!=PAWNKEY)
    {
        cout<<"\n real pawn key = "<<check;
        cout<<" pawn key fail !!";
        return false;
    }
    return true;
}

u64 genpawnkey()
{
    u64 newkey = 0;
    uint i;
    uint sq;
    uint piece;

    for(i = 0; i < 64; ++i)
    {
        sq=SQFROM64(i);
        piece = BRDPCE(sq);
        ASS(piecegood(piece)||piece==pE);
        ASS(onbrd(sq));
        if(piece == pwP || piece == pbP)
        newkey ^= piece_hash_keys[piece][sq];
    }

    return newkey;
}



