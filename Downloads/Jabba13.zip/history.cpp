#include <iostream>
#include <string>
#include "history.h"
#include "move.h"
#include "defs.h"



using namespace std;

sHistory his[1];

void clearhistory()
{
   uint i;
   for(i = 0; i < maxgamelength; ++i)
   {
         his->hisarray[i].captured = 0;
         his->hisarray[i].castle = 0;
         his->hisarray[i].enpas = 0;
         his->hisarray[i].fifty = 0;
         his->hisarray[i].move = 0;
         his->hisarray[i].key = 0;
         his->hisarray[i].pawnkey = 0;
   }
   his->gamemoves = 0;
}

void printallhistory()
{
     uint i;
     cout<<"\n game line : ";
     for(i = 0; i < GAMEMOVES; ++i)
     {
           cout<<printmove(HISMOVE(i));
           cout<<" ";
     }
     cout<<endl;
}


void logallhistory()
{
     uint i;
     logger.file<<"\n game line : ";
     for(i = 0; i < GAMEMOVES; ++i)
     {
           logger.file<<printmove(HISMOVE(i));
           logger.file<<" ";
     }
     logger.file<<endl;
}


void printonehistory(const uint index)
{
     cout<<"\n->"<<HISMOVE(index);
     cout<<endl;
}

uint lastmovemade()
{
    if(GAMEMOVES>0)
    return HISMOVE(GAMEMOVES-1);
    else
    return NULLMOVE|(NULLMOVE<<1);
}


