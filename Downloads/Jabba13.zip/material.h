#ifndef MATERIAL_H
#define MATERIAL_H

#include "piecedefs.h"
#include "squares.h"
#include "bits.h"

#define VALUE(x) (piecevals[(x)])


const uint PAWNBASE = 100;
const uint PAWN10TH = 10;
const uint vE = 0;
const uint vP = 100;
const uint vN = 320;
const uint vB = 320;
const uint vR = 500;
const uint vQ = 970;
const uint vK = 50000;

const uint ENDMAT = 4*vR + vB + vN + 4*vP;

const uint piecevals[numpieces] = {vE, vP, vP, vN, vN, vB, vB, vR, vR, vQ, vQ, vK, vK};

static const int PawnPhase   = 0;
static const int KnightPhase = 3;
static const int BishopPhase = 3;
static const int RookPhase   = 5;
static const int QueenPhase  = 9;
static const int TotalPhase = PawnPhase * 16 + KnightPhase * 4 + BishopPhase * 4 + RookPhase * 4 + QueenPhase * 2;

extern int psqt[numpieces][2][BRDSQ];

struct sMaterial {

//piece list
uint pcelist[numpieces][maxpiecenum];
uint pcecount[numpieces];

//counters (pawns counted above in pcecount)
uint majors[numcolours];
uint minors[numcolours];
uint bigpieces[numcolours];

uint kingsq[numcolours];

int material[numcolours];
int psqvalope[numcolours];
int psqvalend[numcolours];

//psq tables
int psqt[numpieces][2][BRDSQ];

//piece BBoards
u64 pceBB[numpieces];
u64 allBB;
u64 colBB[numcolours];//white /black BB
};

extern sMaterial mat[1];

extern void init_psqt();
extern void setpiecelists(const uint *board);
extern void clearpcelists();
extern void printmaterial();
extern void printBB();
extern void logBB();

#define PCENUM(pce)   (mat->pcecount[(pce)])
#define MAJORS(s) (mat->majors[(s)])
#define MINORS(s) (mat->minors[(s)])
#define BIG(s) (mat->bigpieces[(s)])
#define MATERIAL(s) (mat->material[(s)])
#define TOTMAT (mat->material[(cW)]-mat->material[(cB)])
#define KINGSQ(s) (mat->kingsq[(s)])
#define PSQOPE(s) (mat->psqvalope[(s)])
#define PSQEND(s) (mat->psqvalend[(s)])
#define TOTPSQOPE (mat->psqvalope[(cW)]-mat->psqvalope[(cB)])
#define TOTPSQEND (mat->psqvalend[(cW)]-mat->psqvalend[(cB)])
#define PSQVAL(pc,ph,sq) (psqt[(pc)][(ph)][(sq)])
#define PCEVAL(pce) (piecevals[(pce)])

#define N_BB(s) (mat->pceBB[(knights[(s)])])
#define P_BB(s) (mat->pceBB[(pawns[(s)])])
#define B_BB(s) (mat->pceBB[(bishops[(s)])])
#define R_BB(s) (mat->pceBB[(rooks[(s)])])
#define Q_BB(s) (mat->pceBB[(queens[(s)])])
#define K_BB(s) (mat->pceBB[(kings[(s)])])
#define ALL_BB   (mat->allBB)
#define GET_BB(p) (mat->pceBB[(p)])


//piece list add / remove / edit
inline void addpiece(const uint &pce, const uint &sq)
{
   ASS(piecegood(pce));
   ASS(PCENUM(pce)<maxpiecenum);
   ASS(onbrd(sq));

   mat->pcecount[pce]++;
   mat->material[PCECOL(pce)]+=PCEVAL(pce);

   if(ISBIG(pce)) mat->bigpieces[PCECOL(pce)]++;
   if(ISMINOR(pce)) mat->minors[PCECOL(pce)]++;
   if(ISMAJOR(pce)) mat->majors[PCECOL(pce)]++;

   setbit(sq,mat->pceBB[pce]);
   setbit(sq,mat->allBB);
   setbit(sq,mat->colBB[PCECOL(pce)]);
}

inline void movepiece(const uint &pce, const uint &sqfrom, const uint &sqto)
{
   ASS(piecegood(pce));
   ASS(onbrd(sqfrom));
   ASS(onbrd(sqto));

   movebit(sqfrom,sqto,mat->pceBB[pce]);
   movebit(sqfrom,sqto,mat->allBB);
   movebit(sqfrom,sqto,mat->colBB[PCECOL(pce)]);
}

inline void removepiece(const uint &pce, const uint &sq)
{
   ASS(piecegood(pce));
   ASS(PCENUM(pce)<maxpiecenum);
   ASS(onbrd(sq));

   mat->pcecount[pce]--;
   mat->material[PCECOL(pce)]-=PCEVAL(pce);

   if(ISBIG(pce)) mat->bigpieces[PCECOL(pce)]--;
   if(ISMINOR(pce)) mat->minors[PCECOL(pce)]--;
   if(ISMAJOR(pce)) mat->majors[PCECOL(pce)]--;

   clearbit(sq,mat->pceBB[pce]);
   clearbit(sq,mat->allBB);
   clearbit(sq,mat->colBB[PCECOL(pce)]);
}

inline void movepsqt(const uint pce, const uint from, const uint to)
{
     ASS(onbrd(from));
     ASS(onbrd(to));
     ASS(piecegood(pce));

     uint colour = PCECOL(pce);

     ASS(colour==cW || colour==cB);
     mat->psqvalope[colour] += (psqt[pce][OPE][to]-psqt[pce][OPE][from]);
     mat->psqvalend[colour] += (psqt[pce][END][to]-psqt[pce][END][from]);
}

inline void addpsqt(const uint pce, const uint sq)
{
     ASS(onbrd(sq));
     ASS(piecegood(pce));

     uint colour = PCECOL(pce);

     ASS(colour==cW || colour==cB);
     mat->psqvalope[colour] += psqt[pce][OPE][sq];
     mat->psqvalend[colour] += psqt[pce][END][sq];;
}

inline void removepsqt(const uint pce, const uint sq)
{
     ASS(onbrd(sq));
     ASS(piecegood(pce));

     uint colour = PCECOL(pce);

     ASS(colour==cW || colour==cB);
     mat->psqvalope[colour] -= psqt[pce][OPE][sq];
     mat->psqvalend[colour] -= psqt[pce][END][sq];
}

inline bool drawmaterial()
{
    if(mat->pcecount[pwP] || mat->pcecount[pbP] ) {return false;}
    if(mat->pcecount[pwR]  || mat->pcecount[pwQ]  || mat->pcecount[pbR]  || mat->pcecount[pbQ] ) {return false;}
    if(mat->pcecount[pwB]  > 1 || mat->pcecount[pbB]  > 1) {return false;}
    if(mat->pcecount[pwN]  && mat->pcecount[pwB] ) {return false;}
    if(mat->pcecount[pbN]  && mat->pcecount[pbB] ) {return false;}
    return true;
}


#endif

