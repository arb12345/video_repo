#ifndef BITS_H
#define BITS_H

#include "defs.h"
#include "squares.h"
#include "piecedefs.h"

#define FILEOPEN(occ, f) ( ( (file_masks[(f)]) & (occ) ) == 0)
#define RANKOCC(occ, r) ( ( (rank_masks[(r)]) & (occ) ) != 0)


//7k/RR6/8/8/8/8/rr6/7K w - - 0 1



extern u64 setter[64];
extern u64 clearer[64];
extern u64 isfilenorth[64];//is a bit set north of our bit... e.g on E4, is something on E5, E6, E7, E8
extern u64 isfilesouth[64];
extern u64 isisolated[64];
extern u64 whitepassed[64];
extern u64 blackpassed[64];

extern u64 whitepawnconnect[64];
extern u64 blackpawnconnect[64];

extern u64 whitebackward[64];
extern u64 blackbackward[64];

extern u64 wknightsup[64];
extern u64 bknightsup[64];
extern u64 rank_masks[8];
extern u64 file_masks[8];

extern u64 pawn_att[numcolours][64];
extern u64 king_moves[64];
extern u64 king_circle[64]; //the king sq and surrounding squares
extern u64 knight_moves[64];

extern void printbitboard(const u64 b);
extern void logbitboard(const u64 bitbrd);
extern void init_bitboards();
extern int POP(u64 &b);
extern int MSB(u64 b);
extern int LSB(u64 b);

inline uint POP64(u64 &b)
{
    return (uint)SQFROM64(POP(b));
}

inline uint MSB64(u64 b)
{
    return (uint)SQFROM64(MSB(b));
}

inline uint LSB64(u64 b)
{
    return (uint)SQFROM64(LSB(b));
}

inline void setbit(uint sq, u64 &bitbrd)
{
	ASS(onbrd(sq));
	ASS(SQTO64(sq)>=0&&SQTO64(sq)<64);
	bitbrd |= setter[SQTO64(sq)];
}

inline void clearbit(uint sq, u64 &bitbrd)
{
	ASS(onbrd(sq));
	ASS(SQTO64(sq)>=0&&SQTO64(sq)<64);
	bitbrd &= clearer[SQTO64(sq)];
}


inline void movebit(uint from, uint to, u64 &bitbrd)
{
	ASS(onbrd(from));
	ASS(onbrd(to));
	ASS(SQTO64(from)>=0&&SQTO64(from)<64);
	ASS(SQTO64(to)>=0&&SQTO64(to)<64);
	bitbrd &= clearer[SQTO64(from)];
	bitbrd |= setter[SQTO64(to)];
}

inline int popCount (u64 x) {
   int count = 0;
   while (x) {
       count++;
       x &= x - 1;
   }
   return count;
}

#endif
