#ifndef INIT_H
#define INIT_H

#include <string>

using namespace std;

struct sMainOpt {
	string inifilename;
	bool logon;
	bool bookon;
	string bookfile;
	int tablesize;
};

extern sMainOpt mainopt;

extern void init_all();

#endif

