#include <iostream>
#include <windows.h>
#include <math.h>


#include "init.h"
#include "board.h"
#include "material.h"
#include "fen.h"
#include "movegen.h"
#include "move.h"
#include "make.h"
#include "perft.h"
#include "clock.h"
#include "searcher.h"
#include "utils.h"
#include "engine.h"
#include "testers.h"
#include "log.h"
#include "book.h"
#include "stats.h"
#include "tuner.h"
#include "sts.h"

using namespace std;

void drivests(const vector<string> &args)
{
	cSTStuner ststester;
	string sw;
    uint size = args.size();
	bool setfilein = false;
	bool setfileout = false;
    for(uint i = 0; i < size; ++i)
    {
        sw = args[i];
        if (sw=="-i") { ststester.SetIniFileName(args[i+1]); setfilein = true; }
		else if (sw=="-o") { ststester.SetFileOutName(args[i+1]); setfileout = true; }
	}

	if(!setfilein) { cout<<"\n No file in name set";return;}
	if(!setfileout) { cout<<"\n No file out name set";return;}

    ststester.STStest();
}



void drivetuner(const vector<string> &args)
{
    cTuner tuningobj;
    string sw;
    uint size = args.size();
    int what = 2;//default to nothingd 
    for(uint i = 0; i < size; ++i)
    {
        sw = args[i];
       // cout<<"\n arg "<<args[i];
        if (sw=="-eval")what = 0;
        else if (sw=="-makeepd") what=1;
        else if (sw=="-i") { tuningobj.SetFileInName(args[i+1]); }
        else if (sw=="-o") tuningobj.SetFileOutName(args[i+1]);
        else if (sw=="-d") tuningobj.SetPly(atoi(args[i+1].c_str()));
    }

    tuningobj.start(what);
}

void drivetester(const vector<string> &args)
{
    string sw;
    uint size = args.size();

    tester.depthset = 0;//default time limited ie depth 0
    tester.timeperposition = 0;
    tree->opt->special = true;
	int mode=0;

    for(uint i = 0; i < size; ++i)
    {
        sw = args[i];
        if (sw=="-t") tester.timeperposition = atoi(args[i+1].c_str())*1000;
        else if (sw=="-i") tester.inputfilename = args[i+1];
        else if (sw=="-o") tester.outputfilename = args[i+1];
        else if (sw=="-d") tester.depthset = atoi(args[i+1].c_str());
		else if(sw=="-epd") mode = 1;
		else if(sw=="-bench") mode = 2;
		else if(sw=="-mirror") mode = 3;
        else if (sw=="-margf1") tree->opt->f1marg = atoi(args[i+1].c_str());
		else if(sw=="-fut1")
		{
			if(args[i+1]=="true") tree->opt->futility1 = true;
			else if(args[i+1]=="false") tree->opt->futility1 = false;
		}
		else if (sw=="-margf2") tree->opt->f2marg = atoi(args[i+1].c_str());
		else if(sw=="-fut2")
		{
			if(args[i+1]=="true") tree->opt->futility2 = true;
			else if(args[i+1]=="false") tree->opt->futility2 = false;
		}
		else if(sw=="-iid")
		{
			if(args[i+1]=="true") tree->opt->iid = true;
			else if(args[i+1]=="false") tree->opt->iid = false;
		}
    }

    if(tester.depthset!=0 && tester.timeperposition != 0)
    {
        cout<<"\n ERROR - both time and depth set exiting";
        return;
    }
#ifdef DEBUG
            cout << "ini file set to "<<tree->opt->inifilename<<endl;
            if(islog()) logger.file << "ini file set to "<<tree->opt->inifilename<<endl;
#endif

    if(mode==3)
    evalmirror();
    else if(mode==2)
    benchmark();
    else if(mode==1)
    epdtest();
    return;
}

void drivestats(const vector<string> &args)
{
    string sw;
    uint size = args.size();
    cStatmake statter;
    bool havein = false;
    bool haveout = false;

    for(uint i = 0; i < size; ++i)
    {
        sw = args[i];
        if (sw=="-i") { statter.ifile.open(args[i+1].c_str()); havein=true;}
        else if (sw=="-o") {statter.ofile.open(args[i+1].c_str(), ios::trunc);haveout=true;}
    }

    if(!havein) { cout<<"\n no input file "; }
    if(!haveout) { cout<<"\n no output file "; }

    if(!statter.ifile && havein) { cout<<"\n could not open input file "; return;}
    if(!statter.ofile && haveout) { cout<<"\n could not open output file "; return;}

    statter.readpgn();
    if(havein) statter.ifile.close();
    if(haveout) statter.ofile.close();
}

void driveengine()
{
	char command[256];

    for (;;)
    {
        cout<<"\n "<<version<<" > ";
        cin>>command;
        cout<<endl;
        if (!strcmp(command, "uci")) {process_uci();return ;}
        if (!strcmp(command, "xboard")) {cout<<"\nxboard command recieved <"<<command<<">"<<endl;process_xboard(); return;}
        else if(!strcmp(command, "quit")) return ;
        else cout<<"\nunknown command <"<<command<<"> use 'uci' or 'xboard' or 'quit'";
    }
}

void start_driver(const int argc, char* argv[])
{
    vector<string> mainargs;
    int argument = 1;
	bool testing = false;
	bool statistics = false;
	bool tuner = false;
	bool ststesting = false;
    while (argument < argc)
    {
        mainargs.push_back(argv[argument]);
        argument++;
    }
#ifdef DEBUG
    cout<<"\n total args "<<mainargs.size()<<endl;
#endif

    for(uint i = 0; i< mainargs.size(); ++i)
    {
        if(mainargs[i]=="-epd" || mainargs[i]=="-bench" || mainargs[i]=="-mirror")
        testing=true;
        else if (mainargs[i]=="-stats")
        statistics=true;
        else if (mainargs[i]=="-tuner")
        tuner=true;
		else if (mainargs[i]=="-sts")
		ststesting = true;
    }

#ifdef DEBUG
            cout << "ini file set to "<<mainopt.inifilename<<endl;
            if(islog()) logger.file << "ini file set to "<<mainopt.inifilename<<endl;
#endif

    if(testing) drivetester(mainargs);
    else if(statistics) drivestats(mainargs);
    else if(tuner) drivetuner(mainargs);
	else if(ststesting) drivests(mainargs);
    else driveengine();
    return;

}


int main(const int argc, char* argv[])
{
	init_all();
    engopt.variant=1;
	start_driver(argc,argv);
	delete_tables();
    return 0;
}

