#ifndef STS_H
#define STS_H


#include <fstream>
#include <string.h>
#include <vector>

#include "defs.h"

using namespace std;

struct sMoveScore {
	string move;
	int score;
};

struct sPosition {
	string fen;
	vector<sMoveScore> bestmoves;
	string file_id;
	int result;
};

class cSTStuner {

private:

	cSTStuner( const cSTStuner & );
         cSTStuner &operator = ( const cSTStuner & );

	uint stsfiles;

	vector<sPosition> STSfilepositions; //stores the positions and scores from an sts file

	ofstream ofile;
    ifstream ifile;

	string FileInName;
    string FileOutName;

	string IniFileName;

	void processfile(string name);
	void score_position(sPosition &entry);

public:

	cSTStuner();
	void STStest();

    void SetIniFileName(string name) { IniFileName = name; }
    void SetFileOutName(string name) { FileOutName = name; }
    void SetFileNum(int d) { stsfiles = d; }

};

#endif
