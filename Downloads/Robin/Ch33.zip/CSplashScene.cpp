//
//  CSplashScene.cpp
//  SimpleFloppyRobin
//
//  Created by ScreenCast on 10/03/14.
//
//

#include "CSplashScene.h"
#include "CGameManager.h"
#include "Constants.h"

USING_NS_CC;

CCScene* CSplashLayer::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    CSplashLayer *layer = CSplashLayer::create();
	
    // add layer as a child to scene
    scene->addChild(layer);
	
    // return the scene
    return scene;
}

void CSplashLayer::RunGameScreen() {
	 CGameManager::Instance()->RunScene(kSceneGame);
}

bool CSplashLayer::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
		{
        return false;
		}
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
	CGameManager::Instance()->SetUpScaleFactors();
	char FileName[32];
	
	
	GETFILENAME(FileName, 32, "BG", ".png");
	CCSprite *bgSprite = CCSprite::create(FileName);
	SCALENODE_XY(bgSprite);
	bgSprite->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(bgSprite, kZindexBackground);
	
	GETFILENAME(FileName, 32, "Floor", ".png");
	CCSprite *floorSprite = CCSprite::create(FileName);
	SCALENODE_XY(floorSprite);
	floorSprite->setAnchorPoint(ccp(0,0));
	floorSprite->setPosition(ccp(0,0));
	this->addChild(floorSprite, kZindexFloor);
	
	GETFILENAME(FileName, 32, "Robin", ".png");
	CCSprite *Robin = CCSprite::create(FileName);
	SCALENODE_Y(Robin);
	Robin->setPosition(SCALEPOS(150,350));
	this->addChild(Robin, kZindexRobin);
	
	GETFILENAME(FileName, 32, "Cloud", ".png");
	CCSprite *cloud1 = CCSprite::create(FileName);
	SCALENODE_Y(cloud1);
	cloud1->setPosition(SCALEPOS(400,550));
	cloud1->setScale(kCloudScaleFast);
	this->addChild(cloud1, kZindexRobin);
	
	GETFILENAME(FileName, 32, "Cloud", ".png");
	CCSprite *cloud2 = CCSprite::create(FileName);
	SCALENODE_Y(cloud2);
	cloud2->setPosition(SCALEPOS(700,500));
	cloud2->setScale(kCloudScaleFast);
	this->addChild(cloud2, kZindexRobin);
	
	CCLabelTTF *Title = CCLabelTTF::create("SIMPLE FLOPPY ROBIN", kFontName, SCALEFONT(64));
	Title->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2 + visibleSize.height / 6));
	Title->setColor(ccRED);
	this->addChild(Title, kZindexRobin);
	
	CCLabelTTF *detail = CCLabelTTF::create("... A Tutorial App By BlueFeverSoft", kFontName, SCALEFONT(40));
	detail->setPosition(ccp(visibleSize.width / 2,
								visibleSize.height / 2 - visibleSize.height / 4 ) );
	detail->setColor(ccRED);
	this->addChild(detail, kZindexRobin);
	
	this->scheduleOnce(schedule_selector(CSplashLayer::RunGameScreen), 4.0f);
	
	return true;
}












