#include <iostream>
#include <sys/timeb.h>
#include <windows.h>
#include <io.h>
#include <fstream>

#include <signal.h>
#include <errno.h>
#include <conio.h>

#ifndef _WINDOWS_
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#endif


#include "searcher.h"
#include "log.h"
#include "utils.h"

using namespace std;


/*
  From Beowulf, from Olithink, and I confess I have no idea how it works.
*/


#include <windows.h>
#define frame 0
#include <conio.h>
int bioskey(void)
{
    static int      init = 0,
                    pipe;
    static HANDLE   inh;
    DWORD           dw;

    if (!init) {
        init = 1;
        inh = GetStdHandle(STD_INPUT_HANDLE);
        pipe = !GetConsoleMode(inh, &dw);
        if (!pipe) {
            SetConsoleMode(inh, dw & ~(ENABLE_MOUSE_INPUT | ENABLE_WINDOW_INPUT));
            FlushConsoleInputBuffer(inh);
        }
    }
    if (pipe) {
        if (!PeekNamedPipe(inh, NULL, 0, NULL, &dw, NULL))
            return 1;
        return dw;
    } else {
        GetNumberOfConsoleInputEvents(inh, &dw);
        return dw <= 1 ? 0 : dw;
    }
}

/*
checkinput() is taken from Beowulf
Again, I'm too clear on the workings of this.
*/
int checkinput()
{
  int             datain;
  datain = bioskey();//see if we have had input

  ASS(tree->opt->special==true||tree->opt->special==false);

  //we have input, so process it and see what the command is - if it's ponderhit, continue searching
  if (datain && !tree->opt->special)
  {
      cin.get(tree->data->commandin,0xffff);
      //cout<<"***************search interrupted with "<<data->commandin<<endl;
      tree->status->interrupted = true;

      if(islog())
      {
       logger.file<<"search interrupted with "<<tree->data->commandin<<endl;
      }

      if(findsubstr("ponderhit", tree->data->commandin, datain))
      {
          tree->status->mode = smPONDERHIT;
		  timer->pondertime = (TIMEELAPSED);
          startsearchtimer(SIDENOW, tree->status->mode, true);
          return 0;
      }
      return 1;
  }
  return 0;
}


int checkinputtuning()
{
  int             datain;
  datain = bioskey();//see if we have had input

  ASS(tree->opt->special==true||tree->opt->special==false);

  //we have input, so process it and see what the command is - if it's ponderhit, continue searching
  if (datain)
  {
      cin.get(tree->data->commandin,0xffff);
      if(findsubstr("tunestop", tree->data->commandin, datain))
      {
         return 1;
      }
  }
  return 0;
}

