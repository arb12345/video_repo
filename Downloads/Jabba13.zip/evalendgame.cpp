#include <iostream>
#include <string>

#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "board.h"
#include "bits.h"


using namespace std;

/*
This file has the functions that help Jabba evaluate endings for specific material
situations.

I took all of this knowledge from a great book "Silman's Complete Endgame Course"
*/

/* encourage pawn adavnce to a win */
const int wonending[2][8] = {
    { 0, vP/2, vP, 2*vP, 3*vP, 4*vP, 5*vP, 5*vP },
    { vP*5, vP*5, vP*4, vP*3, vP*2, vP, vP/2, 0 }
};

void KP_v_K()
{
	uint pawnsq = LSB64(P_BB(cW));
	uint pawnf =  files[pawnsq];
	uint pawnr = ranks[pawnsq];

	uint wks =  KINGSQ(cW);
	uint wkr =  ranks[wks];
	uint wkf =  files[wks];

    uint bks =  KINGSQ(cB);
	uint bkr =  ranks[bks];
	uint bkf =  files[bks];

	uint side = SIDENOW;

	//rook pawn draw
	if(pawnf==FILEA)
	{
		if(bkf==FILEA && bkr > pawnr) scorer->drawflag = true;
		if(wkf==FILEA && wkr > pawnr)
		{
			if(bks == wks+E+E) scorer->drawflag = true;
		}
	}
	else if(pawnf==FILEH)
	{
		if(bkf==FILEH && bkr > pawnr) scorer->drawflag = true;
		if(wkf==FILEH && wkr > pawnr)
		{
			if(bks == wks+W+W) scorer->drawflag = true;
		}
	}
	else if (bks == pawnsq+N)
	{
      if (pawnr < RANK7) scorer->drawflag = true;
      else
	  {
         if (side==cW)
		 {
            if (wks == pawnsq+SE || wks == pawnsq+SW) scorer->drawflag = true;
		 }
		 else
		 {
			if (wks != pawnsq-SE && wks != pawnsq-SW) scorer->drawflag = true;
         }
      }
   }
   else if (bks == pawnsq+N+N)
   {
      if (pawnr < RANK6)
	  {
         scorer->drawflag = true;
      }
	  else
	  {
         if (side==cW)
		 {
            if (wks != pawnsq+W && wks != pawnsq+E) scorer->drawflag = true;
         }
		 else
		 {
           scorer->drawflag = true;
         }
      }
   }
   else if (wks == pawnsq+W || wks == pawnsq+E)
   {
      if (bks == wks+N+N && side == cW)
	  {
         scorer->drawflag = true;
      }
   }
   else if (wks == pawnsq+NW || wks == pawnsq+N || wks == pawnsq+NE)
   {
      if (pawnr < RANK5)
	  {
         if (bks == wks+N+N && side==cW)
		 {
            scorer->drawflag = true;
         }
      }
   }
   if(!scorer->drawflag) scorer->bal[cW][END]+= wonending[cW][pawnr];
}


void K_v_KP()
{
	uint pawnsq = LSB64(P_BB(cB));
	uint pawnf =  files[pawnsq];
	uint pawnr = ranks[pawnsq];

	uint wks =  KINGSQ(cW);
	uint wkr =  ranks[wks];
	uint wkf =  files[wks];

    uint bks =  KINGSQ(cB);
	uint bkr =  ranks[bks];
	uint bkf =  files[bks];

	uint side = SIDENOW;

	//rook pawn draw
	if(pawnf==FILEA)
	{
		if(wkf==FILEA && wkr < pawnr) scorer->drawflag = true;
		if(bkf==FILEA && bkr < pawnr)
		{
			if(wks == bks+E+E) scorer->drawflag = true;
		}
	}
	else if(pawnf==FILEH)
	{
		if(wkf==FILEH && wkr < pawnr) scorer->drawflag = true;
		if(bkf==FILEH && bkr < pawnr)
		{
			if(wks == bks+W+W) scorer->drawflag = true;
		}
	}
	else if (wks == pawnsq+S)
	{
      if (pawnr > RANK2) scorer->drawflag = true;
      else
	  {
         if (side==cB)
		 {
            if (bks == pawnsq+NE || bks == pawnsq+NW) scorer->drawflag = true;
		 }
		 else
		 {
			if (bks != pawnsq+NE && bks != pawnsq+NW) scorer->drawflag = true;
         }
      }
   }
   else if (wks == pawnsq+S+S)
   {
      if (pawnr > RANK3)
	  {
         scorer->drawflag = true;
      }
	  else
	  {
         if (side==cB)
		 {
            if (bks != pawnsq+W && bks != pawnsq+E) scorer->drawflag = true;
         }
		 else
		 {
            scorer->drawflag = true;
         }
      }
   }
   else if (bks == pawnsq+W || bks == pawnsq+E)
   {
      if (bks == wks+S+S && side == cB)
	  {
         scorer->drawflag = true;
      }
   }
   else if (bks == pawnsq+SW || bks == pawnsq+S || bks == pawnsq+SE)
   {
      if (pawnr > RANK4)
	  {
         if (wks == bks+S+S && side==cB)
		 {
            scorer->drawflag = true;
         }
      }
   }

   if(!scorer->drawflag) scorer->bal[cB][END]+= wonending[cB][pawnr];
}

void KBP_v_K()
{
	uint pawnsq = LSB64(P_BB(cW));
	uint pawnf =  files[pawnsq];
	uint pawnr = ranks[pawnsq];

    uint bks =  KINGSQ(cB);
	uint bkr =  ranks[bks];

	uint promote = promsq[cW][pawnf];
	uint bishsq = LSB64(P_BB(cW));

	//rook pawn draw
	if(pawnf==FILEA)
	{
		if(bkr > pawnr && scorer->distance[bks][promote] <= 1)
		{
			if(sqcolour[bishsq] != sqcolour[promote])
			{
				scorer->drawflag=true;
			}
		}
	}
	else if(pawnf==FILEH)
	{
		if(bkr > pawnr && scorer->distance[bks][promote] <= 1)
		{
			if(sqcolour[bishsq] != sqcolour[promote])
			{
				scorer->drawflag=true;
			}
		}
	}

	if(!scorer->drawflag) scorer->bal[cW][END]+= wonending[cW][pawnr];

}

void K_v_KBP()
{
	uint pawnsq = LSB64(P_BB(cB));
	uint pawnf =  files[pawnsq];
	uint pawnr = ranks[pawnsq];

	uint wks =  KINGSQ(cW);
	uint wkr =  ranks[wks];

	uint promote = promsq[cB][pawnf];
	uint bishsq = LSB64(B_BB(cB));

	//rook pawn draw
	if(pawnf==FILEA)
	{
		if(wkr < pawnr && scorer->distance[wks][promote] <= 1)
		{
			if(sqcolour[bishsq] != sqcolour[promote])
			{
				scorer->drawflag=true;
			}
		}
	}
	else if(pawnf==FILEH)
	{
		if(wkr < pawnr && scorer->distance[wks][promote] <= 1)
		{
			if(sqcolour[bishsq] != sqcolour[promote])
			{
				scorer->drawflag=true;
			}
		}
	}

	if(!scorer->drawflag) scorer->bal[cB][END]+= wonending[cB][pawnr];
}

void KB_v_KP()
{
	uint pawnsq = LSB64(P_BB(cB));
	uint pawnf =  files[pawnsq];

	uint wks =  KINGSQ(cW);

    uint bks =  KINGSQ(cB);

	uint side = SIDENOW;

	uint promote = promsq[cB][pawnf];
	uint bishsq = LSB64(B_BB(cW));
    uint bishcol = sqcolour[bishsq];

	scorer->drawflag = true;
	//rook pawn win for white, the only chance
	if(pawnf==FILEA && bishcol == sqcolour[promote])
	{
		if(bks == A1 && pawnsq==A2 && side == cW && wks == C2)
		{
			scorer->drawflag = false;//it's mate in 1
		}
	}
	else if(pawnf==FILEH && bishcol == sqcolour[promote])
	{
		if(bks == H1 && pawnsq==H2 && side == cW && wks == F2)
		{
			scorer->drawflag = false;//it's mate in 1
		}
	}

	//adjust material to give a disadvantage for white, who can draw at best
	scorer->bal[cW][END] -= vB;
}

void KP_v_KB()
{
	uint pawnsq = LSB64(P_BB(cW));
	uint pawnf =  files[pawnsq];

	uint wks =  KINGSQ(cW);

    uint bks =  KINGSQ(cB);
	uint side = SIDENOW;

	uint promote = promsq[cW][pawnf];
	uint bishsq = LSB64(B_BB(cB));
    uint bishcol = sqcolour[bishsq];

	scorer->drawflag = true;
	//rook pawn win for white, the only chance
	if(pawnf==FILEA && bishcol == sqcolour[promote])
	{
		if(wks == A8 && pawnsq==A7 && side == cB && bks == C7)
		{
			scorer->drawflag = false;//it's mate in 1
		}
	}
	else if(pawnf==FILEH && bishcol == sqcolour[promote])
	{
		if(wks == H8 && pawnsq==H7 && side == cB && wks == F7)
		{
			scorer->drawflag = false;//it's mate in 1
		}
	}

	//adjust material to give a disadvantage for black, who can draw at best
	scorer->bal[cB][END] -= vB;
}

/*
N vs P... if the king is not in the square of the promoting pawn, then the knight
needs to be able to control the squares in front of the pawn, up to 6th rank. If the pawn is on the
seventh rank, the knight must be controlling the promotion square for a draw.

Rook pawns are another story...
*/
void KN_v_KP()
{
	uint pawnsq = LSB64(P_BB(cB));
	uint pawnf =  files[pawnsq];
	uint pawnr = ranks[pawnsq];

	uint knsq = LSB64(N_BB(cW));


     const int *movedir = NULL;

	scorer->drawflag = false;
	//non rook pawn
	if(pawnf>FILEA && pawnf<FILEH)
	{
		if(pawnr==RANK2)
		{
			for(movedir = dirPieces[pwN]; *movedir ; movedir++)
            {
			   if(knsq+*movedir == pawnsq+S) { scorer->drawflag = true; break;}
		    }
		}
		else
		{
		  for(movedir = dirPieces[pwN]; *movedir ; movedir++)
          {
			   if(knsq+*movedir==pawnsq+S || knsq+*movedir==pawnsq+SE || knsq+*movedir==pawnsq+SW) { scorer->drawflag = true; break;}
		  }
		}
	}

	//adjust material to give a disadvantage for white, who can draw at best
	scorer->bal[cW][END] -= vN;
}

void KP_v_KN()
{
	uint pawnsq = LSB64(P_BB(cW));
	uint pawnf =  files[pawnsq];
	uint pawnr = ranks[pawnsq];

	uint knsq = LSB64(N_BB(cB));


     const int *movedir = NULL;

	scorer->drawflag = false;
	//non rook pawn
	if(pawnf>FILEA && pawnf<FILEH)
	{
		if(pawnr==RANK7)
		{
			for(movedir = dirPieces[pbN]; *movedir ; movedir++)
            {
			   if(knsq+*movedir == pawnsq+N) { scorer->drawflag = true; break;}
		    }
		}
		else
		{
		  for(movedir = dirPieces[pbN]; *movedir ; movedir++)
          {
			   if(knsq+*movedir==pawnsq+N || knsq+*movedir==pawnsq+NE || knsq+*movedir==pawnsq+NW) { scorer->drawflag = true; break;}
		  }
		}
	}

	//adjust material to give a disadvantage for white, who can draw at best
	scorer->bal[cB][END] -= vN;
}
