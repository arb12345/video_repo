#ifndef PIECEDEFS_H
#define PIECEDEFS_H

#include <string>
#include "defs.h"

using std::string;

const uint pE = 0;
const uint pwP = 1;
const uint pwN = 3;
const uint pwB = 5;
const uint pwR = 7;
const uint pwQ = 9;
const uint pwK = 11;

const uint pbP = 2;
const uint pbN = 4;
const uint pbB = 6;
const uint pbR = 8;
const uint pbQ = 10;
const uint pbK = 12;

const uint numpieces = 13;//includes "empty uint"
const uint numcolours = 2;
const uint maxpiecenum = 11; //max numer of one type - technically could have 9 queens.... plus piece list space [0] is free
const uint piecedead = 0;

extern int const dirN[];
extern int const dirB[];
extern int const dirR[];
extern int const dirQ[];
extern int const *dirPieces[];

extern int const dirwP[];
extern int const dirbP[];
extern int const *dirPawn[];

extern const uint epdelta[2];

extern const string piecechars;
extern const string colourchars;

extern const uint ismajor[numpieces];
extern const uint isminor[numpieces];
extern const uint isbigpiece[numpieces]; //N or above
extern const uint iswhite[numpieces];
extern const uint isblack[numpieces];
extern const uint isslide[numpieces];
extern const uint iscolour[numpieces];
extern const uint ispawn[numpieces];

extern const uint sliders[numcolours][3];
extern const uint nonsliders[numcolours][2];
extern const uint pawns[numcolours];
extern const uint kings[numcolours];
extern const uint knights[numcolours];
extern const uint rooks[numcolours];
extern const uint bishops[numcolours];
extern const uint queens[numcolours];
extern const uint startrank[numcolours];

extern inline bool piecegood(uint pce) {
    if(pce>pE && pce <= pbK) return true;
    else return false;
}
extern inline char piecechar(const uint pce) {return piecechars[pce];}
extern inline char colourchar(const uint pce) {return colourchars[pce];}

#define PCECOL(pce) (iscolour[(pce)])
#define ISMAJOR(pce) (ismajor[(pce)])
#define ISMINOR(pce) (isminor[(pce)])
#define ISWHITE(pce) (iswhite[(pce)])
#define ISBLACK(pce) (isblack[(pce)])
#define ISSLIDE(pce) (isslide[(pce)])
#define ISBIG(pce) (isbigpiece[(pce)])
#define ISPAWN(pce) (ispawn[(pce)])

#define MOVEDIR(pce) (dirPieces[(pce)])

#endif
