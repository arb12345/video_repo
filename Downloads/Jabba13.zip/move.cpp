#include <iostream>
#include <string>

#include "move.h"
#include "movegen.h"
#include "make.h"
#include "squares.h"
#include "piecedefs.h"
#include "attack.h"
#include "defs.h"
#include "engine.h"
#include "searcher.h"

using namespace std;

bool flaggood(uint flag)
{
     if(flag!=FlagE && flag != FlagCA && flag != FlagEP) return false;

     return true;
}

//quiet moves to cut
bool cancutmove(uint move)
{
	if (move & FlagCAPEP) return false;
	else if(move & FlagCA) return false;
	else if (PROM(move)) return false;
	else return true;
}

int materialgainmove(uint move)
{
	if(move & FlagEP) return int(vP);
	else if(PROM(move)) return int((PCEVAL(PROM(move))-vP));
	else if(CAP(move)) return int(PCEVAL(CAP(move)));
	else return 0;
}

void printmovelong(uint move)
{
       uint from = FROM(move);
       uint to = TO(move);
       uint cap = CAP(move);
       uint prom = PROM(move);

       ASS(onbrd(from));
       ASS(onbrd(to));
       ASS(piecegood(cap)||cap==pE);
       ASS(piecegood(prom)||prom==pE);
       cout<<"->"<<printsquare(from)<<"->"<<printsquare(to)<<" captured: ["<<piecechar(cap)<<"] promoted to: ["<<piecechar(prom)<<"]";
}

string printmove(uint move)
{
       uint from = FROM(move);
       uint to = TO(move);
       uint prom = PROM(move);

       if(!onbrd(from)) return "?";

       ASS(onbrd(from));
       ASS(onbrd(to));
       ASS(piecegood(prom)||prom==pE);

	   string m;

	   if(engopt.variant==2 && (move&FlagCA))
       {
           uint spareto=0;
		   if(tree->xb)
		   {
			   if(to==G1 || to==G8) m="O-O";
               if(to==C1 || to==C8) m="O-O-O";
			   return m;
		   }
		   else
		   {
			   if(to==G1) { from = brd->frccasq[FRCWK]; to = brd->frccasq[FRCWKR]; }
			   else if(to==C1) { from = brd->frccasq[FRCWK]; spareto = brd->frccasq[FRCWQR]; }
			   else if(to==G8) { from = brd->frccasq[FRCBK]; spareto = brd->frccasq[FRCBKR]; }
			   else if(to==C8) { from = brd->frccasq[FRCBK]; spareto = brd->frccasq[FRCBQR]; }

			   m+=printsquare(from);
			   m+=printsquare(spareto);
			   return m;
		   }
       }

	   m+=printsquare(from);
	   m+=printsquare(to);

       //printf("%s%s",printsquare(from),printsquare(to));

       if(prom)
       {
         switch (prom)
         {
          case pwQ :m+='q'; break;
          case pwR :m+='r'; break;
          case pwB :m+='b'; break;
          case pwN :m+='n'; break;
          case pbQ :m+='q'; break;
          case pbR :m+='r'; break;
          case pbB :m+='b'; break;
          case pbN :m+='n'; break;
          default: cout<<"\n prom piece print error"; exit(1);
          break;
         };
       }
	   return m;
}


string movetosan(uint move)
{
    uint from = FROM(move);
    uint to = TO(move);
    uint fromfile = FILE(from);
    uint tofile = FILE(to);
    uint fromrank = RANK(from);
    uint torank = RANK(to);
    uint piecefrom = BRDPCE(from);
    bool ambiguous = false;
    uint ambigsq[8] = {0,0,0,0,0,0,0,0};
    uint ambignum = 0;
    bool givescheck = false;
    bool iscastle = false;
    bool givesmate = false;
    bool iscapture = false;
    bool ispromote = false;
    string prompiece;
    string sanmove;
    const string sanpiece =  ".PPNNBBRRQQKK";
   // cout<<"\n converting "<<printmove(move)<<" ";
  //  printboard();
   // mat.printmaterial();

    gen_all_moves(NULLMOVE);
	//printmovelist(PLYNOW);
    bool found = false;
    uint j,played=0;
	uint tempmove = NULLMOVE;
	uint tempmove2 = NULLMOVE;

    //first loop, looking for move and if it gives check, or mate
    for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
    {
        tempmove = MOVE(PLYNOW,i);
		if (makemove(tempmove)) {takemove();continue; }
          // cout<<"\n\t\t\t "<<i<<" "<<printmove(tempmove);
     //      pboard.printboard();
           if(tempmove == move)
           {
               found = true;
               //cout<<" could be... ";
               if(incheck(SIDENOW))
               {
                givescheck=true;
                //cout<<" givescheck ";
                gen_all_moves(NULLMOVE);
	           // printmovelist(PLYNOW);
                 for( j = 0; j < MOVECOUNT(PLYNOW); ++j)
                 {
					 tempmove2 = MOVE(PLYNOW,j);
                     // cout<<"\ntrying "<<printmove(list2[j]);
                      if (makemove(tempmove2))
                      {
                        //  cout<< " notok ";
                          takemove();
                          continue;
                      }
                   //   cout<< " ok! ";
                      played++;
                      takemove();
                      break;
                 }
                 if(!played) { givesmate = true; givescheck=false;}
               }
           }
           takemove();
           if(found==true) break;
    }

    if(found==false)
    {
         cout<<" MOVE NOT FOUND "<<printmove(move)<<" ";
         exit(1);
         ASS(true==false);
         return " error san";
    }

     //second loop, looking for ambiguity
     for(uint i = 0; i < MOVECOUNT(PLYNOW); ++i)
     {
         tempmove = MOVE(PLYNOW,i);
		 if (makemove(tempmove)) {takemove();continue; }
            takemove();
            if(tempmove == move) continue;
            //cout<<"\n\t\t checking "<<printmove(list[i]);
            //cout<<" brdfrom = "<<board[FROM(list[i])]<<" pcefrom "<<piecefrom;
            //cout<<" to = "<<TO(list[i])<<" origto "<<to;
            if(BRDPCE(FROM(tempmove)) == piecefrom && TO(tempmove) == to)
            {
                ambiguous = true;
                //cout<<" is ambig ";
                ambigsq[ambignum] = FROM(tempmove);
                ambignum++;
            }
     }

     //cout<<"\n loops finished, printing board ";
     //pboard.printboard();
     //now set the flag boolean values
     if(moveiscastle(SIDENOW,move)) iscastle = true;
     if(moveiscapture(move)) iscapture = true;
     if(PROM(move))
     {
         ispromote = true;
         switch (PROM(move))
		   {
		    case pwN:prompiece = "N"; break;
		    case pwB:prompiece = "B"; break;
		    case pwR:prompiece = "R"; break;
		    case pwQ:prompiece = "Q"; break;
		    case pbN:prompiece = "N"; break;
		    case pbB:prompiece = "B"; break;
		    case pbR:prompiece = "R"; break;
		    case pbQ:prompiece = "Q"; break;
			default : cout<<" \n san prom problems";exit(1);ASS(true==false);break;
		   }
     }

     //now deal with promotions, castling and pawn moves, and return them
    if(iscastle)
    {
       // cout<<" castle ";
        if(to == G8 || to == G1)
        { sanmove = "O-O"; }
        else { sanmove = "O-O-O"; }

        if(givescheck) sanmove+="+";
        else if(givesmate) sanmove+="#";

        return sanmove;
    }
    if(ispromote)
    {
       // cout<<" promote ";
        if(iscapture)
        {
         //   cout<<" cap ";
            sanmove+=filetostr[fromfile];
            sanmove+="x";
        }
        sanmove+=filetostr[tofile];
        sanmove+=ranktostr[torank];
        sanmove+="=";
        sanmove+=prompiece;
        if(givescheck) sanmove+="+";
        else if(givesmate) sanmove+="#";

        return sanmove;
    }

    if(piecefrom==pwP || piecefrom==pbP)
    {
     //   cout<<" pawn ";
        if(iscapture)
        {
      //      cout<<" cap ";
            sanmove+=filetostr[fromfile];
            sanmove+="x";
        }
        sanmove+=filetostr[tofile];
        sanmove+=ranktostr[torank];
        if(givescheck) sanmove+="+";
        else if(givesmate) sanmove+="#";
        return sanmove;
    }

    if(!ambiguous)
    {
        //cout<<" not ambig ";
        sanmove+=sanpiece[piecefrom];
        if(iscapture) { sanmove+="x"; }
        sanmove+=filetostr[tofile];
        sanmove+=ranktostr[torank];
        if(givescheck) sanmove+="+";
        else if(givesmate) sanmove+="#";
        return sanmove;
    }
    else
    {
        int usefile = 1;
        int userank = 1;
       // cout<<" ambig ";
        for(uint c = 0; c < ambignum; ++c)
        {
            if(files[ambigsq[c]]==fromfile) usefile = 0;
            if(ranks[ambigsq[c]]==fromrank) userank = 0;
        }
        sanmove+=sanpiece[piecefrom];
        if(usefile) sanmove+=filetostr[fromfile];
        else if(userank) sanmove+=ranktostr[fromrank];
        else
        {
                sanmove+=filetostr[fromfile];
                sanmove+=ranktostr[fromrank];
        }
        if(iscapture) { sanmove+="x"; }
        sanmove+=filetostr[tofile];
        sanmove+=ranktostr[torank];
        if(givescheck) sanmove+="+";
        else if(givesmate) sanmove+="#";
        return sanmove;
    }
}

uint santomove(const string sanmove)
{

    uint length = sanmove.length();
    uint last = length-1;
    ASS(length>1&&length<8);

   // cout<<"\n move in "<<sanmove;
  //  printboard();


    bool capture = false;
    bool promote = false;
    bool fileambig = false;
    bool rankambig = false;
    bool found = false;


    string::size_type locater  = sanmove.find("x",0);
    if(locater != string::npos) capture = true;
    locater  = sanmove.find("=",0);
    if(locater != string::npos) promote = true;

   // if(capture) cout<<" capture "; else cout<<" not capture ";
   // if(promote) cout<<" promote "; else cout<<" not promote ";

    uint piece=0;
    uint side = SIDENOW;
    uint ff,tf,fr,tr,from=0,to=0,cap=0,prom=0,flag=0,move;

    ASS(side>=cW&&side<=cB);

    if(sanmove == "0-0" || sanmove == "O-O" || sanmove == "0-0+" || sanmove == "O-O+" || sanmove == "0-0#" || sanmove == "O-O#")
    {
        cap = pE; flag = FlagCA;
        if(side==cW) { from = E1; to = G1;  }
        else { from = E8; to = G8;  }
    }
    else if(sanmove == "0-0-0" || sanmove == "O-O-O" || sanmove == "0-0-0+" || sanmove == "O-O-O+" || sanmove == "0-0-0#" || sanmove == "O-O-O#")
    {
        cap = pE; flag = FlagCA;
        if(side==cW) { from = E1; to = C1;  }
        else { from = E8; to = C8;  }
    }
    else if(sanmove[0] >= 'a')//pawn move?
    {
      //  cout<<" pawn move ";
        ASS(sanmove[0] >= 'a' && sanmove[0] <= 'h');
        if(side == cW)  piece = pwP;
        else piece = pbP;

        //if we don't have a capture, the first letter will be the file of the target square
        if(!capture) //e4 or e8=Q
        {
            ASS(sanmove[1] >= '1' && sanmove[1] <= '8');
            tf = chartofile(sanmove[0]);
            tr = chartorank(sanmove[1]);
            to = fr2sq(tf,tr);

            ASS(BRDPCE(to)==pE);
            ASS(onbrd(to));

            //could have been a 2 move start
            if(side==cW)
            {
              if(ranks[to]==RANK4)
              {
                if(BRDPCE(to+S)==pE) from=to+S+S;
                else from=to+S;
              }
              else
              {
                  from = to+S;
              }
            }
            else
            {
               if(ranks[to]==RANK5)
              {
                if(BRDPCE(to+N)==pE) from=to+N+N;
                else from=to+N;
              }
              else
              {
                  from = to+N;
              }
            }
        }//end of if !capture
        else //form will be exf4
        {
            //cout<<" pcap ";
            tf = chartofile(sanmove[2]);
            tr = chartorank(sanmove[3]);
            if(side==cW) fr = tr-1;
            else fr = tr+1;
            ff = chartofile(sanmove[0]);
            to = fr2sq(tf,tr);
           // cout<<"\n to = "<<printsquare(to);
            cap = BRDPCE(to);
           // cout<<" f "<<ff<<" r "<<fr;
            from = fr2sq(ff,fr);
           // cout<<" ? "<<printsquare(to);
            if(BRDPCE(to)==pE) flag=FlagEP; //ep cap
            ASS(onbrd(from));
            ASS(onbrd(to));
            ASS( (cap==pE && flag==FlagEP) || piecegood(cap) );

        }
    }
    else//not pawn move
    {
        //identify the moving piece
        switch(sanmove[0])
        {
            case 'K': if (side==cW) piece=pwK;else piece=pbK; break;
            case 'Q': if (side==cW) piece=pwQ;else piece=pbQ; break;
            case 'R': if (side==cW) piece=pwR;else piece=pbR; break;
            case 'B': if (side==cW) piece=pwB;else piece=pbB; break;
            case 'N': if (side==cW) piece=pwN;else piece=pbN; break;
            default: {cout<<"\n piece unidentified, move "<<sanmove<<endl<<endl;exit(1);}
        }

        ASS(piecegood(piece));
       // cout<<" piece move "<<piecechar(piece)<<" ";

        //idendtify ambiguity
        if(sanmove[1] >='1' && sanmove[1] <= '8')
        {
            rankambig=true;
          //  cout<<" rankambig ";
        }
        else
        {
             if(capture)
             {
                 if(sanmove[1] >='a' && sanmove[1] <= 'h')
                 {
                     fileambig=true;
                   //  cout<<" fileambig ";
                 }
             }
             else
             {
                 if((sanmove[1] >='a' && sanmove[1] <= 'h') && (sanmove[2] >='a' && sanmove[2] <= 'h') )
                 {
                     fileambig=true;
                    // cout<<" fileambig2 ";
                 }
             }
        }

        //now identify the to sq
        if(!capture)
        {
            if(!rankambig && !fileambig)
            {
                tf = chartofile(sanmove[1]);
                tr = chartorank(sanmove[2]);
                to = fr2sq(tf,tr);
                ASS(onbrd(to));
                ASS(BRDPCE(to)==pE);
            }
            else
            {
                tf = chartofile(sanmove[2]);
                tr = chartorank(sanmove[3]);
                to = fr2sq(tf,tr);
                ASS(onbrd(to));
                ASS(BRDPCE(to)==pE);
            }
        }
        else//is capture
        {
            if(!rankambig && !fileambig) //Nxd4
            {
                tf = chartofile(sanmove[2]);
                tr = chartorank(sanmove[3]);
                to = fr2sq(tf,tr);
                cap = BRDPCE(to);
                ASS(onbrd(to));
                ASS(BRDPCE(to)!=pE);
            }
            else //Nexd4
            {
                tf = chartofile(sanmove[3]);
                tr = chartorank(sanmove[4]);
                to = fr2sq(tf,tr);
                cap = BRDPCE(to);
                ASS(onbrd(to));
                ASS(BRDPCE(to)!=pE);
            }
        }

        uint ar;
        uint af;
        uint i,sq,tsq;
        const int *movedir;
        u64 pieceBB;
        //now need the from sqaure, start with ambig, it's easier, just look for the piece on relevant file or rank
        if(rankambig)
        {
            ar = chartorank(sanmove[1]);
            ASS(ranks[N*ar]==ar);
            for(i = N*ar; !(i&0x88); i+=E)
            {
                if(BRDPCE(i)==piece) { from=i; break; }
            }
        }
        else if(fileambig)
        {
            af = chartofile(sanmove[1]);
           // cout<<" ambigfile = "<<af;
            for(i = af; !(i&0x88); i+=N)
            {
              //  cout<<" trying "<<printsquare(i);
                if(BRDPCE(i)==piece) {
                    // cout<<"\n found "<<piecechar(brd[i]);
                     from=i; break; }
            }
        }
        else//not ambig, need to find the piece using the to square and the known piece type
        {
            //cout<<"\n looking nonambig ";
            //only thing that can cock this up is if the piece is pinned, so need an extra check
            pieceBB = GET_BB(piece);
            while(pieceBB)
            {
                sq = POP64(pieceBB);
              //  cout<<" onsq "<<printsquare(sq)<<" to = "<<printsquare(to);
                ASS(onbrd(sq));
                for(movedir = dirPieces[piece]; *movedir ; movedir++)
                {
                    if(ISSLIDE(piece))
                    {
                     for(tsq = sq+*movedir; !(tsq & 0x88); tsq += *movedir)
                     {
                    //    cout<<" to tsq "<<printsquare(tsq);
                        if(tsq==to)
                        {
                            from=sq;
                            if(!ispinned(SIDENOW^1,from))
                            {
                             found = true;
                         //    cout<<"found ";
                             break;
                            }
                           // else cout<<"\n pinned ";
                        }
                        if(BRDPCE(tsq)!=pE) break;
                        if(found) break;
                     }
                    }
                    else
                    {
                        if(sq+*movedir==to)
                        {
                            from=sq;
                            if(!ispinned(SIDENOW^1,from))
                            {
                             found = true;
                          //   cout<<"found ";
                             break;
                            }
                          //  else cout<<"\n pinned ";
                        }
                    }
                    if(found) break;
                }
                if(found) break;
            }
        }
    }


    if(promote)
    {
        ASS(ranks[to]==RANK1 || ranks[to]==RANK8);
        if(sanmove[last]=='#' || sanmove[last]=='+') last--;
     switch (sanmove[last])
     {
      case 'Q': if(side==cW) prom = pwQ; else prom = pbQ; break;
      case 'R': if(side==cW) prom = pwR; else prom = pbR; break;
      case 'B': if(side==cW) prom = pwB; else prom = pbB; break;
      case 'N': if(side==cW) prom = pwN; else prom = pbN; break;
      default: cout<<"\n sanmove prom piece not found";exit(1);ASS(true==false);break;
      }
    }

           move = (from | (to<<7) | (cap<<16) | (prom<<20) | flag);

          // cout<<"\n move is "<<printmove(move)<<" "<<move;
          // cout<<" from "<<FROM(move)<<" to "<<TO(move)<<" flag "<<FLAG(move)<<" cap "<<CAP(move);

#ifdef DEBUG
    gen_all_moves(NULLMOVE);
    found = false;
    uint i;

    //first loop, looking for move and if it gives check, or mate
    for( i = 0; i < MOVECOUNT(PLYNOW); ++i)
    {
         //  cout<<"\n\t checking "<<printmove(MOVE(PLYNOW,i))<<" "<<MOVE(PLYNOW,i);
         //  cout<<" from "<<FROM(MOVE(PLYNOW,i))<<" to "<<TO(MOVE(PLYNOW,i))<<" flag "<<FLAG(MOVE(PLYNOW,i))<<" cap "<<CAP(MOVE(PLYNOW,i));
           if(MOVE(PLYNOW,i) == move)
           found=true;
    }
    ASS(found);
#endif

return move;
}


