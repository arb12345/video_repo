#ifndef FEN_H
#define FEN_H

#include "board.h"
#include "material.h"
#include "history.h"

using namespace std;

extern const string startfen;

extern void setepdposition(const string epdline);
extern void mirrorboard();
extern string fenfromboard();

#endif
