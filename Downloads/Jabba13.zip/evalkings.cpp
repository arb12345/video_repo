#include <iostream>
#include <string>

#include "eval.h"
#include "defs.h"
#include "squares.h"
#include "bits.h"
#include "board.h"
#include "evalparam.h"

void score_kings()
{
   	uint piece;
	uint sq,revsq;
	uint enemy;
	uint rank;
	uint file;
	uint sq64,revsq64;
	uint oppkingrank;
    u64 wocc;
    u64 bocc;

    wocc = P_BB(cW);
    bocc = P_BB(cB);

	piece = pwK;
	enemy = cB;

    oppkingrank = ranks[KINGSQ(cB)];

    ASS(oppkingrank>=RANK1&&oppkingrank<=RANK8);


      sq = KINGSQ(cW);
      sq64 = SQTO64(sq);

      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);

      file = files[sq];
      rank = ranks[sq];

      //safety
	  if(scorer->useWsafety)
	  {
		  scorer->safe[cW] = eval_light_king(sq, bocc, wocc, file, rank);
	  }

	  //tropism
	  scorer->safe[cW] -= safety_table[scorer->wkatt];

    piece = pbK;
	enemy = cW;


    oppkingrank = ranks[KINGSQ(cW)];

    ASS(oppkingrank>=RANK1&&oppkingrank<=RANK8);

      sq = KINGSQ(cB);
      sq64 = SQTO64(sq);
      revsq = SQREV(sq);
      revsq64 = SQTO64(revsq);

      ASS(onbrd(sq));
      ASS(BRDPCE(sq)==piece);

      file = files[sq];
      rank = ranks[sq];

      ASS(file>=FILEA&&file<=FILEH);
      ASS(rank>=RANK1&&rank<=RANK8);

	  if(scorer->useBsafety)
	  {
		  scorer->safe[cB] = eval_dark_king(sq, bocc, wocc, file, rank);
	  }

	  //tropism
	  scorer->safe[cB] -= safety_table[scorer->bkatt];


}

int eval_light_king(const uint &sq, const u64 &bocc, const u64 & wocc, const uint &file, const uint &rank)
{
	int r=0;  /* the value to return */

	if (file < FILED) {
		if(file>FILEA) r += eval_lkp(sq+W,bocc,file-1);
		r += eval_lkp(sq,bocc,file);
		r += eval_lkp(sq+E,bocc,file+1)/2;
	}
	else if (file > FILEE) {
		if(file<FILEH) r += eval_lkp(sq+E,bocc,file+1);
		r += eval_lkp(sq,bocc,file);
		r += eval_lkp(sq+W,bocc,file-1)/2;
	}
/*
	else
	{
		if(FILEOPEN(bocc,file-1)) r -= KingMid;
		if(FILEOPEN(bocc,file)) r -= KingMid;
		if(FILEOPEN(bocc,file+1)) r -= KingMid;
		if(FILEOPEN(wocc,file-1)) r -= KingMid;
		if(FILEOPEN(wocc,file)) r -= KingMid;
		if(FILEOPEN(wocc,file+1)) r -= KingMid;
	}
*/
	return r;
}

int eval_dark_king(const uint &sq, const u64 &bocc, const u64 & wocc, const uint &file, const uint &rank)
{
	int r=0;  /* the value to return */


	if (file < FILED) {
		if(file>FILEA) r += eval_dkp(sq+W,wocc,file-1);
		r += eval_dkp(sq,wocc,file);
		r += eval_dkp(sq+E,wocc,file+1)/2;
	}
	else if (file > FILEE) {
		if(file<FILEH) r += eval_dkp(sq+E,wocc,file+1);
		r += eval_dkp(sq,wocc,file);
		r += eval_dkp(sq+W,wocc,file-1)/2;
	}

/*
	else
	{
		if(FILEOPEN(bocc,file-1)) r -= KingMid;
		if(FILEOPEN(bocc,file)) r -= KingMid;
		if(FILEOPEN(bocc,file+1)) r -= KingMid;
		if(FILEOPEN(wocc,file-1)) r -= KingMid;
		if(FILEOPEN(wocc,file)) r -= KingMid;
		if(FILEOPEN(wocc,file+1)) r -= KingMid;
	}
*/
	return r;
}


int eval_dkp(const uint &sq, const u64 &wocc, const uint &file)
{
	int r = 0;

	if (BRDPCE(sq+S) == pbP && RANK(sq) > RANK1);
	else if (BRDPCE(sq+S+S) == pbP && RANK(sq) > RANK2)
		r -= KingP1;
	else if (BRDPCE(sq+S+S+S) == pbP && RANK(sq) > RANK3)
		r -= KingP2;
	else
		r -= KingP3;
/*
	if(FILEOPEN(wocc, file))
		r -= 15;
	else if (board[sq+S+S] == pwP)
		r -= 10;
	else if (board[sq+S+S+S] == pwP)
		r -= 5;
*/

	return r;
}


/* eval_lkp(f) evaluates the Light King Pawn on file f */

int eval_lkp(const uint &sq, const u64 &bocc, const uint &file)
{
	int r = 0;

	if (BRDPCE(sq+N) == pwP && RANK(sq) < RANK8);
	else if (BRDPCE(sq+N+N) == pwP && RANK(sq) < RANK7)
		r -= KingP1;
	else if (BRDPCE(sq+N+N+N) == pwP && RANK(sq) < RANK6)
		r -= KingP2;
	else
		r -= KingP3;
/*
	if(FILEOPEN(bocc, file))
		r -= 15;
	else if (board[sq+N+N] == pbP)
		r -= 10;
	else if (board[sq+N+N+N] == pbP)
		r -= 5;
*/
	return r;
}
