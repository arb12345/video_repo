#include <iostream>
#include <string>

#include "evalparam.h"
#include "eval.h"

using namespace std;


int BPair;
int BmobminO;
int BmobminE;
int BmobsqO;
int BmobsqE;
int QmobminO;
int QmobminE;
int QmobsqO;
int QmobsqE;
int RmobminO;
int RmobminE;
int RmobsqO;
int RmobsqE;
int NmobminO;
int NmobminE;
int NmobsqO;
int NmobsqE;
int KingMid;
int KingP1;
int KingP2;
int KingP3;
int NSupp1;
int NSupp2;
int NSupp3;
int PDouOpe;
int PDouEnd;
int PIsoOpe;
int PIsoEnd;
int POpeOpe;
int POpeEnd;
int PBacOpe;
int PBacEnd;
int PPasOpe;
int PPasEnd;
int PPasConOpe;
int PPasConEnd;
int PPasRookEnd;
int PCanOpe;
int PCanEnd;
int QAttSide;
int QAttDir;
int QSevOpe;
int QSevEnd;
int RAttSide;
int RAttDir;
int RSevOpe;
int RSevEnd;
int RSemFile;
int ROpeFile;
int trR;
int trP;
int trB;
int minordev;
int majorsoon;
int psqPo;
int psqPe;
int psqPra;
int psqNo;
int psqNe;
int psqBo;
int psqBe;
int psqRo;
int psqQo;
int psqQe;
int psqKo;
int psqKe;
int PDouOpeWk;
int PDouEndWk;
int PIsoOpeWk;
int PIsoEndWk;
int tropNBRQ;
int tropBRQ;
int tropNRQ;
int tropRQ;
int tropNBQ;
int tropBQ;
int tropNQ;
int tropQ;
int tropNBR;
int tropBR;
int tropNR;
int tropR;
int tropNB;
int tropB;
int tropN;
int Qmato;
int Qmate;

sEvalParam  paramlist[] = {
// tune,   name,         min, max,   value
{  false, "BPair",	0,	100,	50 },
{  false, "BmobminO",	-50,	50,	-18 },
{  false, "BmobminE",	-50,	50,	-16 },
{  false, "BmobsqO",	0,	50,	1 },
{  false, "BmobsqE",	0,	50,	2 },
{  false, "QmobminO",	-50,	50,	0 },
{  false, "QmobminE",	-50,	50,	0 },
{  false, "QmobsqO",	0,	50,	1 },
{  false, "QmobsqE",	0,	50,	1 },
{  false, "RmobminO",	-50,	50,	0 },
{  false, "RmobminE",	-50,	50,	0 },
{  false, "RmobsqO",	0,	50,	1 },
{  false, "RmobsqE",	0,	50,	1 },
{  false, "NmobminO",	-50,	50,	0 },
{  false, "NmobminE",	-50,	50,	0 },
{  false, "NmobsqO",	0,	50,	1 },
{  false, "NmobsqE",	0,	50,	1 },
{  false, "KingMid",	0,	100,	5 },
{  false, "KingP1",	0,	100,	10 },
{  false, "KingP2",	0,	100,	20 },
{  false, "KingP3",	0,	100,	25 },
{  false, "NSupp1",	0,	100,	1 },
{  false, "NSupp2",	0,	100,	3 },
{  false, "NSupp3",	0,	100,	10 },
{  false, "PDouOpe",	0,	100,	8 },
{  false, "PDouEnd",	0,	100,	4 },
{  false, "PIsoOpe",	0,	100,	5 },
{  false, "PIsoEnd",	0,	100,	7 },
{  false, "POpeOpe",	0,	100,	10 },
{  false, "POpeEnd",	0,	100,	10 },
{  false, "PBacOpe",	0,	100,	2 },
{  false, "PBacEnd",	0,	100,	3 },
{  false, "PPasOpe",	0,	100,	6 },
{  false, "PPasEnd",	0,	100,	6 },
{  false, "PPasConOpe",	0,	100,	0 },
{  false, "PPasConEnd",	0,	100,	0 },
{  false, "PPasRookEnd",	0,	100,	0 },
{  false, "PCanOpe",	0,	100,	0 },
{  false, "PCanEnd",	0,	100,	2 },
{  false, "QAttSide",	0,	100,	0 },
{  false, "QAttDir",	0,	100,	8 },
{  false, "QSevOpe",	0,	100,	0 },
{  false, "QSevEnd",	0,	100,	4 },
{  false, "RAttSide",	0,	100,	0 },
{  false, "RAttDir",	0,	100,	1 },
{  false, "RSevOpe",	0,	100,	15 },
{  false, "RSevEnd",	0,	100,	6 },
{  false, "RSemFile",	0,	100,	4 },
{  false, "ROpeFile",	0,	100,	4 },
{  false, "trR",	0,	500,	100 },
{  false, "trP",	0,	200,	50 },
{  false, "trB",	0,	400,	100 },
{  false, "minordev",	0,	50,	0 },
{  false, "majorsoon",	0,	50,	0 },
{  false, "psqPo",	-50,	50,	0 },
{  false, "psqPe",	-50,	50,	0 },
{  false, "psqPra",	-50,	50,	0 },
{  false, "psqNo",	-50,	50,	0 },
{  false, "psqNe",	-50,	50,	0 },
{  false, "psqBo",	-50,	50,	0 },
{  false, "psqBe",	-50,	50,	0 },
{  false, "psqRo",	-50,	50,	0 },
{  false, "psqQo",	-50,	50,	0 },
{  false, "psqQe",	-50,	50,	0 },
{  false, "psqKo",	-50,	50,	0 },
{  false, "psqKe",	-50,	50,	0 },
{  false, "PDouOpeWk",	0,	100,	14 },
{  false, "PDouEndWk",	0,	100,	13 },
{  false, "PIsoOpeWk",	0,	100,	12 },
{  false, "PIsoEndWk",	0,	100,	14 },
{  false, "tropNBRQ",	0,	100,	0 },
{  false, "tropBRQ",	0,	100,	5 },
{  false, "tropNRQ",	0,	100,	0 },
{  false, "tropRQ",	0,	100,	5 },
{  false, "tropNBQ",	0,	100,	14 },
{  false, "tropBQ",	0,	100,	28 },
{  false, "tropNQ",	0,	100,	3 },
{  false, "tropQ",	0,	100,	1 },
{  false, "tropNBR",	0,	100,	11 },
{  false, "tropBR",	0,	100,	13 },
{  false, "tropNR",	0,	100,	34 },
{  false, "tropR",	0,	100,	24 },
{  false, "tropNB",	0,	100,	23 },
{  false, "tropB",	0,	100,	34 },
{  false, "tropN",	0,	100,	8 },
{  true, "Qmato",	-1000,	1000,	0 },
{  true, "Qmate",	-1000,	1000,	0 },
{  true, "end",	0,	100,	10 }
};

void init_eval_param()
{
    sEvalParam *entry = &paramlist[0];

    while(entry->name != "end")
    {
       if(entry->name ==   "BPair") BPair  = entry->value;
       else if(entry->name ==   "BmobminO") BmobminO = entry->value;
       else if(entry->name ==   "BmobminE") BmobminE = entry->value;
       else if(entry->name ==   "BmobsqO") BmobsqO = entry->value;
       else if(entry->name ==   "BmobsqE") BmobsqE = entry->value;
       else if(entry->name ==   "QmobminO") QmobminO = entry->value;
       else if(entry->name ==   "QmobminE") QmobminE = entry->value;
       else if(entry->name ==   "QmobsqO") QmobsqO = entry->value;
       else if(entry->name ==   "QmobsqE") QmobsqE = entry->value;
       else if(entry->name ==   "RmobminO") RmobminO = entry->value;
       else if(entry->name ==   "RmobminE") RmobminE = entry->value;
       else if(entry->name ==   "RmobsqO") RmobsqO = entry->value;
       else if(entry->name ==   "RmobsqE") RmobsqE = entry->value;
       else if(entry->name ==   "NmobminO") NmobminO = entry->value;
       else if(entry->name ==   "NmobminE") NmobminE = entry->value;
       else if(entry->name ==   "NmobsqO") NmobsqO = entry->value;
       else if(entry->name ==   "NmobsqE") NmobsqE = entry->value;
       else if(entry->name ==   "KingMid") KingMid = entry->value;
       else if(entry->name ==   "KingP1") KingP1 = entry->value;
       else if(entry->name ==   "KingP2") KingP2 = entry->value;
       else if(entry->name ==   "KingP3") KingP3 = entry->value;
       else if(entry->name ==   "NSupp1") NSupp1 = entry->value;
       else if(entry->name ==   "NSupp2") NSupp2 = entry->value;
       else if(entry->name ==   "NSupp3") NSupp3 = entry->value;
       else if(entry->name ==   "PDouOpe") PDouOpe = entry->value;
       else if(entry->name ==   "PDouEnd") PDouEnd = entry->value;
       else if(entry->name ==   "PIsoOpe") PIsoOpe = entry->value;
       else if(entry->name ==   "PIsoEnd") PIsoEnd = entry->value;
       else if(entry->name ==   "POpeOpe") POpeOpe = entry->value;
       else if(entry->name ==   "POpeEnd") POpeEnd = entry->value;
       else if(entry->name ==   "PBacOpe") PBacOpe = entry->value;
       else if(entry->name ==   "PBacEnd") PBacEnd = entry->value;
       else if(entry->name ==   "PPasOpe") PPasOpe = entry->value;
       else if(entry->name ==   "PPasEnd") PPasEnd = entry->value;
       else if(entry->name ==   "PPasConOpe") PPasConOpe = entry->value;
       else if(entry->name ==   "PPasConEnd") PPasConEnd = entry->value;
       else if(entry->name ==   "PPasRookEnd") PPasRookEnd = entry->value;
       else if(entry->name ==   "PCanOpe") PCanOpe = entry->value;
       else if(entry->name ==   "PCanEnd") PCanEnd = entry->value;
       else if(entry->name ==   "QAttSide")  QAttSide = entry->value;
       else if(entry->name ==   "QAttDir") QAttDir = entry->value;
       else if(entry->name ==   "QSevOpe")  QSevOpe = entry->value;
       else if(entry->name ==   "QSevEnd") QSevEnd = entry->value;
       else if(entry->name ==   "RAttSide") RAttSide  = entry->value;
       else if(entry->name ==   "RAttDir") RAttDir  = entry->value;
       else if(entry->name ==   "RSevOpe") RSevOpe = entry->value;
       else if(entry->name ==   "RSevEnd")  RSevEnd = entry->value;
       else if(entry->name ==   "RSemFile") RSemFile = entry->value;
       else if(entry->name ==   "ROpeFile") ROpeFile = entry->value;
       else if(entry->name ==    "trP") trP = entry->value;
       else if(entry->name ==    "trP") trP = entry->value;
       else if(entry->name ==    "trB")trB = entry->value;
       else if(entry->name ==   "minordev") minordev = entry->value;
       else if(entry->name ==   "majorsoon") majorsoon = entry->value;
       else if(entry->name ==   "psqPo") psqPo = entry->value;
       else if(entry->name ==   "psqPe") psqPe = entry->value;
       else if(entry->name ==   "psqPra") psqPra = entry->value;
       else if(entry->name ==   "psqNo") psqNo = entry->value;
       else if(entry->name ==   "psqNe") psqNe = entry->value;
       else if(entry->name ==   "psqBo") psqBo = entry->value;
       else if(entry->name ==   "psqBe") psqBe = entry->value;
       else if(entry->name ==   "psqRo") psqRo = entry->value;
       else if(entry->name ==   "psqQo")  psqQo = entry->value;
       else if(entry->name ==   "psqQe")  psqQe = entry->value;
       else if(entry->name ==   "psqKo") psqKo = entry->value;
       else if(entry->name ==   "psqKe") psqKe = entry->value;
       else if(entry->name ==   "PDouOpeWk")  PDouOpeWk = entry->value;
       else if(entry->name ==   "PDouEndWk") PDouEndWk = entry->value;
       else if(entry->name ==   "PIsoOpeWk") PIsoOpeWk = entry->value;
       else if(entry->name ==   "PIsoEndWk") PIsoEndWk = entry->value;
       else if(entry->name ==    "tropNBRQ") tropNBRQ = entry->value;
       else if(entry->name ==    "tropBRQ") tropBRQ = entry->value;
       else if(entry->name ==    "tropNRQ") tropNRQ = entry->value;
       else if(entry->name ==    "tropRQ") tropRQ = entry->value;
       else if(entry->name ==    "tropNBQ") tropNBQ = entry->value;
       else if(entry->name ==    "tropBQ") tropBQ = entry->value;
       else if(entry->name ==    "tropNQ") tropNQ = entry->value;
       else if(entry->name ==    "tropQ") tropQ = entry->value;
       else if(entry->name ==    "tropNBR") tropNBR = entry->value;
       else if(entry->name ==    "tropBR") tropBR = entry->value;
       else if(entry->name ==    "tropNR") tropNR = entry->value;
       else if(entry->name ==    "tropR") tropR = entry->value;
       else if(entry->name ==    "tropNB") tropNB = entry->value;
       else if(entry->name ==    "tropB") tropB = entry->value;
       else if(entry->name ==    "tropN") tropN = entry->value;
       else if(entry->name ==    "Qmato") Qmato = entry->value;
       else if(entry->name ==    "Qmate") Qmate = entry->value;

       entry++;
    }
    debugparam();
}

void set_param_value(int value, string name)
{
    sEvalParam *entry = &paramlist[0];

    while(entry->name != "end")
    {
       if(entry->name == name) { entry->value = value; break; }
       entry++;
    }

    init_eval_param();
    init_psqt();
    safety_table_init();
}

void printevalparam()
{
       cout<<"\n Eval Paramters: "<<endl;
       sEvalParam *entry = &paramlist[0];
       while(entry->name != "end")
       {
       if(entry->name ==   "BPair") { cout<<entry->name<<" "<< BPair  ; }
       else if(entry->name ==   "BmobminO") { cout<<endl<<entry->name<<" "<< BmobminO ; }
       else if(entry->name ==   "BmobminE") { cout<<endl<<entry->name<<" "<< BmobminE ; }
       else if(entry->name ==   "BmobsqO") { cout<<endl<<entry->name<<" "<< BmobsqO ; }
       else if(entry->name ==   "BmobsqE") { cout<<endl<<entry->name<<" "<< BmobsqE ; }
       else if(entry->name ==   "QmobminO") { cout<<endl<<entry->name<<" "<< QmobminO ; }
       else if(entry->name ==   "QmobminE") { cout<<endl<<entry->name<<" "<< QmobminE ; }
       else if(entry->name ==   "QmobsqO") { cout<<endl<<entry->name<<" "<< QmobsqO ; }
       else if(entry->name ==   "QmobsqE") { cout<<endl<<entry->name<<" "<< QmobsqE ; }
       else if(entry->name ==   "RmobminO") { cout<<endl<<entry->name<<" "<< RmobminO ; }
       else if(entry->name ==   "RmobminE") { cout<<endl<<entry->name<<" "<< RmobminE ; }
       else if(entry->name ==   "RmobsqO") { cout<<endl<<entry->name<<" "<< RmobsqO ; }
       else if(entry->name ==   "RmobsqE") { cout<<endl<<entry->name<<" "<< RmobsqE ; }
       else if(entry->name ==   "NmobminO") { cout<<endl<<entry->name<<" "<< NmobminO ; }
       else if(entry->name ==   "NmobminE") { cout<<endl<<entry->name<<" "<< NmobminE ; }
       else if(entry->name ==   "NmobsqO") { cout<<endl<<entry->name<<" "<< NmobsqO ; }
       else if(entry->name ==   "NmobsqE") { cout<<endl<<entry->name<<" "<< NmobsqE ; }
       else if(entry->name ==   "KingMid") { cout<<endl<<entry->name<<" "<< KingMid ; }
       else if(entry->name ==   "KingP1") { cout<<endl<<entry->name<<" "<< KingP1 ; }
       else if(entry->name ==   "KingP2") { cout<<endl<<entry->name<<" "<< KingP2 ; }
       else if(entry->name ==   "KingP3") { cout<<endl<<entry->name<<" "<< KingP3 ; }
       else if(entry->name ==   "NSupp1") { cout<<endl<<entry->name<<" "<< NSupp1 ; }
       else if(entry->name ==   "NSupp2") { cout<<endl<<entry->name<<" "<< NSupp2 ; }
       else if(entry->name ==   "NSupp3") { cout<<endl<<entry->name<<" "<< NSupp3 ; }
       else if(entry->name ==   "PDouOpe") { cout<<endl<<entry->name<<" "<< PDouOpe ; }
       else if(entry->name ==   "PDouEnd") { cout<<endl<<entry->name<<" "<< PDouEnd ; }
       else if(entry->name ==   "PIsoOpe") { cout<<endl<<entry->name<<" "<< PIsoOpe ; }
       else if(entry->name ==   "PIsoEnd") { cout<<endl<<entry->name<<" "<< PIsoEnd ; }
       else if(entry->name ==   "POpeOpe") { cout<<endl<<entry->name<<" "<< POpeOpe ; }
       else if(entry->name ==   "POpeEnd") { cout<<endl<<entry->name<<" "<< POpeEnd ; }
       else if(entry->name ==   "PBacOpe") { cout<<endl<<entry->name<<" "<< PBacOpe ; }
       else if(entry->name ==   "PBacEnd") { cout<<endl<<entry->name<<" "<< PBacEnd ; }
       else if(entry->name ==   "PPasOpe") { cout<<endl<<entry->name<<" "<< PPasOpe ; }
       else if(entry->name ==   "PPasEnd") { cout<<endl<<entry->name<<" "<< PPasEnd ; }
       else if(entry->name ==   "PPasConOpe") { cout<<endl<<entry->name<<" "<< PPasConOpe ; }
       else if(entry->name ==   "PPasConEnd") { cout<<endl<<entry->name<<" "<< PPasConEnd ; }
       else if(entry->name ==   "PPasRookEnd") { cout<<endl<<entry->name<<" "<< PPasRookEnd ; }
       else if(entry->name ==   "PCanOpe") { cout<<endl<<entry->name<<" "<< PCanOpe ; }
       else if(entry->name ==   "PCanEnd") { cout<<endl<<entry->name<<" "<< PCanEnd ; }
       else if(entry->name ==   "QAttSide") { cout<<endl<<entry->name<<" "<<  QAttSide ; }
       else if(entry->name ==   "QAttDir") { cout<<endl<<entry->name<<" "<< QAttDir ; }
       else if(entry->name ==   "QSevOpe") { cout<<endl<<entry->name<<" "<<  QSevOpe ; }
       else if(entry->name ==   "QSevEnd") { cout<<endl<<entry->name<<" "<< QSevEnd ; }
       else if(entry->name ==   "RAttSide") { cout<<endl<<entry->name<<" "<< RAttSide  ; }
       else if(entry->name ==   "RAttDir") { cout<<endl<<entry->name<<" "<< RAttDir  ; }
       else if(entry->name ==   "RSevOpe") { cout<<endl<<entry->name<<" "<< RSevOpe ; }
       else if(entry->name ==   "RSevEnd") { cout<<endl<<entry->name<<" "<<  RSevEnd ; }
       else if(entry->name ==   "RSemFile") { cout<<endl<<entry->name<<" "<< RSemFile ; }
       else if(entry->name ==   "ROpeFile") { cout<<endl<<entry->name<<" "<< ROpeFile ; }
       else if(entry->name ==    "trP") { cout<<endl<<entry->name<<" "<< trP ; }
       else if(entry->name ==    "trP") { cout<<endl<<entry->name<<" "<< trP ; }
       else if(entry->name ==    "trB") { cout<<endl<<entry->name<<" "<<trB ; }
       else if(entry->name ==   "minordev") { cout<<endl<<entry->name<<" "<< minordev ; }
       else if(entry->name ==   "majorsoon") { cout<<endl<<entry->name<<" "<< majorsoon ; }
       else if(entry->name ==   "psqPo") { cout<<endl<<entry->name<<" "<< psqPo ; }
       else if(entry->name ==   "psqPe") { cout<<endl<<entry->name<<" "<< psqPe ; }
       else if(entry->name ==   "psqPra") { cout<<endl<<entry->name<<" "<< psqPra ; }
       else if(entry->name ==   "psqNo") { cout<<endl<<entry->name<<" "<< psqNo ; }
       else if(entry->name ==   "psqNe") { cout<<endl<<entry->name<<" "<< psqNe ; }
       else if(entry->name ==   "psqBo") { cout<<endl<<entry->name<<" "<< psqBo ; }
       else if(entry->name ==   "psqBe") { cout<<endl<<entry->name<<" "<< psqBe ; }
       else if(entry->name ==   "psqRo") { cout<<endl<<entry->name<<" "<< psqRo ; }
       else if(entry->name ==   "psqQo") { cout<<endl<<entry->name<<" "<<  psqQo ; }
       else if(entry->name ==   "psqQe") { cout<<endl<<entry->name<<" "<<  psqQe ; }
       else if(entry->name ==   "psqKo") { cout<<endl<<entry->name<<" "<< psqKo ; }
       else if(entry->name ==   "psqKe") { cout<<endl<<entry->name<<" "<< psqKe ; }
       else if(entry->name ==   "PDouOpeWk") { cout<<endl<<entry->name<<" "<<  PDouOpeWk ; }
       else if(entry->name ==   "PDouEndWk") { cout<<endl<<entry->name<<" "<< PDouEndWk ; }
       else if(entry->name ==    "PIsoOpeWk") { cout<<endl<<entry->name<<" "<< PIsoOpeWk ; }
       else if(entry->name ==    "PIsoEndWk") { cout<<endl<<entry->name<<" "<< PIsoEndWk ; }
       else if(entry->name ==    "tropNBRQ") { cout<<endl<<entry->name<<" "<<tropNBRQ;}
       else if(entry->name ==    "tropBRQ") { cout<<endl<<entry->name<<" "<<tropBRQ;}
       else if(entry->name ==    "tropNRQ") { cout<<endl<<entry->name<<" "<<tropNRQ;}
       else if(entry->name ==    "tropRQ") { cout<<endl<<entry->name<<" "<<tropRQ;}
       else if(entry->name ==    "tropNBQ") { cout<<endl<<entry->name<<" "<<tropNBQ;}
       else if(entry->name ==    "tropBQ") { cout<<endl<<entry->name<<" "<<tropBQ;}
       else if(entry->name ==    "tropNQ") { cout<<endl<<entry->name<<" "<<tropNQ;}
       else if(entry->name ==    "tropQ") { cout<<endl<<entry->name<<" "<<tropQ;}
       else if(entry->name ==    "tropNBR") { cout<<endl<<entry->name<<" "<<tropNBR;}
       else if(entry->name ==    "tropBR") { cout<<endl<<entry->name<<" "<<tropBR;}
       else if(entry->name ==    "tropNR") { cout<<endl<<entry->name<<" "<<tropNR;}
       else if(entry->name ==    "tropR") { cout<<endl<<entry->name<<" "<<tropR;}
       else if(entry->name ==    "tropNB") { cout<<endl<<entry->name<<" "<<tropNB;}
       else if(entry->name ==    "tropB") { cout<<endl<<entry->name<<" "<<tropB;}
       else if(entry->name ==    "tropN") { cout<<endl<<entry->name<<" "<<tropN;}
       else if(entry->name ==    "Qmato") { cout<<endl<<entry->name<<" "<<Qmato;}
       else if(entry->name ==    "Qmate") { cout<<endl<<entry->name<<" "<<Qmate;}
       entry++;
       }
}


bool debugparam()
{
       sEvalParam *entry = &paramlist[0];
       while(entry->name != "end")
       {
       if(entry->name ==   "BPair") { if(entry->value!=BPair) cout<<" BPAir error "; return false; }
       else if(entry->name ==   "BmobminO") { if(entry->value != BmobminO ) cout<<" BmobminO error "; return false; }
       else if(entry->name ==   "BmobminE") { if(entry->value != BmobminE ) cout<<" BmobminE error "; return false; }
       else if(entry->name ==   "BmobsqO") { if(entry->value != BmobsqO ) cout<<" BmobsqO error "; return false; }
       else if(entry->name ==   "BmobsqE") { if(entry->value != BmobsqE ) cout<<" BmobsqE error "; return false; }
       else if(entry->name ==   "QmobminO") { if(entry->value != QmobminO ) cout<<" QmobminO error "; return false; }
       else if(entry->name ==   "QmobminE") { if(entry->value != QmobminE ) cout<<" QmobminE error "; return false; }
       else if(entry->name ==   "QmobsqO") { if(entry->value != QmobsqO ) cout<<" QmobsqO error "; return false; }
       else if(entry->name ==   "QmobsqE") { if(entry->value != QmobsqE ) cout<<" QmobsqE error "; return false; }
       else if(entry->name ==   "RmobminO") { if(entry->value != RmobminO ) cout<<" RmobminO error "; return false; }
       else if(entry->name ==   "RmobminE") { if(entry->value != RmobminE ) cout<<" RmobminE error "; return false; }
       else if(entry->name ==   "RmobsqO") { if(entry->value != RmobsqO ) cout<<" RmobsqO error "; return false; }
       else if(entry->name ==   "RmobsqE") { if(entry->value != RmobsqE ) cout<<" RmobsqE error "; return false; }
       else if(entry->name ==   "NmobminO") { if(entry->value != NmobminO ) cout<<" NmobminO error "; return false; }
       else if(entry->name ==   "NmobminE") { if(entry->value != NmobminE ) cout<<" NmobminE error "; return false; }
       else if(entry->name ==   "NmobsqO") { if(entry->value != NmobsqO ) cout<<" NmobsqO error "; return false; }
       else if(entry->name ==   "NmobsqE") { if(entry->value != NmobsqE ) cout<<" NmobsqE error "; return false; }
       else if(entry->name ==   "KingMid") { if(entry->value != KingMid ) cout<<" KingMid error "; return false; }
       else if(entry->name ==   "KingP1") { if(entry->value != KingP1 ) cout<<" KingP1 error "; return false; }
       else if(entry->name ==   "KingP2") { if(entry->value != KingP2 ) cout<<" KingP2 error "; return false; }
       else if(entry->name ==   "KingP3") { if(entry->value != KingP3 ) cout<<" KingP3 error "; return false; }
       else if(entry->name ==   "NSupp1") { if(entry->value != NSupp1 ) cout<<" NSupp1 error "; return false; }
       else if(entry->name ==   "NSupp2") { if(entry->value != NSupp2 ) cout<<" NSupp2 error "; return false; }
       else if(entry->name ==   "NSupp3") { if(entry->value != NSupp3 ) cout<<" NSupp3 error "; return false; }
       else if(entry->name ==   "PDouOpe") { if(entry->value != PDouOpe ) cout<<" PDouOpe error "; return false; }
       else if(entry->name ==   "PDouEnd") { if(entry->value != PDouEnd ) cout<<" PDouEnd error "; return false; }
       else if(entry->name ==   "PIsoOpe") { if(entry->value != PIsoOpe ) cout<<" PIsoOpe error "; return false; }
       else if(entry->name ==   "PIsoEnd") { if(entry->value != PIsoEnd ) cout<<" PIsoEnd error "; return false; }
       else if(entry->name ==   "POpeOpe") { if(entry->value != POpeOpe ) cout<<" POpeOpe error "; return false; }
       else if(entry->name ==   "POpeEnd") { if(entry->value != POpeEnd ) cout<<" POpeEnd error "; return false; }
       else if(entry->name ==   "PBacOpe") { if(entry->value != PBacOpe ) cout<<" PBacOpe error "; return false; }
       else if(entry->name ==   "PBacEnd") { if(entry->value != PBacEnd ) cout<<" PBacEnd error "; return false; }
       else if(entry->name ==   "PPasOpe") { if(entry->value != PPasOpe ) cout<<" PPasOpe error "; return false; }
       else if(entry->name ==   "PPasEnd") { if(entry->value != PPasEnd ) cout<<" PPasEnd error "; return false; }
       else if(entry->name ==   "PPasConOpe") { if(entry->value != PPasConOpe ) cout<<" PPasConOpe error "; return false; }
       else if(entry->name ==   "PPasConEnd") { if(entry->value != PPasConEnd ) cout<<" PPasConEnd error "; return false; }
       else if(entry->name ==   "PPasRookEnd") { if(entry->value != PPasRookEnd ) cout<<" PPasRookEnd error "; return false; }
       else if(entry->name ==   "PCanOpe") { if(entry->value != PCanOpe ) cout<<" PCanOpe error "; return false; }
       else if(entry->name ==   "PCanEnd") { if(entry->value != PCanEnd ) cout<<" PCanEnd error "; return false; }
       else if(entry->name ==   "QAttSide") { if(entry->value !=  QAttSide ) cout<<" QAttSide error "; return false; }
       else if(entry->name ==   "QAttDir") { if(entry->value != QAttDir ) cout<<" QAttDir error "; return false; }
       else if(entry->name ==   "QSevOpe") { if(entry->value !=  QSevOpe ) cout<<" QSevOpe error "; return false; }
       else if(entry->name ==   "QSevEnd") { if(entry->value != QSevEnd ) cout<<" QSevEnd error "; return false; }
       else if(entry->name ==   "RAttSide") { if(entry->value != RAttSide  ) cout<<" RAttSide error "; return false; }
       else if(entry->name ==   "RAttDir") { if(entry->value != RAttDir  ) cout<<" RAttDir error "; return false; }
       else if(entry->name ==   "RSevOpe") { if(entry->value != RSevOpe ) cout<<" RSevOpe error "; return false; }
       else if(entry->name ==   "RSevEnd") { if(entry->value !=  RSevEnd ) cout<<" RSevEnd error "; return false; }
       else if(entry->name ==   "RSemFile") { if(entry->value != RSemFile ) cout<<" RSemFile error "; return false; }
       else if(entry->name ==   "ROpeFile") { if(entry->value != ROpeFile ) cout<<" ROpeFile error "; return false; }
       else if(entry->name ==    "trP") { if(entry->value != trP ) cout<<" trP error "; return false; }
       else if(entry->name ==    "trP") { if(entry->value != trP ) cout<<" trP error "; return false; }
       else if(entry->name ==    "trB") { if(entry->value !=trB ) cout<<" trB error "; return false; }
       else if(entry->name ==   "minordev") { if(entry->value != minordev ) cout<<" minordev error "; return false; }
       else if(entry->name ==   "majorsoon") { if(entry->value != majorsoon ) cout<<" majorsoon error "; return false; }
       else if(entry->name ==   "psqPo") { if(entry->value != psqPo ) cout<<" psqPo error "; return false; }
       else if(entry->name ==   "psqPe") { if(entry->value != psqPe ) cout<<" psqPe error "; return false; }
       else if(entry->name ==   "psqPra") { if(entry->value != psqPra ) cout<<" psqPra error "; return false; }
       else if(entry->name ==   "psqNo") { if(entry->value != psqNo ) cout<<" psqNo error "; return false; }
       else if(entry->name ==   "psqNe") { if(entry->value != psqNe ) cout<<" psqNe error "; return false; }
       else if(entry->name ==   "psqBo") { if(entry->value != psqBo ) cout<<" psqBo error "; return false; }
       else if(entry->name ==   "psqBe") { if(entry->value != psqBe ) cout<<" psqBe error "; return false; }
       else if(entry->name ==   "psqRo") { if(entry->value != psqRo ) cout<<" psqRo error "; return false; }
       else if(entry->name ==   "psqQo") { if(entry->value !=  psqQo ) cout<<" psqQo error "; return false; }
       else if(entry->name ==   "psqQe") { if(entry->value !=  psqQe ) cout<<" psqQe error "; return false; }
       else if(entry->name ==   "psqKo") { if(entry->value != psqKo ) cout<<" psqKo error "; return false; }
       else if(entry->name ==   "psqKe") { if(entry->value != psqKe ) cout<<" psqKe error "; return false; }
       else if(entry->name ==   "PDouOpeWk") { if(entry->value !=  PDouOpeWk ) cout<<" PDouOpeWk error "; return false; }
       else if(entry->name ==   "PDouEndWk") { if(entry->value != PDouEndWk ) cout<<" PDouEndWk error "; return false; }
       else if(entry->name ==   "PIsoOpeWk") { if(entry->value != PIsoOpeWk ) cout<<" PIsoOpeWk error "; return false; }
       else if(entry->name ==   "PIsoEndWk") { if(entry->value != PIsoEndWk ) cout<<" PIsoEndWk error "; return false; }
       else if(entry->name ==   "tropNBRQ") { if(entry->value !=tropNBRQ ) cout<<" tropNBRQError "; return false;}
       else if(entry->name ==   "tropBRQ") { if(entry->value !=tropBRQ ) cout<<" tropBRQError "; return false;}
       else if(entry->name ==   "tropNRQ") { if(entry->value !=tropNRQ ) cout<<" tropNRQError "; return false;}
       else if(entry->name ==   "tropRQ") { if(entry->value !=tropRQ ) cout<<" tropRQError "; return false;}
       else if(entry->name ==   "tropNBQ") { if(entry->value !=tropNBQ ) cout<<" tropNBQError "; return false;}
       else if(entry->name ==   "tropBQ") { if(entry->value !=tropBQ ) cout<<" tropBQError "; return false;}
       else if(entry->name ==   "tropNQ") { if(entry->value !=tropNQ ) cout<<" tropNQError "; return false;}
       else if(entry->name ==   "tropQ") { if(entry->value !=tropQ ) cout<<" tropQError "; return false;}
       else if(entry->name ==   "tropNBR") { if(entry->value !=tropNBR ) cout<<" tropNBRError "; return false;}
       else if(entry->name ==   "tropBR") { if(entry->value !=tropBR ) cout<<" tropBRError "; return false;}
       else if(entry->name ==   "tropNR") { if(entry->value !=tropNR ) cout<<" tropNRError "; return false;}
       else if(entry->name ==   "tropR") { if(entry->value !=tropR ) cout<<" tropRError "; return false;}
       else if(entry->name ==   "tropNB") { if(entry->value !=tropNB ) cout<<" tropNBError "; return false;}
       else if(entry->name ==   "tropB") { if(entry->value !=tropB ) cout<<" tropBError "; return false;}
       else if(entry->name ==   "tropN") { if(entry->value !=tropN ) cout<<" tropNError "; return false;}
       else if(entry->name ==   "Qmato") { if(entry->value !=Qmato ) cout<<" QmatoError "; return false;}
       else if(entry->name ==   "Qmate") { if(entry->value !=Qmate ) cout<<" QmateError "; return false;}

       entry++;
       }
	   return true;
}

